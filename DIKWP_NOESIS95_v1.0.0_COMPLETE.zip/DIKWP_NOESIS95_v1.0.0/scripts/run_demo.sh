#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python run.py demo --out outputs/yucongduan_cosmic_method "$@"
python run.py verify outputs/yucongduan_cosmic_method
