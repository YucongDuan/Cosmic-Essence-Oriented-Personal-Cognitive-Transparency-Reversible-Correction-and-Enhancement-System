@echo off
cd /d %~dp0\..
python run.py demo --out outputs\yucongduan_cosmic_method %*
if errorlevel 1 exit /b %errorlevel%
python run.py verify outputs\yucongduan_cosmic_method
