#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd: list[str], *, cwd: Path = ROOT, env: dict[str, str] | None = None) -> dict[str, Any]:
    full_env = os.environ.copy()
    if env:
        full_env.update(env)
    proc = subprocess.run(cmd, cwd=cwd, env=full_env, text=True, capture_output=True)
    record = {
        "command": cmd,
        "cwd": str(cwd),
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }
    if proc.returncode != 0:
        raise RuntimeError(json.dumps(record, ensure_ascii=False, indent=2))
    return record


def parse_last_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if not text:
        return {}
    return json.loads(text)


def main() -> int:
    ap = argparse.ArgumentParser(description="Validate a DIKWP-NOESIS95 source tree and create a machine-readable receipt")
    ap.add_argument("--eidos", help="Optional EIDOS95 essence_bundle.json used by the demo")
    ap.add_argument("--output", default=str(ROOT / "RELEASE_VALIDATION.json"))
    ap.add_argument("--skip-wheel", action="store_true")
    args = ap.parse_args()

    result: dict[str, Any] = {
        "system": "DIKWP-NOESIS 9.5",
        "version": "1.0.0",
        "project_root": str(ROOT),
        "python": sys.version,
        "checks": [],
        "boundaries": [
            "The demo is a small curated public-method and synthetic stress-test sample, not a complete-person model or diagnosis.",
            "The 24 working-law cards are not collectively asserted as experimentally established final laws of physics or consciousness.",
            "Automatic external-action authority is fixed at zero.",
        ],
        "automatic_external_action_authority": 0,
    }

    compile_record = run([PYTHON, "-m", "compileall", "-q", "src", "tests", "scripts"])
    result["checks"].append({"name": "python_compileall", "passed": True, "returncode": compile_record["returncode"]})

    test_record = run([PYTHON, "-m", "unittest", "discover", "-s", "tests", "-v"], env={"PYTHONPATH": str(ROOT / "src")})
    combined = test_record["stdout"] + "\n" + test_record["stderr"]
    match = re.search(r"Ran\s+(\d+)\s+tests?", combined)
    test_count = int(match.group(1)) if match else None
    result["checks"].append({"name": "unit_tests", "passed": True, "test_count": test_count})

    doctor_record = run([PYTHON, "run.py", "doctor"])
    doctor = parse_last_json(doctor_record["stdout"])
    if doctor.get("bundled_working_law_count") != 24 or doctor.get("automatic_external_action_authority") != 0:
        raise RuntimeError(f"Doctor invariant failure: {doctor}")
    result["checks"].append({"name": "doctor", "passed": True, "details": doctor})

    output_dir = ROOT / "outputs" / "release_demo"
    if output_dir.exists():
        shutil.rmtree(output_dir)
    demo_cmd = [PYTHON, "run.py", "demo", "--out", str(output_dir)]
    if args.eidos:
        demo_cmd += ["--eidos", str(Path(args.eidos).resolve())]
    demo_record = run(demo_cmd)
    demo = parse_last_json(demo_record["stdout"])
    result["checks"].append({"name": "demo_compile", "passed": True, "details": demo})

    verify_record = run([PYTHON, "run.py", "verify", str(output_dir)])
    verify = parse_last_json(verify_record["stdout"])
    if not verify.get("valid"):
        raise RuntimeError(f"Output verification failure: {verify}")
    result["checks"].append({"name": "compiled_output_integrity", "passed": True, "details": verify})

    bundle = output_dir / "noesis_bundle.json"
    owner_export = output_dir / "owner_transparency_packet.json"
    public_export = output_dir / "public_transparency_packet.json"
    run([PYTHON, "run.py", "export", "--bundle", str(bundle), "--audience", "owner", "--out", str(owner_export)])
    run([PYTHON, "run.py", "export", "--bundle", str(bundle), "--audience", "public", "--out", str(public_export)])
    owner_packet = json.loads(owner_export.read_text(encoding="utf-8"))
    public_packet = json.loads(public_export.read_text(encoding="utf-8"))
    if owner_packet.get("automatic_external_action_authority") != 0 or public_packet.get("automatic_external_action_authority") != 0:
        raise RuntimeError("Export authority invariant failure")
    result["checks"].append({
        "name": "selective_exports",
        "passed": True,
        "owner_event_count": len(owner_packet.get("events", [])),
        "public_event_count": len(public_packet.get("events", [])),
        "public_is_filtered_view": True,
    })

    delta_path = output_dir / "self_diff.json"
    run([PYTHON, "run.py", "diff", "--old", str(bundle), "--new", str(bundle), "--out", str(delta_path)])
    delta = json.loads(delta_path.read_text(encoding="utf-8"))
    if delta.get("added_event_ids") or delta.get("changed_events"):
        raise RuntimeError("Self-diff must contain no added or changed events")
    result["checks"].append({"name": "worldline_self_diff", "passed": True})

    dashboard = output_dir / "dashboard.html"
    html_text = dashboard.read_text(encoding="utf-8")
    if "Automatic external-action authority 0" not in html_text or "<script type=\"application/json\"" not in html_text:
        raise RuntimeError("Dashboard boundary or embedded-data marker missing")
    if re.search(r"<script[^>]+src=", html_text, flags=re.I):
        raise RuntimeError("Dashboard unexpectedly references external script")
    result["checks"].append({"name": "offline_dashboard_static_check", "passed": True, "external_script_tags": 0})

    wheel_info = None
    if not args.skip_wheel:
        dist = ROOT / "dist"
        dist.mkdir(exist_ok=True)
        for old in dist.glob("dikwp_noesis95-*.whl"):
            old.unlink()
        run([PYTHON, "-m", "pip", "wheel", ".", "--no-deps", "--no-build-isolation", "-w", str(dist)])
        wheels = sorted(dist.glob("dikwp_noesis95-*.whl"))
        if len(wheels) != 1:
            raise RuntimeError(f"Expected exactly one wheel, found {wheels}")
        wheel = wheels[0]
        with tempfile.TemporaryDirectory(prefix="noesis95-venv-") as td:
            venv = Path(td) / "venv"
            run([PYTHON, "-m", "venv", str(venv)])
            py = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
            cli = venv / ("Scripts/noesis95.exe" if os.name == "nt" else "bin/noesis95")
            run([str(py), "-m", "pip", "install", "--no-deps", str(wheel)], cwd=ROOT)
            installed = run([str(cli), "doctor"], cwd=ROOT)
            installed_doctor = parse_last_json(installed["stdout"])
            if installed_doctor.get("bundled_working_law_count") != 24:
                raise RuntimeError("Installed wheel is missing the 24-card registry")
        wheel_info = {"path": str(wheel), "sha256": sha256(wheel), "isolated_install": True}
        result["checks"].append({"name": "wheel_build_and_isolated_install", "passed": True, "details": wheel_info})

    output_info = json.loads((output_dir / "OUTPUT_INFO.json").read_text(encoding="utf-8"))
    result["demo"] = {
        "output_dir": str(output_dir),
        "compilation_id": output_info.get("compilation_id"),
        "bundle_digest": output_info.get("bundle_digest"),
        "ledger_head_digest": output_info.get("ledger_head_digest"),
        "event_count": output_info.get("event_count"),
        "evidence_count": output_info.get("evidence_count"),
        "issue_count": output_info.get("issue_count"),
        "correction_candidate_count": output_info.get("correction_candidate_count"),
        "integrity_covered_file_count": verify.get("checked_files"),
    }
    result["wheel"] = wheel_info
    result["status"] = "PASS"

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "validation": str(out.resolve()), "test_count": test_count, "demo": result["demo"], "wheel": wheel_info}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
