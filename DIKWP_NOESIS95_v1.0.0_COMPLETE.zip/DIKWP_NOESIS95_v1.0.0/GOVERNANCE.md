# Governance

DIKWP-NOESIS95 is governed by the following order of responsibility:

1. source and factual integrity;
2. owner consent, refusal, revocation and correction;
3. affected-world burden, appeal and repair;
4. domain-specific safety and law;
5. transparent, reversible technical operation;
6. convenience and automation.

No contributor may introduce automatic external-action authority, silent cognitive-record mutation, clinical diagnosis, involuntary profiling or a total person score into the reference implementation without creating a clearly separate project and ceasing to represent it as this system.

Changes to the working-law registry require a version increment, stated evidence or rationale, falsifier/retirement update and migration note. Historical registries remain available.
