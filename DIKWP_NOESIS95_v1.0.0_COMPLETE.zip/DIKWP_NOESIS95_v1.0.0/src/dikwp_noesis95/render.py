from __future__ import annotations

import csv
import html
import json
from pathlib import Path
from typing import Any

from .utils import save_json, save_text

_DIM_ZH = {
    "provenance_traceability": "来源可追溯",
    "scope_explicitness": "范围显式",
    "uncertainty_explicitness": "不确定性显式",
    "claim_class_discipline": "主张分类纪律",
    "dikwp_separation": "DIKWP位置分离",
    "model_plurality": "模型多元性",
    "distinguishing_evidence": "区分性证据",
    "value_visibility": "价值可见",
    "purpose_executability": "目的可执行",
    "affected_world_visibility": "受影响世界可见",
    "falsifiability": "可否证性",
    "action_reversibility": "行动可逆性",
    "reality_contact": "现实接触",
    "revision_continuity": "修订连续性",
    "residual_preservation": "残差保留",
    "capacity_context": "能力与情境",
}


def _pct(value: float | int | None) -> str:
    return "—" if value is None else f"{float(value) * 100:.1f}%"


def _md_escape(text: Any) -> str:
    return str(text or "").replace("|", "\\|").replace("\n", " ")


def render_report(bundle: dict[str, Any]) -> str:
    owner = bundle["owner"]
    audit = bundle["audit"]
    cal = bundle["calibration"]
    lines = [
        "# DIKWP-NOESIS 9.5 个人认知透明化反馈报告",
        "",
        f"- 所有者 / Owner: `{owner['owner_id']}` — {owner.get('display_name', '')}",
        f"- 编译标识 / Compilation: `{bundle['compilation_id']}`",
        f"- 生成时间 / Generated: {bundle['generated_at']}",
        f"- Mesh95模式: `{bundle['mesh95_audit']['mode']}`",
        "- 自动外部行动权限 / Automatic external-action authority: `0`",
        "",
        "> 本报告衡量的是所提供认知记录的可追溯性、范围、不确定性、模型竞争、现实校准、可逆性与负担可见性。它不是对人的真理、智力、人格、道德、意识或心理健康评分。",
        "",
        "> 命名空间边界：`claim_class=P`表示经验假说；`dikwp=P`表示目的/可执行输入—输出取向。两者不得因字母相同而坍塌。",
        "",
        "## 1. 透明度向量 / Transparency vector",
        "",
        "| 维度 | 当前记录表现 |",
        "|---|---:|",
    ]
    for dim, score in audit["transparency_vector"].items():
        lines.append(f"| {_DIM_ZH.get(dim, dim)} / `{dim}` | {_pct(score)} |")
    lines += [
        "",
        f"导航均值（仅用于定位缺口，不是单一认知分数）：**{_pct(audit['navigation_mean'])}**",
        "",
        "## 2. 需要优先审阅的认知风险模式",
        "",
        "| 严重度 | 事件 | 模式 | 依据 |",
        "|---:|---|---|---|",
    ]
    for issue in audit.get("issues", [])[:40]:
        lines.append(f"| {issue['severity']} | `{issue['event_id']}` | {issue['title_zh']} (`{issue['code']}`) | {_md_escape(issue['reason_zh'])} |")
    if not audit.get("issues"):
        lines.append("| — | — | 当前记录未触发内置规则；这不等于记录真实、完整或没有盲区。 | — |")
    lines += [
        "",
        "## 3. 预测与现实校准",
        "",
        f"- 预测总数：{cal['prediction_count']}；已解决：{cal['resolved_count']}；待解决：{cal['pending_count']}；逾期：{cal['overdue_count']}。",
        f"- 平均Brier分数：{cal['mean_brier'] if cal['mean_brier'] is not None else '尚不可计算'}。",
        f"- 期望校准误差：{cal['expected_calibration_error'] if cal['expected_calibration_error'] is not None else '尚不可计算'}。",
        f"- 解释边界：{cal['interpretation_boundary']}",
        "",
        "## 4. 24条宇宙本质导向工作规律的记录对齐",
        "",
        "> 对齐只表示当前记录体现了相应操作协议，不证明这些命题是终极物理定律或意识定律。",
        "",
        "| 规律 | 认识论状态 | 记录对齐 | 导航均值 | 命中问题 |",
        "|---|---|---|---:|---|",
    ]
    for law in bundle["law_alignment"]["laws"]:
        lines.append(f"| {law['law_id']} {law['name_zh']} | `{law['epistemic_status']}` | `{law['record_alignment_status']}` | {_pct(law['navigation_mean'])} | {_md_escape(', '.join(law['issue_hits']) or '—')} |")
    lines += [
        "",
        "## 5. 可逆认知矫正候选",
        "",
        "> 所有候选均需所有者具名批准；系统不会自动覆盖原记录。批准后只追加后继记录，并保留原始世界线。",
        "",
        "| 优先级 | 目标事件 | 操作 | 区分性现实步骤 |",
        "|---:|---|---|---|",
    ]
    for prop in bundle["correction_proposals"][:40]:
        lines.append(f"| {prop['severity']} | `{prop['event_id']}` | `{prop['operation']}` | {_md_escape(prop['discriminating_action'])} |")
    if not bundle["correction_proposals"]:
        lines.append("| — | — | 当前没有自动生成候选；仍建议进行所有者复核与主动反证。 | — |")
    lines += [
        "",
        "## 6. 认知提升方案",
        "",
    ]
    for ex in bundle["enhancement_plan"]["exercises"]:
        lines += [
            f"### {ex['priority']}. {ex['name_zh']} / {ex['name_en']}",
            f"对应维度：`{ex['dimension']}`；当前记录表现：{_pct(ex['current_record_score'])}",
            "",
        ]
        for step in ex["protocol"]:
            lines.append(f"1. {step}")
        lines += [
            "",
            f"衡量：{ex['metric']}",
            f"节奏：{ex['cadence']}",
            f"停止/减负：{ex['burden_limit']}",
            "",
        ]
    lines += [
        "## 7. 关键边界",
        "",
    ]
    for boundary in bundle.get("claim_boundaries", []):
        lines.append(f"- {boundary}")
    lines += [
        "",
        "## 8. 责任交接",
        "",
        f"- 所有者决定：{bundle['responsibility_handoff']['owner_decisions']}",
        f"- 系统保留：{bundle['responsibility_handoff']['system_preserves']}",
        f"- 外部专业验证：{bundle['responsibility_handoff']['domain_validation']}",
        "",
    ]
    return "\n".join(lines) + "\n"


def render_enhancement_markdown(plan: dict[str, Any]) -> str:
    lines = ["# NOESIS95 认知提升计划 / Cognitive Enhancement Plan", "", f"生成时间：{plan['generated_at']}", "", f"> {plan['clinical_boundary']}", ""]
    for ex in plan.get("exercises", []):
        lines.append(f"## {ex['priority']}. {ex['name_zh']} / {ex['name_en']}")
        lines.append(f"维度：`{ex['dimension']}`；当前记录表现：{_pct(ex['current_record_score'])}")
        lines.append("")
        for step in ex["protocol"]:
            lines.append(f"- {step}")
        lines += ["", f"指标：{ex['metric']}", f"节奏：{ex['cadence']}", f"减负边界：{ex['burden_limit']}", f"主体控制：{ex['owner_control']}", ""]
    lines += ["## 防止指标绑架", "", plan["anti_gaming"], "", f"自动外部行动权限：{plan['automatic_external_action_authority']}", ""]
    return "\n".join(lines)


def _json_for_script(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")


def render_dashboard(bundle: dict[str, Any]) -> str:
    audit = bundle["audit"]
    cal = bundle["calibration"]
    dim_cards = "".join(
        f'<article class="metric"><div class="metric-name">{html.escape(_DIM_ZH.get(dim, dim))}</div><div class="metric-val">{float(score)*100:.1f}%</div><div class="bar"><i style="width:{float(score)*100:.1f}%"></i></div><code>{html.escape(dim)}</code></article>'
        for dim, score in audit["transparency_vector"].items()
    )
    issue_rows = "".join(
        f'<tr data-severity="{i["severity"]}"><td><span class="sev s{i["severity"]}">{i["severity"]}</span></td><td><code>{html.escape(i["event_id"])}</code></td><td><strong>{html.escape(i["title_zh"])}</strong><br><code>{html.escape(i["code"])}</code></td><td>{html.escape(i["reason_zh"])}</td></tr>'
        for i in audit.get("issues", [])
    ) or '<tr><td colspan="4">当前记录未触发内置规则；这不是正确性证明。</td></tr>'
    law_rows = "".join(
        f'<tr><td><code>{law["law_id"]}</code></td><td>{html.escape(law["name_zh"])}</td><td>{html.escape(law["epistemic_status"])}</td><td><span class="tag">{html.escape(law["record_alignment_status"])}</span></td><td>{law["navigation_mean"]*100:.1f}%</td></tr>'
        for law in bundle["law_alignment"]["laws"]
    )
    corr_cards = "".join(
        f'<article class="card"><div class="kicker">严重度 {p["severity"]} · {html.escape(p["issue_code"])}</div><h3>{html.escape(p["operation"])}</h3><p><code>{html.escape(p["event_id"])}</code></p><p>{html.escape(p["reason_zh"])}</p><details><summary>候选补丁与区分试验</summary><pre>{html.escape(json.dumps(p["proposed_patch"], ensure_ascii=False, indent=2))}</pre><p>{html.escape(p["discriminating_action"])}</p></details><div class="boundary">需具名批准；不自动修改。</div></article>'
        for p in bundle["correction_proposals"][:24]
    ) or '<article class="card"><p>没有自动生成候选；仍需所有者复核和主动反证。</p></article>'
    ex_cards = "".join(
        f'<article class="card"><div class="kicker">优先级 {e["priority"]} · {html.escape(e["dimension"])}</div><h3>{html.escape(e["name_zh"])}</h3><p>{html.escape(e["name_en"])}</p><ol>{"".join(f"<li>{html.escape(step)}</li>" for step in e["protocol"])}</ol><p><b>指标：</b>{html.escape(e["metric"])}</p><div class="boundary">{html.escape(e["burden_limit"])}</div></article>'
        for e in bundle["enhancement_plan"]["exercises"]
    )
    event_rows = "".join(
        f'<tr><td><code>{html.escape(e["event_id"])}</code></td><td>{html.escape(e["kind"])}</td><td>{html.escape(e["claim_class"])} / {html.escape(e["dikwp"])}</td><td>{e["confidence"]:.2f}</td><td>{html.escape(next((x.get("visibility", "private") for x in bundle["event_index"] if x.get("event_id") == e["event_id"]), "private"))}</td><td>{html.escape(e["title"])}</td><td>{e["issue_count"]}</td></tr>'
        for e in audit["event_audits"]
    )
    data = _json_for_script({"audit": audit, "calibration": cal, "law_alignment": bundle["law_alignment"], "events": bundle["event_index"]})
    return f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-NOESIS 9.5 · 认知透明化仪表盘</title>
<style>
:root{{--bg:#071018;--panel:#0e1a24;--panel2:#132433;--text:#eaf3f7;--muted:#9db0bc;--line:#264152;--accent:#51d3b0;--warn:#ffc46b;--danger:#ff7f7f;--blue:#78b7ff}}
*{{box-sizing:border-box}}body{{margin:0;background:linear-gradient(180deg,#061018,#0a141c);color:var(--text);font:15px/1.6 ui-sans-serif,system-ui,-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}}
a{{color:var(--blue)}}code,pre{{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}}header{{padding:56px max(24px,6vw) 40px;border-bottom:1px solid var(--line);background:radial-gradient(circle at 80% 0,#143848 0,transparent 42%)}}header h1{{font-size:clamp(34px,6vw,72px);line-height:1.05;margin:8px 0 20px;max-width:1100px}}.eyebrow{{letter-spacing:.16em;text-transform:uppercase;color:var(--accent);font-weight:700}}.lede{{max-width:980px;color:var(--muted);font-size:18px}}.pill{{display:inline-block;border:1px solid var(--line);background:#0b1720;padding:6px 10px;border-radius:999px;margin:4px 6px 0 0}}main{{padding:32px max(20px,6vw) 80px;max-width:1700px;margin:auto}}section{{margin:38px 0 58px}}h2{{font-size:28px;margin:0 0 8px}}.sub{{color:var(--muted);max-width:1000px;margin:0 0 24px}}.metrics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}}.metric,.card{{background:linear-gradient(180deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:14px;padding:16px;box-shadow:0 12px 40px rgba(0,0,0,.16)}}.metric-name{{color:var(--muted)}}.metric-val{{font-size:27px;font-weight:750;margin:4px 0}}.bar{{height:7px;background:#07131b;border-radius:10px;overflow:hidden;margin:8px 0}}.bar i{{height:100%;display:block;background:linear-gradient(90deg,var(--blue),var(--accent))}}.metric code{{font-size:11px;color:#7892a2}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}}.card h3{{margin:4px 0 8px}}.kicker{{font-size:12px;color:var(--accent);letter-spacing:.06em;text-transform:uppercase}}.boundary{{border-left:3px solid var(--warn);padding:8px 10px;margin-top:12px;color:#f5d7a9;background:rgba(255,196,107,.06)}}table{{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--line);border-radius:12px;overflow:hidden}}th,td{{padding:11px 12px;border-bottom:1px solid var(--line);vertical-align:top;text-align:left}}th{{color:var(--muted);font-size:12px;letter-spacing:.05em;text-transform:uppercase;background:#101f2a}}tr:last-child td{{border-bottom:0}}.table-wrap{{overflow:auto;border-radius:12px}}.sev{{display:inline-grid;place-items:center;width:28px;height:28px;border-radius:50%;font-weight:800;background:#233746}}.s4,.s5{{background:#5e2428;color:#ffd6d6}}.s3{{background:#5a4720;color:#ffe6ae}}.tag{{display:inline-block;padding:3px 7px;border:1px solid var(--line);border-radius:8px;color:var(--muted)}}.summary-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}}.big{{font-size:38px;font-weight:800}}.muted{{color:var(--muted)}}details summary{{cursor:pointer;color:var(--blue)}}pre{{white-space:pre-wrap;word-break:break-word;background:#07131b;padding:12px;border-radius:8px;border:1px solid var(--line);max-height:360px;overflow:auto}}footer{{padding:24px max(20px,6vw);color:var(--muted);border-top:1px solid var(--line)}}@media print{{body{{background:white;color:#111}}header,.metric,.card,table{{background:white;color:#111;box-shadow:none}}.muted,.sub,.lede{{color:#444}}}}
</style></head><body>
<header><div class="eyebrow">MESH95 · NOESIS 9.5</div><h1>个人认知透明化、可逆矫正与共同提升</h1><p class="lede">不是人格判决，不是思想改造，也不是“终极真理评分”。本仪表盘把认知记录拆为来源、范围、置信、D/I/K/W/P、竞争世界模型、价值与负担、预测、行动、结果和修订世界线。主张类P（经验假说）与DIKWP位置P（目的/输入—输出取向）属于不同命名空间。</p><div><span class="pill">Owner: {html.escape(bundle['owner']['owner_id'])}</span><span class="pill">Compilation: {html.escape(bundle['compilation_id'])}</span><span class="pill">External authority: 0</span></div></header>
<main>
<section><h2>透明度向量</h2><p class="sub">导航均值 {audit['navigation_mean']*100:.1f}% 仅用于定位记录缺口。它不是智力、真实、道德、意识、人格或心理健康分数。</p><div class="metrics">{dim_cards}</div></section>
<section><h2>现实校准</h2><div class="summary-grid"><article class="card"><div class="muted">预测 / Predictions</div><div class="big">{cal['prediction_count']}</div></article><article class="card"><div class="muted">已解决 / Resolved</div><div class="big">{cal['resolved_count']}</div></article><article class="card"><div class="muted">平均 Brier</div><div class="big">{cal['mean_brier'] if cal['mean_brier'] is not None else '—'}</div></article><article class="card"><div class="muted">逾期 / Overdue</div><div class="big">{cal['overdue_count']}</div></article></div><div class="boundary">{html.escape(cal['interpretation_boundary'])}</div></section>
<section><h2>认知风险模式</h2><p class="sub">规则仅指出记录结构中的认识论风险，不诊断人。严重度5优先阻断不可逆、未经授权或高外部性行动。</p><div class="table-wrap"><table><thead><tr><th>严重度</th><th>事件</th><th>模式</th><th>透明依据</th></tr></thead><tbody>{issue_rows}</tbody></table></div></section>
<section><h2>24条宇宙本质导向工作规律</h2><p class="sub">规律卡被分别标记为本体工作命题、形式协议、研究假说、经验方法或规范约束；“记录对齐”不等于物理证明。</p><div class="table-wrap"><table><thead><tr><th>ID</th><th>规律</th><th>认识论状态</th><th>记录对齐</th><th>导航</th></tr></thead><tbody>{law_rows}</tbody></table></div></section>
<section><h2>可逆矫正候选</h2><p class="sub">候选不自动应用。具名所有者批准后，只能追加后继事件，原记录与触发依据继续保留。</p><div class="grid">{corr_cards}</div></section>
<section><h2>提升实验</h2><p class="sub">提升以现实反馈、区分性证据、可逆性和负担减少为准，而不是以迎合系统字段为准。</p><div class="grid">{ex_cards}</div></section>
<section><h2>事件索引</h2><div class="table-wrap"><table><thead><tr><th>事件ID</th><th>类型</th><th>类别/位置</th><th>置信</th><th>可见性</th><th>标题</th><th>问题数</th></tr></thead><tbody>{event_rows}</tbody></table></div></section>
<section><h2>边界与责任</h2><div class="grid"><article class="card"><h3>系统不会做什么</h3><ul>{''.join(f'<li>{html.escape(x)}</li>' for x in bundle['claim_boundaries'])}</ul></article><article class="card"><h3>责任交接</h3><p><b>所有者：</b>{html.escape(bundle['responsibility_handoff']['owner_decisions'])}</p><p><b>系统：</b>{html.escape(bundle['responsibility_handoff']['system_preserves'])}</p><p><b>领域验证：</b>{html.escape(bundle['responsibility_handoff']['domain_validation'])}</p></article></div></section>
</main><footer>DIKWP-NOESIS 9.5 · Local-first · Append-only · Owner-governed · Automatic external-action authority 0</footer>
<script type="application/json" id="noesis-data">{data}</script></body></html>'''


def write_event_cards(path: Path, bundle: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["event_id", "title", "kind", "claim_class", "claim_class_namespace", "dikwp", "dikwp_namespace", "visibility", "confidence", "high_impact", "issue_count", "max_issue_severity", "navigation_mean"])
        for row in bundle["audit"]["event_audits"]:
            event = next((e for e in bundle["event_index"] if e.get("event_id") == row["event_id"]), {})
            writer.writerow([row["event_id"], row["title"], row["kind"], row["claim_class"], event.get("claim_class_namespace", "research_book_claim_status"), row["dikwp"], event.get("dikwp_namespace", "semantic_position"), event.get("visibility", "private"), row["confidence"], row["high_impact"], row["issue_count"], row["max_issue_severity"], row["navigation_mean"]])


def write_rendered_outputs(out: Path, bundle: dict[str, Any]) -> None:
    save_text(out / "transparency_report.md", render_report(bundle))
    save_text(out / "enhancement_plan.md", render_enhancement_markdown(bundle["enhancement_plan"]))
    save_text(out / "dashboard.html", render_dashboard(bundle))
    write_event_cards(out / "event_cards.csv", bundle)
    save_json(out / "correction_register.json", {"proposals": bundle["correction_proposals"], "automatic_application": False})
