from __future__ import annotations

from collections import Counter
import re
from typing import Any

from .evidence import evidence_index
from .world_models import assess_event_models

DIMENSIONS = [
    "provenance_traceability", "scope_explicitness", "uncertainty_explicitness",
    "claim_class_discipline", "dikwp_separation", "model_plurality",
    "distinguishing_evidence", "value_visibility", "purpose_executability",
    "affected_world_visibility", "falsifiability", "action_reversibility",
    "reality_contact", "revision_continuity", "residual_preservation", "capacity_context",
]

_CATALOG = {
 "UNSCOPED_UNIVERSAL_CLAIM":(3,"无范围的全称判断","Unscoped universal claim"),
 "FALSE_CERTAINTY":(4,"置信度与可检验支撑不匹配","Confidence exceeds testable support"),
 "EVIDENCE_GAP":(4,"经验或假说主张缺少证据路径","Evidence path missing"),
 "EVIDENCE_REFERENCE_MISSING":(4,"证据引用无法解析","Evidence reference unresolved"),
 "EVIDENCE_INDEPENDENCE_COLLAPSE":(3,"证据依赖链未独立","Evidence independence collapse"),
 "SOURCE_AUTHORITY_OVERREACH":(4,"低直接性来源承担过高结论负荷","Source authority overreach"),
 "SINGLE_MODEL_CLOSURE":(4,"高影响判断由单一模型闭合","Single-model closure"),
 "MODEL_PSEUDO_DIVERSITY":(3,"模型数量增加但结构未分化","Pseudo-diverse models"),
 "VALUE_SMUGGLING":(4,"价值进入决定但未显式登记","Undeclared value insertion"),
 "PURPOSE_OPACITY":(4,"目的缺少可执行契约","Opaque purpose contract"),
 "NO_FALSIFIER":(3,"主张缺少可推翻入口","No falsifier entry point"),
 "CATEGORY_COLLAPSE":(3,"主张类别或DIKWP位置混淆","Claim/D.I.K.W.P category collapse"),
 "OUTCOMELESS_ACTION":(4,"行动缺少结果回流","Action without outcome channel"),
 "HIGH_STAKES_IRREVERSIBLE":(5,"高影响行动不可逆或无回滚","High-impact irreversible action"),
 "COUNTEREVIDENCE_ERASURE":(3,"高置信主张未保留反证或残差","Counterevidence/residual omitted"),
 "REVISION_WITHOUT_LINEAGE":(4,"修订未连接被修订记录","Revision without lineage"),
 "AFFECTED_WORLD_OMISSION":(4,"高影响判断未列出受影响世界","Affected worlds omitted"),
 "STATUS_ASYMMETRY_BLINDNESS":(4,"权力与错误负担未标注","Power/burden asymmetry unrecorded"),
 "FORMAT_AUTHORITY":(3,"形式化表达被误当作外部有效性","Format authority"),
 "IDENTITY_CLAIM_FUSION":(4,"局部状态被固化为身份","Identity claim fusion"),
 "EXTERNAL_ACTION_NOT_AUTHORIZED":(5,"外部行动缺少具名授权","External action lacks named authorization"),
 "CAPACITY_CONTEXT_OMITTED":(3,"高影响判断未记录能力与环境","Capacity/context omitted"),
 "PREDICTION_RESOLUTION_GAP":(3,"预测到期但未回填结果","Prediction resolution gap"),
 "MEMORY_RECONSTRUCTION_UNMARKED":(3,"回忆被当作无损原始记录","Memory reconstruction unmarked"),
 "BURDEN_EXIT_GAP":(4,"负担存在但缺少退出或申诉","Burden without exit/appeal"),
 "SEMANTIC_RETURN_MISSING":(3,"目的或行动缺少语义返回路径","Semantic return path missing"),
 "DISCLOSURE_WITHOUT_CONSENT_REF":(5,"共享或公开记录缺少同意依据","Shared/public record lacks consent reference"),
}

_EXPECTED = {
 "observation":({"E"},{"D"}), "interpretation":({"H","P"},{"I"}),
 "belief":({"P","H","N"},{"K","I"}), "knowledge":({"E","F","P"},{"K"}),
 "wisdom":({"N","H","P"},{"W"}), "purpose":({"N","F"},{"P"}),
 "prediction":({"P"},{"K","W"}), "decision":({"N","P","H"},{"W","P"}),
 "action":({"N","P"},{"P"}), "outcome":({"E"},{"D","I"}),
 "correction":({"E","N","F","H","P"},{"D","I","K","W","P"}), "reflection":({"H","N","P"},{"W","I"}),
 "boundary":({"N","F"},{"P","W"}), "memory":({"E","H"},{"D","I"}),
 "question":({"P","F","H"},{"I","K"}), "model_revision":({"P","H","F"},{"K","W"}),
}


UNIVERSAL = re.compile(r"(所有|任何|永远|绝不|必然|完全|毫无例外|all\b|always\b|never\b|necessarily\b|without exception)",re.I)
IDENTITY = re.compile(r"(我就是|我永远是|我的本质是|天生就是|不可改变|I am always|my essence is|unchangeable)",re.I)
FORMAL = re.compile(r"(定理|证明|公理|公式|方程|theorem|proof|axiom|equation|QED|∀|∃)",re.I)
VALUE = re.compile(r"(应该|必须|正义|公平|善|恶|价值|责任|权利|ought|should|must|justice|fair|right|responsib)",re.I)
QUALIFIER = re.compile(r"(可能|暂时|范围|取决于|尚不确定|假设|候选|could|may|within|conditional|uncertain|hypothes)",re.I)


def _avg(values: list[float], default: float=0.0) -> float:
    return sum(values)/len(values) if values else default


def _scope_score(scope: dict[str,Any]) -> float:
    vals=[bool(scope.get("subjects")),bool(scope.get("contexts")),bool(scope.get("time_horizon")),bool(scope.get("scale")),bool(scope.get("observer_position"))]
    return round(sum(vals)/len(vals),4)


def _purpose_score(p: dict[str,Any]) -> float:
    vals=[bool(p.get("input_state")),bool(p.get("desired_state")),bool(p.get("output")),bool(p.get("success_metrics")),bool(p.get("stop_conditions")),bool(p.get("rollback"))]
    return round(sum(vals)/len(vals),4)


def _issue(code: str, event: dict[str,Any], zh: str, en: str, evidence: dict[str,Any]|None=None, severity: int|None=None) -> dict[str,Any]:
    base=_CATALOG[code]
    return {"issue_id":f"{event['event_id']}::{code}","event_id":event["event_id"],"code":code,"severity":severity or base[0],"title_zh":base[1],"title_en":base[2],"reason_zh":zh,"reason_en":en,"evidence":evidence or {},"diagnostic_boundary":"Transparent epistemic/decision-record pattern; not a clinical or personality diagnosis."}


def audit_event(event: dict[str,Any], evidence_records: list[dict[str,Any]]) -> dict[str,Any]:
    idx=evidence_index(evidence_records); issues=[]; ma=assess_event_models(event); high=ma["high_impact"]
    refs=event.get("evidence_refs",[]); counter=event.get("counterevidence_refs",[])
    resolved=[r for r in refs if r in idx]; missing=[r for r in refs+counter if r not in idx]
    scope=_scope_score(event.get("scope",{})); purpose=_purpose_score(event.get("purpose",{}))
    claims,dikws=_EXPECTED.get(event.get("kind"),({event.get("claim_class")},{event.get("dikwp")}))
    claim_ok=event.get("claim_class") in claims; dikwp_ok=event.get("dikwp") in dikws
    content=event.get("content",""); conf=float(event.get("confidence",.5))
    purpose_rel=event.get("kind") in {"purpose","decision","action"} or event.get("dikwp")=="P"
    value_rel=event.get("kind") in {"wisdom","purpose","decision","action","boundary"} or bool(event.get("values")) or bool(VALUE.search(content))
    action_rel=event.get("kind")=="action" or bool(event.get("action",{}).get("description"))
    affected_rel=high or event.get("action",{}).get("external")

    provenance=1.0
    if event.get("claim_class") in {"E","H","P"}: provenance=1.0 if resolved and not missing else (.35 if resolved else 0.0)
    elif missing: provenance=.25
    uncertainty=1.0 if conf<.85 or event.get("falsifiers") or counter or event.get("open_questions") or QUALIFIER.search(content) else .25
    plurality=(1.0 if ma["has_non_isomorphic_pair"] else 0.0) if high else (1.0 if ma["has_non_isomorphic_pair"] else (.55 if event.get("world_models") else .75))
    distinguish=(min(1.0,ma["distinguishing_test_count"]/2) if high else (1.0 if ma["distinguishing_test_count"] else .75))
    value_vis=1.0 if not value_rel else min(1.0,len(event.get("values",[]))/2)
    affected_vis=1.0 if not affected_rel else min(1.0,len(event.get("affected_worlds",[]))/2)
    fals=1.0 if event.get("claim_class") not in {"E","H","P"} else min(1.0,(len(event.get("falsifiers",[]))+len(event.get("predictions",[])))/2)
    reversible=1.0
    if action_rel: reversible=1.0 if event.get("action",{}).get("reversible") is True and event.get("action",{}).get("rollback") else (.5 if event.get("action",{}).get("reversible") is True else 0.0)
    reality=min(1.0,(len(event.get("predictions",[]))+len(event.get("outcomes",[]))+int(bool(event.get("action",{}).get("result_metric"))))/2)
    if event.get("kind")=="outcome": reality=1.0
    if event.get("claim_class") in {"F","N"} and not action_rel: reality=max(reality,.7)
    revision=1.0 if event.get("kind") not in {"correction","model_revision"} else (1.0 if event.get("supersedes") else 0.0)
    residual=min(1.0,(len(counter)+len(event.get("open_questions",[]))+len(event.get("falsifiers",[])))/3)
    if conf<.7: residual=max(residual,.6)
    capacity=1.0
    if high:
        c=event.get("state_context",{}); vals=[c.get("capacity") not in (None,"","unspecified"),c.get("stress") is not None,c.get("sleep_hours") is not None,bool(c.get("time_pressure") or c.get("environment") or c.get("notes"))]; capacity=sum(vals)/len(vals)
    scores={"provenance_traceability":round(provenance,4),"scope_explicitness":scope,"uncertainty_explicitness":round(uncertainty,4),"claim_class_discipline":1.0 if claim_ok else .2,"dikwp_separation":1.0 if dikwp_ok else .2,"model_plurality":round(plurality,4),"distinguishing_evidence":round(distinguish,4),"value_visibility":round(value_vis,4),"purpose_executability":1.0 if not purpose_rel else purpose,"affected_world_visibility":round(affected_vis,4),"falsifiability":round(fals,4),"action_reversibility":round(reversible,4),"reality_contact":round(reality,4),"revision_continuity":round(revision,4),"residual_preservation":round(residual,4),"capacity_context":round(capacity,4)}

    if UNIVERSAL.search(content) and scope<.6: issues.append(_issue("UNSCOPED_UNIVERSAL_CLAIM",event,"存在全称/必然表达，但观察者、尺度、时间或排除项未充分声明。","Universal wording lacks adequate observer, scale, time or exclusion boundaries.",{"scope_score":scope}))
    if conf>=.95 and not (resolved and (event.get("falsifiers") or counter)): issues.append(_issue("FALSE_CERTAINTY",event,"置信度接近确定，但未同时形成可核验来源与反证入口。","Near-certain confidence lacks both verifiable provenance and a falsifier/counterevidence path.",{"confidence":conf}))
    if event.get("claim_class") in {"E","H","P"} and conf>=.65 and not resolved: issues.append(_issue("EVIDENCE_GAP",event,"中高置信经验/假说主张没有可解析证据。","Medium-high confidence empirical/hypothesis claim has no resolvable evidence."))
    if missing: issues.append(_issue("EVIDENCE_REFERENCE_MISSING",event,"证据ID未出现在证据账本。","Evidence IDs are absent from the evidence ledger.",{"missing_refs":missing}))
    if event.get("visibility", "private") != "private" and not event.get("consent_ref"):
        issues.append(_issue("DISCLOSURE_WITHOUT_CONSENT_REF", event, "记录被标记为可信审阅或公开，但没有可追溯的同意/授权引用。", "The record is marked trusted/public without a traceable consent or authorization reference.", {"visibility": event.get("visibility")}))
    if len(resolved)>=2:
        groups=[idx[r].get("independence_group","unspecified") for r in resolved]
        if len(set(groups))==1: issues.append(_issue("EVIDENCE_INDEPENDENCE_COLLAPSE",event,"多条证据属于同一依赖组，不能按独立复核计权。","Multiple evidence records share one dependency group.",{"group":groups[0]}))
    if conf>=.85 and resolved:
        low=[r for r in resolved if idx[r].get("source_type") in {"model_output","secondary_summary","memory"} or idx[r].get("quality_score",0)<.45]
        if len(low)==len(resolved): issues.append(_issue("SOURCE_AUTHORITY_OVERREACH",event,"全部支撑来源均低直接性，却支撑高置信结论。","All supporting sources are indirect/low-quality while the conclusion is high-confidence.",{"refs":low}))
    if high and not ma["has_non_isomorphic_pair"]: issues.append(_issue("SINGLE_MODEL_CLOSURE",event,"高影响判断缺少两个非同构模型及区分试验。","High-impact judgment lacks two non-isomorphic models and a discriminating test.",{"model_count":ma["model_count"]}))
    elif len(event.get("world_models",[]))>=2 and not ma["has_non_isomorphic_pair"]: issues.append(_issue("MODEL_PSEUDO_DIVERSITY",event,"多个模型的家族、假设或预测仍过于相似。","Several models remain too similar in family, assumptions or predictions."))
    if value_rel and not event.get("values"): issues.append(_issue("VALUE_SMUGGLING",event,"规范性方向存在，但价值、受益者和负担未登记。","Normative direction exists without registered values, beneficiaries and burdens."))
    if purpose_rel and purpose<.5: issues.append(_issue("PURPOSE_OPACITY",event,"目的未形成输入—输出—指标—停止—回滚契约。","Purpose lacks an input-output-metric-stop-rollback contract.",{"purpose_score":purpose}))
    if event.get("claim_class") in {"E","H","P"} and conf>=.7 and not (event.get("falsifiers") or event.get("predictions")): issues.append(_issue("NO_FALSIFIER",event,"主张没有列出可能推翻或区分它的观察。","Claim has no observation that could falsify or distinguish it."))
    if not claim_ok or not dikwp_ok: issues.append(_issue("CATEGORY_COLLAPSE",event,"事件类型与主张类别或DIKWP位置不一致。","Event kind conflicts with claim class or D/I/K/W/P position.",{"expected_claims":sorted(claims),"expected_dikwp":sorted(dikws)}))
    if action_rel and not (event.get("action",{}).get("result_metric") or event.get("predictions") or event.get("outcomes")): issues.append(_issue("OUTCOMELESS_ACTION",event,"行动没有结果指标、预测或结果回填路径。","Action has no outcome metric, prediction or result-return path."))
    if high and action_rel and (event.get("action",{}).get("reversible") is not True or not event.get("action",{}).get("rollback")): issues.append(_issue("HIGH_STAKES_IRREVERSIBLE",event,"高影响行动未证明可逆或没有具体回滚。","High-impact action is not demonstrated reversible or lacks rollback."))
    if conf>=.85 and not (counter or event.get("open_questions") or event.get("falsifiers")): issues.append(_issue("COUNTEREVIDENCE_ERASURE",event,"高置信结论没有保存反证、未决问题或残差。","High-confidence conclusion preserves no counterevidence, open question or residual."))
    if event.get("kind") in {"correction","model_revision"} and not event.get("supersedes"): issues.append(_issue("REVISION_WITHOUT_LINEAGE",event,"修订没有指向先前事件。","Revision does not point to the prior event."))
    if affected_rel and not event.get("affected_worlds"): issues.append(_issue("AFFECTED_WORLD_OMISSION",event,"判断可能影响外部现实，但未建立受影响世界清单。","Judgment may affect external reality but has no affected-world register."))
    if event.get("affected_worlds"):
        blind=[w["stakeholder"] for w in event["affected_worlds"] if w.get("power_position") in {"","unspecified"}]
        if blind: issues.append(_issue("STATUS_ASYMMETRY_BLINDNESS",event,"部分受影响者的权力位置未说明。","Power position of some affected parties is unspecified.",{"stakeholders":blind}))
        noexit=[w["stakeholder"] for w in event["affected_worlds"] if w.get("possible_burden") and not w.get("appeal_or_exit")]
        if noexit: issues.append(_issue("BURDEN_EXIT_GAP",event,"记录了负担但没有申诉、退出或补救。","Burden is recorded without appeal, exit or remedy.",{"stakeholders":noexit}))
    if FORMAL.search(content) and conf>=.85 and event.get("claim_class")!="F" and not resolved: issues.append(_issue("FORMAT_AUTHORITY",event,"形式化语言被用于经验结论但没有独立现实证据。","Formal language is used for an empirical conclusion without independent evidence."))
    if IDENTITY.search(content) and conf>=.8 and scope<.6: issues.append(_issue("IDENTITY_CLAIM_FUSION",event,"局部状态被表达为不可变身份，且缺少时段与条件。","Local state is expressed as immutable identity without temporal/conditional scope."))
    if event.get("action",{}).get("external") and not event.get("action",{}).get("authorization_ref"): issues.append(_issue("EXTERNAL_ACTION_NOT_AUTHORIZED",event,"外部行动没有具名授权；自动外部行动权限固定为0。","External action has no named authorization; automatic authority is zero."))
    if high:
        c=event.get("state_context",{})
        if c.get("capacity") in {"","unspecified"} and c.get("stress") is None and c.get("sleep_hours") is None and not (c.get("time_pressure") or c.get("environment") or c.get("notes")): issues.append(_issue("CAPACITY_CONTEXT_OMITTED",event,"高影响判断未记录疲劳、压力、时间或环境。","High-impact judgment records no fatigue, stress, time or environment."))
    if event.get("kind")=="memory" and conf>=.8 and not (resolved or event.get("state_context",{}).get("notes") or event.get("open_questions")): issues.append(_issue("MEMORY_RECONSTRUCTION_UNMARKED",event,"高置信回忆未与原始记录分离，也未标注重构条件。","High-confidence memory is not separated from primary records or reconstruction context."))
    if purpose_rel and not (event.get("purpose",{}).get("success_metrics") or event.get("action",{}).get("result_metric") or event.get("predictions")): issues.append(_issue("SEMANTIC_RETURN_MISSING",event,"目的或行动无法通过结果返回可比较数据语义。","Purpose/action cannot return through outcomes to comparable data semantics."))

    return {"event_id":event["event_id"],"title":event.get("title"),"kind":event.get("kind"),"claim_class":event.get("claim_class"),"dikwp":event.get("dikwp"),"confidence":conf,"high_impact":high,"transparency_vector":scores,"navigation_mean":round(_avg(list(scores.values())),4),"issue_count":len(issues),"max_issue_severity":max((i["severity"] for i in issues),default=0),"issues":issues,"world_model_assessment":ma,"interpretation_boundary":"Navigation mean is a record-completeness aid, not a truth, intelligence, virtue, consciousness, personality or mental-health score."}


def audit_events(events: list[dict[str,Any]], evidence_records: list[dict[str,Any]], *, calibration: dict[str,Any]|None=None) -> dict[str,Any]:
    rows=[audit_event(e,evidence_records) for e in events]; issues=[i for r in rows for i in r["issues"]]
    if calibration:
        for p in calibration.get("pending",[]):
            if p.get("overdue"):
                event=next((e for e in events if e["event_id"]==p["event_id"]),None)
                if event:
                    i=_issue("PREDICTION_RESOLUTION_GAP",event,"预测已到期但没有结果与来源。","Prediction is overdue without registered outcome and source.",{"prediction_id":p["prediction_id"],"due_at":p.get("due_at")}); issues.append(i)
                    row=next(r for r in rows if r["event_id"]==event["event_id"]); row["issues"].append(i); row["issue_count"]+=1; row["max_issue_severity"]=max(row["max_issue_severity"],i["severity"])
    vector={d:round(_avg([r["transparency_vector"][d] for r in rows]),4) if rows else 0.0 for d in DIMENSIONS}
    sc=Counter(i["severity"] for i in issues); cc=Counter(i["code"] for i in issues)
    return {"event_count":len(events),"event_audits":rows,"transparency_vector":vector,"navigation_mean":round(_avg(list(vector.values())),4),"issues":sorted(issues,key=lambda x:(-x["severity"],x["event_id"],x["code"])),"issue_count":len(issues),"severity_counts":{str(k):v for k,v in sorted(sc.items())},"issue_code_counts":dict(sorted(cc.items(),key=lambda x:(-x[1],x[0]))),"priority_dimensions":[{"dimension":d,"score":s} for d,s in sorted(vector.items(),key=lambda x:(x[1],x[0]))[:5]],"preserved_strengths":[{"dimension":d,"score":s} for d,s in sorted(vector.items(),key=lambda x:(-x[1],x[0]))[:5]],"single_score_prohibited":True,"interpretation_boundary":"Audit evaluates explicitness, traceability, model pluralism, reality contact and reversibility in supplied records. It does not diagnose cognition, mental health, personality, intelligence, morality or consciousness, and cannot infer unrecorded tacit knowledge."}
