from __future__ import annotations

from importlib.resources import files
from typing import Any

from .utils import load_json


def load_law_registry(path: str | None = None) -> dict[str, Any]:
    if path:
        return load_json(path)
    resource = files("dikwp_noesis95.data").joinpath("cosmic_laws.json")
    return __import__("json").loads(resource.read_text(encoding="utf-8"))


def law_summary(registry: dict[str, Any]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for law in registry.get("laws", []):
        status = law.get("epistemic_status", "unknown")
        counts[status] = counts.get(status, 0) + 1
    return {
        "registry_id": registry.get("registry_id"),
        "law_count": len(registry.get("laws", [])),
        "status_counts": counts,
        "boundary": registry.get("boundary"),
        "automatic_external_action_authority": 0,
    }

_LAW_DIMENSIONS = {
    "U01": ["scope_explicitness"],
    "U02": ["revision_continuity", "scope_explicitness"],
    "U03": ["reality_contact"],
    "U04": ["affected_world_visibility", "scope_explicitness"],
    "U05": ["uncertainty_explicitness", "falsifiability"],
    "U06": ["claim_class_discipline", "dikwp_separation"],
    "U07": ["revision_continuity"],
    "U08": ["residual_preservation"],
    "U09": ["provenance_traceability"],
    "U10": ["value_visibility", "affected_world_visibility"],
    "U11": ["purpose_executability"],
    "U12": ["reality_contact", "purpose_executability"],
    "U13": ["residual_preservation"],
    "U14": ["model_plurality", "distinguishing_evidence"],
    "U15": ["reality_contact", "uncertainty_explicitness"],
    "U16": ["revision_continuity", "residual_preservation"],
    "U17": ["scope_explicitness", "revision_continuity"],
    "U18": ["action_reversibility"],
    "U19": ["affected_world_visibility", "value_visibility"],
    "U20": ["affected_world_visibility", "action_reversibility"],
    "U21": ["action_reversibility", "affected_world_visibility"],
    "U22": ["capacity_context"],
    "U23": ["provenance_traceability", "affected_world_visibility"],
    "U24": ["falsifiability", "residual_preservation", "uncertainty_explicitness"],
}

_LAW_ISSUES = {
    "U01": {"UNSCOPED_UNIVERSAL_CLAIM"},
    "U02": {"IDENTITY_CLAIM_FUSION"},
    "U03": {"OUTCOMELESS_ACTION", "SEMANTIC_RETURN_MISSING"},
    "U04": {"AFFECTED_WORLD_OMISSION", "IDENTITY_CLAIM_FUSION"},
    "U05": {"FORMAT_AUTHORITY", "FALSE_CERTAINTY"},
    "U06": {"CATEGORY_COLLAPSE"},
    "U07": {"REVISION_WITHOUT_LINEAGE"},
    "U08": {"COUNTEREVIDENCE_ERASURE"},
    "U09": {"EVIDENCE_GAP", "EVIDENCE_REFERENCE_MISSING"},
    "U10": {"VALUE_SMUGGLING", "BURDEN_EXIT_GAP"},
    "U11": {"PURPOSE_OPACITY"},
    "U12": {"SEMANTIC_RETURN_MISSING"},
    "U13": {"COUNTEREVIDENCE_ERASURE"},
    "U14": {"SINGLE_MODEL_CLOSURE", "MODEL_PSEUDO_DIVERSITY"},
    "U15": {"OUTCOMELESS_ACTION", "PREDICTION_RESOLUTION_GAP", "FALSE_CERTAINTY"},
    "U16": {"MEMORY_RECONSTRUCTION_UNMARKED"},
    "U17": {"IDENTITY_CLAIM_FUSION"},
    "U18": {"HIGH_STAKES_IRREVERSIBLE", "EXTERNAL_ACTION_NOT_AUTHORIZED", "DISCLOSURE_WITHOUT_CONSENT_REF"},
    "U19": {"STATUS_ASYMMETRY_BLINDNESS", "VALUE_SMUGGLING"},
    "U20": {"BURDEN_EXIT_GAP", "AFFECTED_WORLD_OMISSION"},
    "U21": {"HIGH_STAKES_IRREVERSIBLE", "BURDEN_EXIT_GAP"},
    "U22": {"CAPACITY_CONTEXT_OMITTED"},
    "U23": {"SOURCE_AUTHORITY_OVERREACH", "EXTERNAL_ACTION_NOT_AUTHORIZED", "DISCLOSURE_WITHOUT_CONSENT_REF"},
    "U24": {"NO_FALSIFIER", "FALSE_CERTAINTY", "COUNTEREVIDENCE_ERASURE"},
}


def assess_law_alignment(registry: dict[str, Any], audit: dict[str, Any]) -> dict[str, Any]:
    vector = audit.get("transparency_vector", {})
    issue_codes = [i.get("code") for i in audit.get("issues", [])]
    rows = []
    for law in registry.get("laws", []):
        law_id = law["law_id"]
        dims = _LAW_DIMENSIONS.get(law_id, [])
        scores = [float(vector.get(d, 0.0)) for d in dims]
        mean_score = sum(scores) / len(scores) if scores else 0.0
        mapped = _LAW_ISSUES.get(law_id, set())
        issue_hits = sorted({c for c in issue_codes if c in mapped})
        if mean_score >= 0.8 and not issue_hits:
            status = "supported_by_current_records"
        elif mean_score >= 0.5:
            status = "partial_or_mixed"
        else:
            status = "insufficient_record_support"
        rows.append({
            "law_id": law_id,
            "name_zh": law["name_zh"],
            "name_en": law["name_en"],
            "epistemic_status": law["epistemic_status"],
            "record_alignment_status": status,
            "dimension_scores": {d: vector.get(d, 0.0) for d in dims},
            "navigation_mean": round(mean_score, 4),
            "issue_hits": issue_hits,
            "operational_rule": law["operational_rule"],
            "falsifier_entry_points": law["falsifier_entry_points"],
            "retirement_condition": law["retirement_condition"],
        })
    counts: dict[str, int] = {}
    for row in rows:
        counts[row["record_alignment_status"]] = counts.get(row["record_alignment_status"], 0) + 1
    return {
        "registry_id": registry.get("registry_id"),
        "law_count": len(rows),
        "alignment_counts": counts,
        "laws": rows,
        "interpretation_boundary": "Alignment means the supplied cognition records exhibit the protocol features associated with a law card. It does not empirically prove the law as a final cosmic, physical or consciousness law.",
    }
