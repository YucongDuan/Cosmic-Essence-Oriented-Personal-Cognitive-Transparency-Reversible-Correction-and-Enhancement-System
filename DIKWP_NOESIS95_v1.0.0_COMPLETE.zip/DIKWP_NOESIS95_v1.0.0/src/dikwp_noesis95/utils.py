from __future__ import annotations

from datetime import datetime, timezone
from html import escape as html_escape
import hashlib
import json
import math
import re
import unicodedata
from pathlib import Path
from typing import Any, Iterable, Iterator


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_obj(obj: Any) -> str:
    return sha256_text(canonical_json(obj))


def stable_id(prefix: str, obj: Any, length: int = 20) -> str:
    return f"{prefix}-{sha256_obj(obj)[:length]}"


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[\t\r ]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return low
    return max(low, min(high, f))


def parse_iso_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    text = str(value).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path: str | Path, obj: Any) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(p)


def save_text(path: str | Path, text: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return str(p)


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    out: list[dict[str, Any]] = []
    for line_no, raw in enumerate(p.read_text(encoding="utf-8").splitlines(), start=1):
        raw = raw.strip()
        if not raw or raw.startswith("#"):
            continue
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSONL at {p}:{line_no}: {exc}") from exc
        if not isinstance(obj, dict):
            raise ValueError(f"JSONL record at {p}:{line_no} must be an object")
        out.append(obj)
    return out


def append_jsonl(path: str | Path, record: dict[str, Any]) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(canonical_json(record) + "\n")
    return str(p)


def mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values]
    return sum(vals) / len(vals) if vals else 0.0


def safe_sqrt(value: float) -> float:
    return math.sqrt(max(0.0, value))


def html(text: Any) -> str:
    return html_escape(str(text if text is not None else ""), quote=True)


def iter_files(root: str | Path) -> Iterator[Path]:
    base = Path(root)
    for p in sorted(base.rglob("*")):
        if p.is_file():
            yield p

_STOPWORDS = {"the","a","an","and","or","of","to","in","for","on","with","as","is","are","be","by","that","this","it","from","的","了","在","是","为","对","与","和","或","及","将","把","其","这","那","通过","基于"}

def text_tokens(text: str) -> set[str]:
    text = normalize_text(text).lower()
    out: set[str] = set()
    for tok in re.findall(r"[a-z][a-z0-9_\-]{1,}|[\u4e00-\u9fff]{2,}", text):
        if re.fullmatch(r"[\u4e00-\u9fff]+", tok):
            if len(tok) <= 4:
                grams = [tok]
            else:
                grams = [tok[i:i+n] for n in (2,3,4) for i in range(len(tok)-n+1)]
            out.update(g for g in grams if g not in _STOPWORDS)
        elif tok not in _STOPWORDS:
            out.add(tok)
    return out

def flatten_text(value: Any) -> str:
    if value is None: return ""
    if isinstance(value, str): return value
    if isinstance(value, dict): return " ".join(flatten_text(v) for v in value.values())
    if isinstance(value, (list, tuple, set)): return " ".join(flatten_text(v) for v in value)
    return str(value)


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)
