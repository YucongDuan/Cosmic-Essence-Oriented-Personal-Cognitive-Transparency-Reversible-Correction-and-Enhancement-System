"""DIKWP-NOESIS95: owner-governed cognitive transparency and calibration."""

__version__ = "1.0.0"
SYSTEM_NAME = "DIKWP-NOESIS 9.5"
DEFAULT_MODE = "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE"

from .compiler import compile_noesis
from .ledger import append_event, load_ledger, verify_ledger_records
from .exporter import export_transparency_packet
from .diffing import compare_bundles

__all__ = ["compile_noesis", "append_event", "load_ledger", "verify_ledger_records", "export_transparency_packet", "compare_bundles", "SYSTEM_NAME", "DEFAULT_MODE"]
