from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import load_json, sha256_obj


def load_eidos_context(path: str | Path | None, *, expected_owner_id: str | None = None) -> dict[str, Any] | None:
    if not path:
        return None
    bundle = load_json(path)
    if not isinstance(bundle, dict):
        raise ValueError("EIDOS bundle must be an object")
    stored = bundle.get("bundle_digest")
    if stored:
        unsigned = {k: v for k, v in bundle.items() if k != "bundle_digest"}
        valid = sha256_obj(unsigned) == stored
    else:
        valid = False
    owner_id = (bundle.get("owner") or {}).get("owner_id")
    if expected_owner_id and owner_id and owner_id != expected_owner_id:
        raise ValueError(f"EIDOS owner mismatch: {owner_id} != {expected_owner_id}")
    signatures = bundle.get("essence_signatures", {})
    return {
        "source_path": str(Path(path)),
        "eidos_system": bundle.get("system"),
        "compilation_id": bundle.get("compilation_id"),
        "bundle_digest": stored,
        "digest_valid": valid,
        "owner_id": owner_id,
        "signature_keys": sorted(signatures.keys()) if isinstance(signatures, dict) else [],
        "essence_signatures": signatures,
        "world_models": bundle.get("world_models", []),
        "mesh95_audit": bundle.get("mesh95_audit", {}),
        "source_count": len(bundle.get("source_ledger", [])),
        "claim_boundaries": bundle.get("claim_boundaries", []),
        "integration_boundary": "EIDOS context is treated as a source-grounded prior map of accumulated content, not as a psychological identity, immutable essence or authority that overrides new evidence.",
    }
