from __future__ import annotations

from pathlib import Path
from typing import Any

from .ledger import load_ledger, verify_ledger_records
from .utils import load_json, sha256_bytes, sha256_obj


def verify_output_dir(path: str | Path) -> dict[str, Any]:
    root = Path(path)
    failures = []
    manifest = load_json(root / "MANIFEST.json")
    checked = 0
    for rel, expected in manifest.get("files", {}).items():
        p = root / rel
        if not p.exists():
            failures.append({"path": rel, "reason": "MISSING"})
            continue
        actual = sha256_bytes(p.read_bytes())
        checked += 1
        if actual != expected:
            failures.append({"path": rel, "reason": "DIGEST_MISMATCH", "expected": expected, "actual": actual})
    if sha256_obj(manifest.get("files", {})) != manifest.get("manifest_digest"):
        failures.append({"path": "MANIFEST.json", "reason": "MANIFEST_DIGEST_MISMATCH"})
    bundle = load_json(root / "noesis_bundle.json")
    stored = bundle.pop("bundle_digest", None)
    if sha256_obj(bundle) != stored:
        failures.append({"path": "noesis_bundle.json", "reason": "BUNDLE_DIGEST_MISMATCH"})
    try:
        records = load_ledger(root / "ledger_snapshot.jsonl", verify=False)
        ledger_report = verify_ledger_records(records)
        if not ledger_report["valid"]:
            failures.append({"path": "ledger_snapshot.jsonl", "reason": "LEDGER_INVALID", "failures": ledger_report["failures"]})
        expected_head = load_json(root / "OUTPUT_INFO.json").get("ledger_head_digest")
        if ledger_report["head_digest"] != expected_head:
            failures.append({"path": "ledger_snapshot.jsonl", "reason": "LEDGER_HEAD_MISMATCH", "expected": expected_head, "actual": ledger_report["head_digest"]})
    except Exception as exc:
        ledger_report = {"valid": False, "checked": 0, "failures": [{"reason": str(exc)}]}
        failures.append({"path": "ledger_snapshot.jsonl", "reason": "LEDGER_READ_FAILURE", "detail": str(exc)})
    return {
        "valid": not failures,
        "checked_files": checked,
        "ledger": ledger_report,
        "failures": failures,
        "untracked_files": manifest.get("untracked_files", []),
        "manifest_scope": manifest.get("scope"),
        "automatic_external_action_authority": 0,
    }
