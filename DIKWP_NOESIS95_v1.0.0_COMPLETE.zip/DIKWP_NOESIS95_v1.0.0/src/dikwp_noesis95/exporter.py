from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from .utils import load_json, save_json, sha256_obj, utc_now

_VISIBILITY_RANK = {"private": 0, "trusted_reviewer": 1, "public": 2}


def _allowed(item_visibility: str, audience: str) -> bool:
    # Owner sees everything; trusted reviewers see trusted/public; public sees public only.
    if audience == "owner":
        return True
    threshold = 1 if audience == "trusted_reviewer" else 2
    return _VISIBILITY_RANK.get(item_visibility or "private", 0) >= threshold


def _sanitize_event(event: dict[str, Any]) -> dict[str, Any]:
    row = deepcopy(event)
    row.pop("owner_only_notes", None)
    # Hash-chain fields are retained for provenance, but the export is explicitly a filtered view,
    # not itself a complete ledger and therefore cannot be chain-verified in isolation.
    return row


def export_transparency_packet(
    bundle: dict[str, Any] | str | Path,
    out_path: str | Path,
    *,
    audience: str = "public",
    include_display_name: bool = False,
) -> dict[str, Any]:
    if audience not in {"owner", "trusted_reviewer", "public"}:
        raise ValueError("audience must be owner/trusted_reviewer/public")
    source = load_json(bundle) if isinstance(bundle, (str, Path)) else deepcopy(bundle)
    events = [_sanitize_event(e) for e in source.get("event_index", []) if _allowed(e.get("visibility", "private"), audience)]
    event_ids = {e.get("event_id") for e in events}
    referenced = {r for e in events for r in e.get("evidence_refs", []) + e.get("counterevidence_refs", [])}
    evidence = [
        deepcopy(e) for e in source.get("evidence_ledger", [])
        if e.get("evidence_id") in referenced and _allowed(e.get("visibility", "private"), audience)
    ]
    evidence_ids = {e.get("evidence_id") for e in evidence}
    unresolved_after_filter = sorted(referenced - evidence_ids)
    owner = source.get("owner", {})
    owner_export = {
        "owner_id": owner.get("owner_id"),
        "display_name": owner.get("display_name") if include_display_name or audience == "owner" else "",
        "scope_notice": owner.get("scope_notice", ""),
        "automatic_external_action_authority": 0,
    }
    audit = source.get("audit", {})
    filtered_issues = [deepcopy(i) for i in audit.get("issues", []) if i.get("event_id") in event_ids]
    corrections = [deepcopy(p) for p in source.get("correction_proposals", []) if p.get("event_id") in event_ids]
    packet = {
        "system": source.get("system"),
        "version": source.get("version"),
        "exported_at": utc_now(),
        "audience": audience,
        "source_compilation_id": source.get("compilation_id"),
        "source_bundle_digest": source.get("bundle_digest"),
        "owner": owner_export,
        "events": events,
        "evidence": evidence,
        "filtered_audit": {
            "issue_count": len(filtered_issues),
            "issues": filtered_issues,
            "interpretation_boundary": audit.get("interpretation_boundary"),
            "single_score_prohibited": True,
        },
        "correction_proposals": corrections,
        "law_registry_summary": source.get("law_registry_summary"),
        "claim_boundaries": source.get("claim_boundaries", []),
        "unresolved_evidence_after_visibility_filter": unresolved_after_filter,
        "export_boundary": (
            "This packet is a selective owner-governed view. Missing records may be private, withheld, "
            "not recorded or outside scope; absence is not consent, falsehood or evidence of deficiency. "
            "A filtered packet is not a complete hash-chain ledger and grants no identity, clinical, commercial, "
            "employment, legal or external-action authority."
        ),
        "automatic_external_action_authority": 0,
    }
    packet["export_digest"] = sha256_obj(packet)
    save_json(out_path, packet)
    return packet
