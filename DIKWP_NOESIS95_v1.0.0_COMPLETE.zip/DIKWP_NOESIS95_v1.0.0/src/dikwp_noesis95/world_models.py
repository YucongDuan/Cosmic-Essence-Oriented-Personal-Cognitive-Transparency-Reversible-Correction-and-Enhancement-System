from __future__ import annotations

from itertools import combinations
from typing import Any

from .utils import jaccard, text_tokens

HIGH_IMPACT_KINDS = {"decision", "action", "purpose", "model_revision", "correction"}
HIGH_IMPACT_TAGS = {"high-impact", "high_stakes", "high-stakes", "medical", "legal", "financial", "safety", "identity"}


def is_high_impact(event: dict[str, Any]) -> bool:
    tags = {str(t).lower() for t in event.get("tags", [])}
    if event.get("kind") in HIGH_IMPACT_KINDS and (event.get("action", {}).get("external") or event.get("affected_worlds")):
        return True
    return bool(tags & HIGH_IMPACT_TAGS)


def model_pair_assessment(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    family_distinct = (a.get("model_type") or "unspecified") != (b.get("model_type") or "unspecified")
    claim_similarity = jaccard(text_tokens(a.get("claim", "")), text_tokens(b.get("claim", "")))
    assumption_similarity = jaccard(
        text_tokens(" ".join(a.get("assumptions", []))),
        text_tokens(" ".join(b.get("assumptions", []))),
    )
    discriminator_a = set(a.get("discriminators", []))
    discriminator_b = set(b.get("discriminators", []))
    discriminator_distinct = bool(discriminator_a or discriminator_b) and discriminator_a != discriminator_b
    non_isomorphic = family_distinct and claim_similarity < 0.72 and (assumption_similarity < 0.78 or discriminator_distinct)
    return {
        "model_a": a.get("model_id"),
        "model_b": b.get("model_id"),
        "family_distinct": family_distinct,
        "claim_similarity": round(claim_similarity, 4),
        "assumption_similarity": round(assumption_similarity, 4),
        "discriminator_distinct": discriminator_distinct,
        "non_isomorphic": non_isomorphic,
    }


def assess_event_models(event: dict[str, Any]) -> dict[str, Any]:
    models = event.get("world_models", [])
    pairs = [model_pair_assessment(a, b) for a, b in combinations(models, 2)]
    has_non_isomorphic_pair = any(p["non_isomorphic"] for p in pairs)
    distinguishing_tests = sorted({x for m in models for x in m.get("discriminators", [])})
    return {
        "event_id": event.get("event_id"),
        "high_impact": is_high_impact(event),
        "model_count": len(models),
        "model_families": sorted({m.get("model_type", "unspecified") for m in models}),
        "pair_assessments": pairs,
        "has_non_isomorphic_pair": has_non_isomorphic_pair,
        "distinguishing_test_count": len(distinguishing_tests),
        "distinguishing_tests": distinguishing_tests,
        "sufficient_for_high_impact": (not is_high_impact(event)) or has_non_isomorphic_pair,
    }


def assess_world_models(events: list[dict[str, Any]]) -> dict[str, Any]:
    rows = [assess_event_models(event) for event in events]
    required = [r for r in rows if r["high_impact"]]
    sufficient = [r for r in required if r["sufficient_for_high_impact"]]
    return {
        "event_assessments": rows,
        "high_impact_event_count": len(required),
        "high_impact_with_non_isomorphic_models": len(sufficient),
        "coverage": round(len(sufficient) / len(required), 4) if required else 1.0,
        "rule": "High-impact events require at least two materially different world models with a distinguishing test; wording variants do not count as pluralism.",
    }
