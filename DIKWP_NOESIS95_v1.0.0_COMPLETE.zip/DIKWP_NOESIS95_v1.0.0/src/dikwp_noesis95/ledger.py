from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
from typing import Any, Iterable

from .utils import canonical_json, clamp, normalize_text, read_jsonl, sha256_text, stable_id, utc_now

ALLOWED_EVENT_KINDS = {"observation","interpretation","belief","knowledge","wisdom","purpose","prediction","decision","action","outcome","correction","reflection","boundary","memory","question","model_revision"}
ALLOWED_CLAIM_CLASSES = {"E","H","F","P","N"}
ALLOWED_DIKWP = {"D","I","K","W","P"}
ALLOWED_STATUS = {"active","tentative","retired","superseded","disputed"}
ALLOWED_VISIBILITY = {"private", "trusted_reviewer", "public"}
CLAIM_CLASS_MEANINGS = {
    "E": "established_or_source_bound_result",
    "H": "historical_interpretation",
    "F": "formal_or_relational_construction",
    "P": "empirical_hypothesis",
    "N": "normative_or_metaphysical_proposal",
}
DIKWP_MEANINGS = {
    "D": "data_or_same_semantics",
    "I": "information_or_different_semantics",
    "K": "knowledge_or_complete_semantics",
    "W": "wisdom_or_value_configuration",
    "P": "purpose_or_input_output_orientation",
}


def _strings(value: Any) -> list[str]:
    if value is None: return []
    if isinstance(value, str): value = [value]
    if not isinstance(value, list): raise ValueError("Expected string or list")
    return [normalize_text(x) for x in value if normalize_text(x)]


def _scope(value: Any) -> dict[str, Any]:
    if value is None: value = {}
    if isinstance(value, str): value = {"contexts":[value]}
    if not isinstance(value, dict): raise ValueError("scope must be an object")
    return {"subjects":_strings(value.get("subjects")),"contexts":_strings(value.get("contexts")),"time_horizon":normalize_text(value.get("time_horizon","")),"scale":normalize_text(value.get("scale","")),"observer_position":normalize_text(value.get("observer_position","")),"exclusions":_strings(value.get("exclusions"))}


def _world_models(value: Any) -> list[dict[str, Any]]:
    if not value: return []
    if not isinstance(value, list): raise ValueError("world_models must be a list")
    out=[]
    for i,m in enumerate(value,1):
        if isinstance(m,str): m={"claim":m}
        if not isinstance(m,dict): raise ValueError("world model must be object or string")
        claim=normalize_text(m.get("claim",""))
        if not claim: continue
        typ=normalize_text(m.get("model_type",m.get("family","unspecified"))) or "unspecified"
        out.append({"model_id":normalize_text(m.get("model_id","")) or stable_id("wm",{"claim":claim,"type":typ,"i":i},16),"name":normalize_text(m.get("name",f"World model {i}")),"model_type":typ,"claim":claim,"assumptions":_strings(m.get("assumptions")),"predictions":_strings(m.get("predictions")),"discriminators":_strings(m.get("discriminators")),"failure_modes":_strings(m.get("failure_modes")),"confidence":clamp(m.get("confidence",.5))})
    return out


def _values(value: Any) -> list[dict[str, Any]]:
    if not value: return []
    if not isinstance(value,list): raise ValueError("values must be a list")
    out=[]
    for item in value:
        if isinstance(item,str): item={"name":item}
        if not isinstance(item,dict): raise ValueError("value must be object or string")
        name=normalize_text(item.get("name",""))
        if name: out.append({"name":name,"weight":clamp(item.get("weight",.5)),"beneficiaries":_strings(item.get("beneficiaries")),"burden_bearers":_strings(item.get("burden_bearers")),"measurement":normalize_text(item.get("measurement","")),"conflicts":_strings(item.get("conflicts"))})
    return out


def _affected(value: Any) -> list[dict[str, Any]]:
    if not value: return []
    if not isinstance(value,list): raise ValueError("affected_worlds must be a list")
    out=[]
    for item in value:
        if isinstance(item,str): item={"stakeholder":item}
        if not isinstance(item,dict): raise ValueError("affected world must be object or string")
        who=normalize_text(item.get("stakeholder",""))
        if who: out.append({"stakeholder":who,"expected_benefit":normalize_text(item.get("expected_benefit","")),"possible_burden":normalize_text(item.get("possible_burden","")),"consent_status":normalize_text(item.get("consent_status","unknown")) or "unknown","appeal_or_exit":normalize_text(item.get("appeal_or_exit","")),"power_position":normalize_text(item.get("power_position","unspecified")) or "unspecified"})
    return out


def _predictions(value: Any, seed: dict[str,Any]) -> list[dict[str,Any]]:
    if not value: return []
    if not isinstance(value,list): raise ValueError("predictions must be a list")
    out=[]
    for i,item in enumerate(value,1):
        if isinstance(item,str): item={"statement":item}
        if not isinstance(item,dict): raise ValueError("prediction must be object or string")
        statement=normalize_text(item.get("statement",""))
        if not statement: continue
        p=float(item.get("probability",.5))
        if not 0<=p<=1: raise ValueError("prediction probability must be 0..1")
        out.append({"prediction_id":normalize_text(item.get("prediction_id","")) or stable_id("pred",{"seed":seed,"statement":statement,"i":i},18),"statement":statement,"probability":p,"due_at":normalize_text(item.get("due_at","")),"outcome_definition":normalize_text(item.get("outcome_definition","")),"resolution_source_required":bool(item.get("resolution_source_required",True)),"tags":_strings(item.get("tags"))})
    return out


def _outcomes(value: Any) -> list[dict[str,Any]]:
    if not value: return []
    if not isinstance(value,list): raise ValueError("outcomes must be a list")
    out=[]
    for item in value:
        if not isinstance(item,dict) or not item.get("prediction_id"): raise ValueError("outcome requires prediction_id")
        observed=item.get("observed")
        if observed not in (0,1,False,True,0.0,1.0): raise ValueError("outcome observed must be binary")
        out.append({"prediction_id":normalize_text(item["prediction_id"]),"observed":int(bool(observed)),"observed_at":normalize_text(item.get("observed_at","")),"evidence_refs":_strings(item.get("evidence_refs")),"notes":normalize_text(item.get("notes",""))})
    return out




def _correction_metadata(value: Any) -> dict[str, Any]:
    if not value:
        return {}
    if not isinstance(value, dict):
        raise ValueError("correction_metadata must be an object")
    return {
        "proposal_id": normalize_text(value.get("proposal_id", "")),
        "approver": normalize_text(value.get("approver", "")),
        "authorization_ref": normalize_text(value.get("authorization_ref", "")),
        "proposal_digest": normalize_text(value.get("proposal_digest", "")),
        "original_event_digest": normalize_text(value.get("original_event_digest", "")),
    }

def normalize_event(event: dict[str,Any], *, owner_id: str|None=None) -> dict[str,Any]:
    if not isinstance(event,dict): raise ValueError("Event must be an object")
    content=normalize_text(event.get("content",""))
    if not content: raise ValueError("Event content is required")
    kind=normalize_text(event.get("kind","belief")).lower()
    claim=normalize_text(event.get("claim_class","H")).upper()
    dikwp=normalize_text(event.get("dikwp","K")).upper()
    status=normalize_text(event.get("status","active")).lower()
    if kind not in ALLOWED_EVENT_KINDS: raise ValueError(f"Unknown event kind: {kind}")
    if claim not in ALLOWED_CLAIM_CLASSES: raise ValueError("claim_class must be E/H/F/P/N")
    if dikwp not in ALLOWED_DIKWP: raise ValueError("dikwp must be D/I/K/W/P")
    if status not in ALLOWED_STATUS: raise ValueError("unknown status")
    conf=float(event.get("confidence",.5))
    if not 0<=conf<=1: raise ValueError("confidence must be 0..1")
    oid=normalize_text(event.get("owner_id",owner_id or ""))
    if not oid: raise ValueError("owner_id is required")
    created=normalize_text(event.get("created_at","")) or utc_now()
    seed={"owner_id":oid,"created_at":created,"kind":kind,"content":content}
    purpose=event.get("purpose") or {}; action=event.get("action") or {}; state=event.get("state_context") or {}
    if isinstance(purpose,str): purpose={"desired_state":purpose}
    if isinstance(action,str): action={"description":action}
    if not isinstance(purpose,dict) or not isinstance(action,dict) or not isinstance(state,dict): raise ValueError("purpose/action/state_context must be objects")
    visibility=normalize_text(event.get("visibility", "private")).lower() or "private"
    if visibility not in ALLOWED_VISIBILITY:
        raise ValueError("visibility must be private/trusted_reviewer/public")
    return {"event_id":normalize_text(event.get("event_id","")) or stable_id("evt",seed,20),"owner_id":oid,"created_at":created,"kind":kind,"title":normalize_text(event.get("title","")) or content[:80],"content":content,"claim_class":claim,"claim_class_namespace":"research_book_claim_status","claim_class_meaning":CLAIM_CLASS_MEANINGS[claim],"dikwp":dikwp,"dikwp_namespace":"semantic_position","dikwp_meaning":DIKWP_MEANINGS[dikwp],"dikwp_secondary":[x.upper() for x in _strings(event.get("dikwp_secondary")) if x.upper() in ALLOWED_DIKWP],"confidence":conf,"scope":_scope(event.get("scope")),"evidence_refs":_strings(event.get("evidence_refs")),"counterevidence_refs":_strings(event.get("counterevidence_refs")),"world_models":_world_models(event.get("world_models")),"values":_values(event.get("values")),"purpose":{"input_state":normalize_text(purpose.get("input_state","")),"desired_state":normalize_text(purpose.get("desired_state","")),"output":normalize_text(purpose.get("output","")),"success_metrics":_strings(purpose.get("success_metrics")),"time_horizon":normalize_text(purpose.get("time_horizon","")),"stop_conditions":_strings(purpose.get("stop_conditions")),"rollback":normalize_text(purpose.get("rollback",""))},"affected_worlds":_affected(event.get("affected_worlds")),"falsifiers":_strings(event.get("falsifiers")),"open_questions":_strings(event.get("open_questions")),"predictions":_predictions(event.get("predictions"),seed),"outcomes":_outcomes(event.get("outcomes")),"action":{"description":normalize_text(action.get("description","")),"reversible":action.get("reversible") if action.get("reversible") in (True,False) else None,"rollback":normalize_text(action.get("rollback","")),"external":bool(action.get("external",False)),"authorization_ref":normalize_text(action.get("authorization_ref","")),"result_metric":normalize_text(action.get("result_metric",""))},"state_context":{"capacity":normalize_text(state.get("capacity","unspecified")) or "unspecified","stress":state.get("stress"),"sleep_hours":state.get("sleep_hours"),"time_pressure":normalize_text(state.get("time_pressure","")),"environment":normalize_text(state.get("environment","")),"notes":normalize_text(state.get("notes",""))},"supersedes":_strings(event.get("supersedes")),"status":status,"tags":_strings(event.get("tags")),"source_language":normalize_text(event.get("source_language","")),"visibility":visibility,"consent_ref":normalize_text(event.get("consent_ref","")),"retention_review_at":normalize_text(event.get("retention_review_at","")),"redaction_tags":_strings(event.get("redaction_tags")),"owner_annotations":_strings(event.get("owner_annotations")),"owner_only_notes":_strings(event.get("owner_only_notes")),"correction_metadata":_correction_metadata(event.get("correction_metadata"))}



def derive_current_view(records: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """Derive the present cognitive view without deleting the append-only worldline.

    An active or disputed successor effectively supersedes the records it names.
    A tentative successor remains visible beside its predecessor until explicitly
    activated. Retired/superseded records remain in history but not in the present
    view. This is a record-state rule, not a judgment about the person.
    """
    rows = list(records)
    known_ids = {row.get("event_id") for row in rows}
    superseded_by: dict[str, list[str]] = {}
    dangling: list[dict[str, str]] = []
    self_refs: list[str] = []
    effective_successor_statuses = {"active", "disputed"}
    for row in rows:
        successor_id = row.get("event_id", "")
        for prior in row.get("supersedes", []):
            if prior == successor_id:
                self_refs.append(successor_id)
                continue
            if prior not in known_ids:
                dangling.append({"successor_event_id": successor_id, "missing_event_id": prior})
                continue
            if row.get("status") in effective_successor_statuses:
                superseded_by.setdefault(prior, []).append(successor_id)
    for prior in superseded_by:
        superseded_by[prior] = sorted(set(superseded_by[prior]))
    effective_superseded = set(superseded_by)
    current = [
        row for row in rows
        if row.get("event_id") not in effective_superseded
        and row.get("status") not in {"retired", "superseded"}
    ]
    state = {
        "historical_event_count": len(rows),
        "current_event_count": len(current),
        "current_event_ids": [row.get("event_id") for row in current],
        "effectively_superseded_event_ids": sorted(effective_superseded),
        "superseded_by": dict(sorted(superseded_by.items())),
        "tentative_event_ids": [row.get("event_id") for row in rows if row.get("status") == "tentative"],
        "disputed_event_ids": [row.get("event_id") for row in rows if row.get("status") == "disputed"],
        "retired_event_ids": [row.get("event_id") for row in rows if row.get("status") in {"retired", "superseded"}],
        "dangling_supersedes": dangling,
        "self_supersedes": sorted(set(self_refs)),
        "current_view_rule": (
            "Active/disputed successors displace named predecessors from the current view; "
            "tentative successors do not. Retired/superseded records remain in the immutable history."
        ),
        "interpretation_boundary": (
            "Current-view membership is a ledger lifecycle state, not a score of truth, worth, identity, "
            "mental health, intelligence or consciousness. Historical records remain available for accountability."
        ),
    }
    return {"current_events": current, "state": state}

def verify_ledger_records(records: Iterable[dict[str,Any]]) -> dict[str,Any]:
    failures=[]; prev="GENESIS"; seen=set(); checked=0
    for seq,r in enumerate(records,1):
        checked+=1
        if r.get("event_id") in seen: failures.append({"seq":seq,"reason":"DUPLICATE_EVENT_ID","event_id":r.get("event_id")})
        seen.add(r.get("event_id"))
        if r.get("ledger_seq")!=seq: failures.append({"seq":seq,"reason":"SEQUENCE_MISMATCH"})
        if r.get("previous_digest")!=prev: failures.append({"seq":seq,"reason":"PREVIOUS_DIGEST_MISMATCH"})
        unsigned={k:v for k,v in r.items() if k!="event_digest"}
        actual=sha256_text(canonical_json(unsigned))
        if r.get("event_digest")!=actual: failures.append({"seq":seq,"reason":"EVENT_DIGEST_MISMATCH","actual":actual})
        prev=r.get("event_digest","")
    return {"valid":not failures,"checked":checked,"head_digest":prev,"failures":failures}


def load_ledger(path: str|Path, *, verify: bool=True) -> list[dict[str,Any]]:
    records=read_jsonl(path)
    if verify:
        report=verify_ledger_records(records)
        if not report["valid"]: raise ValueError(f"Ledger verification failed: {report['failures'][:3]}")
    return records


def initialize_ledger(path: str|Path, *, overwrite: bool=False) -> str:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() and p.stat().st_size and not overwrite: raise FileExistsError(f"Ledger already exists: {p}")
    p.write_text("",encoding="utf-8"); return str(p)


def append_event(path: str|Path, event: dict[str,Any], *, owner_id: str|None=None) -> dict[str,Any]:
    p=Path(path); records=load_ledger(p) if p.exists() else []
    normalized=normalize_event(event,owner_id=owner_id)
    if any(r.get("event_id")==normalized["event_id"] for r in records): raise ValueError(f"Duplicate event_id: {normalized['event_id']}")
    if normalized["event_id"] in normalized.get("supersedes", []):
        raise ValueError("An event cannot supersede itself")
    known_ids = {r.get("event_id") for r in records}
    missing_supersedes = sorted(set(normalized.get("supersedes", [])) - known_ids)
    if missing_supersedes:
        raise ValueError(f"supersedes references must already exist in the ledger: {missing_supersedes}")
    record=deepcopy(normalized); record["ledger_seq"]=len(records)+1; record["previous_digest"]=records[-1]["event_digest"] if records else "GENESIS"; record["recorded_at"]=utc_now(); record["event_digest"]=sha256_text(canonical_json(record))
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("a",encoding="utf-8",newline="\n") as f: f.write(json.dumps(record,ensure_ascii=False,sort_keys=True)+"\n")
    return record


def rebuild_ledger(events: Iterable[dict[str,Any]], path: str|Path, *, owner_id: str|None=None, overwrite: bool=False) -> list[dict[str,Any]]:
    p=Path(path)
    if p.exists() and p.stat().st_size and not overwrite: raise FileExistsError(f"Refusing to overwrite: {p}")
    initialize_ledger(p,overwrite=True); out=[]
    for e in events: out.append(append_event(p,e,owner_id=owner_id))
    return out


def ledger_from_json(path: str|Path, output: str|Path, *, owner_id: str|None=None, overwrite: bool=False) -> list[dict[str,Any]]:
    data=json.loads(Path(path).read_text(encoding="utf-8")); data=data.get("events",[]) if isinstance(data,dict) else data
    if not isinstance(data,list): raise ValueError("Input JSON must be list or {events:[]}")
    return rebuild_ledger(data,output,owner_id=owner_id,overwrite=overwrite)
