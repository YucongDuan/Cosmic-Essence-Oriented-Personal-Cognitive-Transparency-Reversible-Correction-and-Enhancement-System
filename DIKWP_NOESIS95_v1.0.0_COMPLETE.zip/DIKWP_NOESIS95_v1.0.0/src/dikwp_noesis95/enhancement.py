from __future__ import annotations

from typing import Any

from .utils import stable_id, utc_now

_EXERCISES: dict[str, dict[str, Any]] = {
    "provenance_traceability": {
        "name_zh": "来源三角测量", "name_en": "Provenance triangulation",
        "protocol": ["选择一个中高置信主张。", "分别寻找直接记录、独立来源和最强反证。", "标注依赖组与证据质量，不按数量重复计权。", "重新登记置信度和仍未解释的残差。"],
        "metric": "可解析证据率、独立来源组数、反证保留率",
    },
    "scope_explicitness": {
        "name_zh": "观察者—尺度—时间换位", "name_en": "Observer-scale-time shift",
        "protocol": ["写出当前观察者位置与利益关系。", "把同一主张分别放到个体、组织、社会和长期尺度。", "列出哪些结论保持、哪些反转。", "用最小充分范围重写主张。"],
        "metric": "范围字段完整率、跨尺度反转发现数",
    },
    "uncertainty_explicitness": {
        "name_zh": "置信度—反例同步更新", "name_en": "Confidence-counterexample coupling",
        "protocol": ["给主张分配0–1概率。", "预写一条上调条件和一条下调条件。", "主动寻找一条会令你不舒服的反例。", "观察后按预先规则更新，不修改原始概率。"],
        "metric": "预先更新规则覆盖率、过度自信差、Brier分数",
    },
    "claim_class_discipline": {
        "name_zh": "E/H/F/P/N分层", "name_en": "E/H/F/P/N separation",
        "protocol": ["把文本切成经验、假说、形式定义、方案和规范五类。", "任何一句承担多类功能时拆分。", "分别写出每类可接受的验证方式。", "检查形式正确是否被偷换为经验真实或规范正当。"],
        "metric": "跨类混淆事件数、分类复核一致率",
    },
    "dikwp_separation": {
        "name_zh": "DIKWP语义往返", "name_en": "DIKWP semantic round trip",
        "protocol": ["记录原始D。", "说明D如何关系化为I、稳定为K、进入W并服务P。", "执行最小行动并得到新D。", "比较起点与返回数据，登记不可等价残差。"],
        "metric": "完整路径率、往返残差、位置混淆数",
    },
    "model_plurality": {
        "name_zh": "非同构模型对决", "name_en": "Non-isomorphic model duel",
        "protocol": ["为同一问题建立机制不同的两个模型。", "禁止只更换措辞。", "写出它们会给出相反更新的可观察结果。", "优先执行负担最小且区分度最大的试验。"],
        "metric": "非同构模型覆盖率、区分试验完成率、模型退役率",
    },
    "distinguishing_evidence": {
        "name_zh": "信息增益优先试验", "name_en": "Information-gain-first test",
        "protocol": ["列出竞争模型共同预测与分歧预测。", "选择分歧最大且可逆的观察。", "预先定义每个结果如何更新模型。", "记录未能区分的原因。"],
        "metric": "区分结果比例、每单位负担的信息增益",
    },
    "value_visibility": {
        "name_zh": "价值—负担双账本", "name_en": "Value-burden dual ledger",
        "protocol": ["列出价值与受益者。", "列出成本、错误和维护债由谁承担。", "进行角色反转审查。", "把被负担者的拒绝、申诉和退出写入方案。"],
        "metric": "价值显式率、负担承担者覆盖率、退出通道测试率",
    },
    "purpose_executability": {
        "name_zh": "目的编译", "name_en": "Purpose compilation",
        "protocol": ["把愿望改写为当前状态→期望状态。", "指定输出、阈值、期限。", "写出停止与回滚条件。", "让第三方仅凭记录判断成功或失败。"],
        "metric": "目的契约完整率、模糊目标数、停止条件触发合规率",
    },
    "affected_world_visibility": {
        "name_zh": "受影响世界映射", "name_en": "Affected-world mapping",
        "protocol": ["列出直接、间接和未来受影响者。", "分别写利益、负担、权力位置。", "加入最不共享你的利益的一方。", "定义申诉、退出、补救和责任交接。"],
        "metric": "受影响方覆盖率、异议方纳入率、补救路径完整率",
    },
    "falsifiability": {
        "name_zh": "先写失败条件", "name_en": "Failure-first protocol",
        "protocol": ["在继续论证前写出主张失败的可观察条件。", "写出竞争模型对此结果的解释。", "设定何时降低置信度或退役模型。", "结果出现时按规则执行。"],
        "metric": "带反证入口主张比例、按规则退役率",
    },
    "action_reversibility": {
        "name_zh": "最小可逆试点", "name_en": "Minimum reversible pilot",
        "protocol": ["把行动缩小到最小现实接触。", "明确回滚负责人、触发器和恢复状态。", "先演练回滚。", "只有在负担与信息增益达标时升级。"],
        "metric": "回滚演练成功率、不可逆暴露量、升级前证据增量",
    },
    "reality_contact": {
        "name_zh": "预测—行动—结果闭环", "name_en": "Prediction-action-outcome loop",
        "protocol": ["为关键判断给出概率和到期日。", "执行经授权的最小行动或观察。", "无论结果是否有利都回填。", "计算Brier分数并更新模型而非改写历史。"],
        "metric": "预测解决率、Brier分数、逾期率、结果回填完整率",
    },
    "revision_continuity": {
        "name_zh": "认知世界线复盘", "name_en": "Cognitive worldline review",
        "protocol": ["每次修订指向旧事件。", "分别记录改变、保留和触发证据。", "说明旧模型何时仍有效。", "登记新模型的退役条件。"],
        "metric": "修订血缘完整率、静默覆盖数、模型退役理由完整率",
    },
    "residual_preservation": {
        "name_zh": "Ω残差日志", "name_en": "Omega residual journal",
        "protocol": ["记录异常、矛盾、低频案例和无法翻译部分。", "禁止把残差自动归为噪声。", "每周期选择一个残差建立新模型。", "标记哪些残差因负担过高暂不处理。"],
        "metric": "残差保留率、由残差触发的模型修订数",
    },
    "capacity_context": {
        "name_zh": "状态依赖复判", "name_en": "State-dependent re-evaluation",
        "protocol": ["高影响判断时记录睡眠、压力、时间与环境。", "在不同状态下重复最关键判断。", "比较置信度与选择变化。", "将稳定结论与状态依赖结论分开。"],
        "metric": "状态记录率、跨状态判断漂移、延迟决定收益",
    },
}


def build_enhancement_plan(audit: dict[str, Any], calibration: dict[str, Any]) -> dict[str, Any]:
    priorities = audit.get("priority_dimensions", [])
    exercises = []
    for rank, item in enumerate(priorities, 1):
        dim = item["dimension"]
        template = _EXERCISES[dim]
        exercises.append({
            "exercise_id": stable_id("exercise", {"dimension": dim, "rank": rank}, 16),
            "priority": rank,
            "dimension": dim,
            "current_record_score": item["score"],
            **template,
            "cadence": "One focused cycle per week for four weeks, then review burden and evidence before continuing.",
            "burden_limit": "Stop or reduce scope if the exercise creates material distress, coercion, privacy loss, conflict escalation or opportunity cost greater than its measured learning value.",
            "owner_control": "The owner may reject, edit, pause or retire this exercise; non-completion is not treated as failure or pathology.",
        })
    if calibration.get("resolved_count", 0) < 20 and not any(e["dimension"] == "reality_contact" for e in exercises):
        template = _EXERCISES["reality_contact"]
        exercises.append({
            "exercise_id": stable_id("exercise", {"dimension": "reality_contact", "reason": "small-calibration-sample"}, 16),
            "priority": len(exercises) + 1,
            "dimension": "reality_contact",
            "current_record_score": audit.get("transparency_vector", {}).get("reality_contact", 0),
            **template,
            "cadence": "Record 3–5 clearly resolvable forecasts per week until at least 20 outcomes exist, without selecting only easy forecasts.",
            "burden_limit": "Do not forecast private or high-stakes matters merely to produce a score; choose ethically low-risk, naturally occurring decisions.",
            "owner_control": "Owner may exclude domains, delete uncompiled drafts and stop at any time.",
        })
    return {
        "generated_at": utc_now(),
        "basis": "Lowest dimensions in the supplied record-transparency vector plus calibration sample sufficiency.",
        "exercises": exercises,
        "success_definition": "Improvement means better traceability, model discrimination, calibrated prediction, reversible action and reduced exported burden in future records—not conformity to the system's wording.",
        "anti_gaming": "Do not fill fields merely to raise scores. Empty-but-honest fields are preferable to fabricated evidence, artificial countermodels or coerced disclosure.",
        "clinical_boundary": "This plan is educational and epistemic decision support. It is not psychotherapy, diagnosis, treatment, crisis care or a substitute for a qualified professional.",
        "automatic_external_action_authority": 0,
    }
