from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .audit import audit_events
from .calibration import calibration_report
from .corrections import correction_proposals
from .eidos import load_eidos_context
from .enhancement import build_enhancement_plan
from .evidence import evidence_coverage, load_evidence
from .graph import build_graph
from .laws import assess_law_alignment, law_summary, load_law_registry
from .ledger import load_ledger, verify_ledger_records
from .render import write_rendered_outputs
from .utils import canonical_json, load_json, save_json, save_text, sha256_bytes, sha256_obj, stable_id, utc_now
from .world_models import assess_world_models

_GENERATED_PATHS = (
    "noesis_bundle.json",
    "audit.json",
    "calibration_report.json",
    "world_model_competition.json",
    "law_alignment.json",
    "cosmic_law_registry.json",
    "evidence_coverage.json",
    "evidence_ledger.json",
    "ledger_snapshot.jsonl",
    "cognitive_graph.json",
    "correction_register.json",
    "enhancement_plan.json",
    "enhancement_plan.md",
    "transparency_report.md",
    "dashboard.html",
    "event_cards.csv",
    "OUTPUT_INFO.json",
)


def _prepare_output(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    for rel in (*_GENERATED_PATHS, "MANIFEST.json", "VERIFY.txt"):
        p = out / rel
        if p.exists() and (p.is_file() or p.is_symlink()):
            p.unlink()


def _validate_owner(owner: dict[str, Any]) -> None:
    if not owner.get("owner_id"):
        raise ValueError("Owner profile requires owner_id")
    if int(owner.get("automatic_external_action_authority", 0)) != 0:
        raise ValueError("Reference system fixes automatic_external_action_authority at 0")
    rights = owner.get("rights") or {}
    if rights and not isinstance(rights, dict):
        raise ValueError("owner.rights must be an object")


def _validate_config(config: dict[str, Any]) -> None:
    if int(config.get("automatic_external_action_authority", 0)) != 0:
        raise ValueError("Config cannot grant automatic external action")
    if config.get("mesh_mode") and config["mesh_mode"] != "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE":
        raise ValueError("Unsupported mesh_mode")


def _write_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in records), encoding="utf-8")


def _owner_feedback(audit: dict[str, Any], calibration: dict[str, Any]) -> dict[str, Any]:
    strengths = []
    for row in audit.get("preserved_strengths", []):
        strengths.append({
            "dimension": row["dimension"],
            "record_score": row["score"],
            "feedback": "Current records make this dimension comparatively visible. Preserve the underlying evidence and process, not merely the score.",
        })
    priorities = []
    for row in audit.get("priority_dimensions", []):
        priorities.append({
            "dimension": row["dimension"],
            "record_score": row["score"],
            "feedback": "This is a record-structure blind spot. Review the linked events and correction candidates before making high-impact inferences.",
        })
    questions = [
        "Which important judgments are absent from the ledger because they were tacit, private or too costly to record?",
        "Which correction proposal would create the most information while imposing the least burden?",
        "Which high-confidence belief has the strongest missing counterexample?",
        "Whose burden or refusal is not represented in the current affected-world records?",
        "What result would make you retire, not merely rename, a favored model?",
    ]
    return {
        "preserved_strengths": strengths,
        "priority_review_dimensions": priorities,
        "owner_questions": questions,
        "calibration_note": calibration.get("interpretation_boundary"),
        "anti_shame_boundary": "Missing fields, uncertainty and model failure are learning signals, not moral defects. The system must not be used for coercive ranking, employment screening, insurance pricing, legal culpability or involuntary profiling.",
    }


def _selective_transparency_summary(owner: dict[str, Any], events: list[dict[str, Any]], evidence: list[dict[str, Any]]) -> dict[str, Any]:
    levels = ("private", "trusted_reviewer", "public")
    event_counts = {level: sum(1 for item in events if item.get("visibility", "private") == level) for level in levels}
    evidence_counts = {level: sum(1 for item in evidence if item.get("visibility", "private") == level) for level in levels}
    missing_consent = sorted(
        item.get("event_id") for item in events
        if item.get("visibility", "private") != "private" and not item.get("consent_ref")
    )
    evidence_missing_consent = sorted(
        item.get("evidence_id") for item in evidence
        if item.get("visibility", "private") != "private" and not item.get("consent_ref")
    )
    return {
        "event_counts_by_visibility": event_counts,
        "evidence_counts_by_visibility": evidence_counts,
        "shared_or_public_events_missing_consent_ref": missing_consent,
        "shared_or_public_evidence_missing_consent_ref": evidence_missing_consent,
        "right_to_opacity_declared": bool((owner.get("rights") or {}).get("right_to_opacity", False)),
        "selective_transparency_declared": bool((owner.get("rights") or {}).get("selective_transparency", False)),
        "absence_interpretation": (owner.get("visibility_policy") or {}).get("absence_interpretation", "Missing or withheld records are not evidence of deficiency, consent, falsehood or identity."),
        "export_rule": "Owner exports may include all records; trusted-review exports include trusted/public records; public exports include public records only and always remove owner_only_notes.",
        "complete_person_inference_prohibited": True,
        "automatic_external_action_authority": 0,
    }


def _mesh95_audit(owner: dict[str, Any], events: list[dict[str, Any]], audit: dict[str, Any]) -> dict[str, Any]:
    external = [e["event_id"] for e in events if e.get("action", {}).get("external")]
    unauthorized = [i["event_id"] for i in audit.get("issues", []) if i["code"] == "EXTERNAL_ACTION_NOT_AUTHORIZED"]
    return {
        "mode": "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE",
        "default_stance": "FACTUALLY_OBJECTIVE_RELATIONALLY_PROTECTIVE",
        "owner_agency": "Owner reviews, rejects, edits and explicitly approves correction candidates; original records remain append-only.",
        "external_action_events_declared": external,
        "external_action_events_without_named_authorization": sorted(set(unauthorized)),
        "automatic_external_action_authority": 0,
        "non_pseudo_neutrality": "The system records beneficiaries, burden bearers, power positions, refusal, exit and repair rather than treating hidden asymmetry as neutral.",
        "non_negotiable_boundaries": [
            "No automatic correction, publication, messaging, transaction, representation, diagnosis, treatment or operation of external infrastructure.",
            "Public or shared cognitive records do not grant identity, voice, commercial, clinical or official-representation rights.",
            "High-impact judgments require materially different models and a reversible reality-contact step where feasible.",
            "Corrections append successors and preserve the original event, trigger, approver and authorization reference.",
            "Scores describe record explicitness only; they cannot be converted into a person's worth, sanity, intelligence, trustworthiness or consciousness status.",
        ],
        "owner_rights": owner.get("rights", {}),
    }


def _write_manifest(out: Path) -> dict[str, Any]:
    files = {}
    expected = set(_GENERATED_PATHS)
    for rel in sorted(expected):
        p = out / rel
        if p.is_file():
            files[rel] = sha256_bytes(p.read_bytes())
    untracked = sorted(
        p.relative_to(out).as_posix()
        for p in out.rglob("*")
        if p.is_file() and p.relative_to(out).as_posix() not in expected and p.name not in {"MANIFEST.json", "VERIFY.txt"}
    )
    manifest = {
        "created_at": utc_now(),
        "files": files,
        "manifest_digest": sha256_obj(files),
        "untracked_files": untracked,
        "scope": "Only compiler-owned files listed under files are integrity-covered. Unknown user files are preserved and excluded from the manifest.",
    }
    save_json(out / "MANIFEST.json", manifest)
    return manifest


def compile_noesis(
    owner: dict[str, Any] | str | Path,
    ledger_path: str | Path,
    evidence_path: str | Path | None,
    out_dir: str | Path,
    *,
    config: dict[str, Any] | str | Path | None = None,
    eidos_bundle: str | Path | None = None,
    law_registry_path: str | None = None,
) -> dict[str, Any]:
    owner_obj = load_json(owner) if isinstance(owner, (str, Path)) else dict(owner)
    config_obj = load_json(config) if isinstance(config, (str, Path)) else dict(config or {})
    _validate_owner(owner_obj)
    _validate_config(config_obj)
    records = load_ledger(ledger_path, verify=True)
    if not records:
        raise ValueError("The cognitive ledger is empty")
    owners = {r.get("owner_id") for r in records}
    if owners != {owner_obj["owner_id"]}:
        raise ValueError(f"Ledger owner mismatch: {sorted(owners)}")
    evidence = load_evidence(evidence_path)
    ledger_verification = verify_ledger_records(records)
    calibration = calibration_report(records)
    audit = audit_events(records, evidence, calibration=calibration)
    model_competition = assess_world_models(records)
    coverage = evidence_coverage(records, evidence)
    registry = load_law_registry(law_registry_path)
    law_alignment = assess_law_alignment(registry, audit)
    corrections = correction_proposals(audit)
    enhancement = build_enhancement_plan(audit, calibration)
    graph = build_graph(records, evidence, audit, law_alignment)
    eidos_context = load_eidos_context(eidos_bundle, expected_owner_id=owner_obj["owner_id"]) if eidos_bundle else None
    feedback = _owner_feedback(audit, calibration)
    mesh95 = _mesh95_audit(owner_obj, records, audit)
    selective_transparency = _selective_transparency_summary(owner_obj, records, evidence)
    compilation_id = stable_id("noesis", {
        "owner_id": owner_obj["owner_id"],
        "owner_digest": sha256_obj(owner_obj),
        "ledger_head": ledger_verification["head_digest"],
        "evidence_digests": [e["record_digest"] for e in evidence],
        "registry_id": registry.get("registry_id"),
        "eidos_digest": eidos_context.get("bundle_digest") if eidos_context else None,
        "config": config_obj,
    }, 24)
    bundle_core = {
        "system": "DIKWP-NOESIS 9.5 — Cosmic-Essence-Oriented Personal Cognitive Transparency, Reversible Correction and Enhancement System",
        "version": "1.0.0",
        "generated_at": utc_now(),
        "compilation_id": compilation_id,
        "owner": owner_obj,
        "config": config_obj,
        "ledger_verification": ledger_verification,
        "event_index": records,
        "evidence_ledger": evidence,
        "evidence_coverage": coverage,
        "audit": audit,
        "calibration": calibration,
        "world_model_competition": model_competition,
        "law_registry_summary": law_summary(registry),
        "law_alignment": law_alignment,
        "correction_proposals": corrections,
        "enhancement_plan": enhancement,
        "owner_feedback": feedback,
        "cognitive_graph": graph,
        "eidos_context": eidos_context,
        "mesh95_audit": mesh95,
        "selective_transparency": selective_transparency,
        "responsibility_handoff": {
            "owner_decisions": "Accept, edit, reject or retire interpretations and correction proposals; authorize any external or high-impact action explicitly and revocably.",
            "system_preserves": "Source paths, uncertainty, alternatives, residuals, revision lineage, burdens, digests and the fact that a recommendation was machine-generated.",
            "domain_validation": "Medical, psychological, legal, financial, scientific and safety-critical claims require independent qualified professionals and domain-appropriate evidence.",
        },
        "claim_boundaries": [
            "The 24 law cards are versioned working propositions/protocols/hypotheses/constraints, not a collective claim of experimentally established final cosmic laws.",
            "The system audits supplied records; it cannot see tacit cognition and does not infer a complete person from incomplete data.",
            "No output diagnoses or treats mental illness, determines legal responsibility, certifies expertise, consciousness, personhood, truthfulness or moral worth.",
            "Cognitive correction means owner-governed epistemic record revision through evidence, competing models, prediction and reversible action—not coercive belief replacement.",
            "Calibration statistics are conditional on which predictions were selected, their resolution quality, domain and sample size; they are not stable trait scores.",
            "The deterministic reference engine can miss irony, multilingual nuance, domain semantics and hidden context; owner review and counterexamples remain required.",
            "Selective transparency is owner-governed: absence, withholding or redaction cannot be interpreted as deficiency, consent, falsehood, guilt or a stable trait.",
            "Automatic external-action authority is zero.",
        ],
        "automatic_external_action_authority": 0,
    }
    bundle_core["bundle_digest"] = sha256_obj(bundle_core)
    out = Path(out_dir)
    _prepare_output(out)
    save_json(out / "noesis_bundle.json", bundle_core)
    save_json(out / "audit.json", audit)
    save_json(out / "calibration_report.json", calibration)
    save_json(out / "world_model_competition.json", model_competition)
    save_json(out / "law_alignment.json", law_alignment)
    save_json(out / "cosmic_law_registry.json", registry)
    save_json(out / "evidence_coverage.json", coverage)
    save_json(out / "evidence_ledger.json", {"evidence": evidence})
    _write_jsonl(out / "ledger_snapshot.jsonl", records)
    save_json(out / "cognitive_graph.json", graph)
    save_json(out / "correction_register.json", {"proposals": corrections, "automatic_application": False})
    save_json(out / "enhancement_plan.json", enhancement)
    write_rendered_outputs(out, bundle_core)
    save_json(out / "OUTPUT_INFO.json", {
        "system": bundle_core["system"],
        "version": bundle_core["version"],
        "compilation_id": compilation_id,
        "bundle_digest": bundle_core["bundle_digest"],
        "ledger_head_digest": ledger_verification["head_digest"],
        "event_count": len(records),
        "evidence_count": len(evidence),
        "issue_count": audit["issue_count"],
        "correction_candidate_count": len(corrections),
        "automatic_external_action_authority": 0,
    })
    manifest = _write_manifest(out)
    save_text(out / "VERIFY.txt", (
        f"Compilation: {compilation_id}\n"
        f"Bundle digest: {bundle_core['bundle_digest']}\n"
        f"Ledger head digest: {ledger_verification['head_digest']}\n"
        f"Manifest digest: {manifest['manifest_digest']}\n"
        f"Integrity-covered files: {len(manifest['files'])}\n"
        f"Untracked preserved files: {len(manifest['untracked_files'])}\n"
        "Automatic external action authority: 0\n"
    ))
    return bundle_core
