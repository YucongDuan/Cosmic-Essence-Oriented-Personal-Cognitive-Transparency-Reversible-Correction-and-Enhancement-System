from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import clamp, load_json, normalize_text, sha256_obj, stable_id

ALLOWED_VISIBILITY = {"private", "trusted_reviewer", "public"}

ALLOWED_SOURCE_TYPES = {
    "direct_observation", "measurement", "experiment", "primary_document", "research_paper",
    "book", "official_record", "expert_judgment", "testimony", "memory", "secondary_summary",
    "model_output", "simulation", "code_execution", "other",
}


def _strings(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        raise ValueError("Expected string or list")
    return [normalize_text(str(v)) for v in value if normalize_text(str(v))]


def normalize_evidence(record: dict[str, Any], idx: int = 0) -> dict[str, Any]:
    if not isinstance(record, dict):
        raise ValueError("Evidence record must be an object")
    title = normalize_text(str(record.get("title", "")))
    source_type = normalize_text(str(record.get("source_type", "other"))).lower()
    if source_type not in ALLOWED_SOURCE_TYPES:
        source_type = "other"
    locator = normalize_text(str(record.get("locator", record.get("url", record.get("path", "")))))
    excerpt = normalize_text(str(record.get("excerpt", "")))
    seed = {"title": title, "source_type": source_type, "locator": locator, "excerpt": excerpt, "idx": idx}
    quality = record.get("quality") or {}
    if not isinstance(quality, dict):
        raise ValueError("Evidence quality must be an object")
    normalized_quality = {
        "directness": clamp(float(quality.get("directness", 0.5))),
        "reliability": clamp(float(quality.get("reliability", 0.5))),
        "independence": clamp(float(quality.get("independence", 0.5))),
        "completeness": clamp(float(quality.get("completeness", 0.5))),
        "recency_relevance": clamp(float(quality.get("recency_relevance", 0.5))),
    }
    visibility = normalize_text(str(record.get("visibility", "private"))).lower() or "private"
    if visibility not in ALLOWED_VISIBILITY:
        raise ValueError("evidence visibility must be private/trusted_reviewer/public")
    normalized = {
        "evidence_id": normalize_text(str(record.get("evidence_id", ""))) or stable_id("ev", seed, 18),
        "title": title or f"Evidence {idx + 1}",
        "source_type": source_type,
        "locator": locator,
        "retrieved_at": normalize_text(str(record.get("retrieved_at", ""))),
        "authors_or_origin": _strings(record.get("authors_or_origin")),
        "excerpt": excerpt,
        "supports_event_ids": _strings(record.get("supports_event_ids")),
        "challenges_event_ids": _strings(record.get("challenges_event_ids")),
        "independence_group": normalize_text(str(record.get("independence_group", ""))) or "unspecified",
        "quality": normalized_quality,
        "rights": {
            "status": normalize_text(str((record.get("rights") or {}).get("status", "unknown"))),
            "attribution": normalize_text(str((record.get("rights") or {}).get("attribution", ""))),
            "allowed_use": _strings((record.get("rights") or {}).get("allowed_use")),
        },
        "notes": normalize_text(str(record.get("notes", ""))),
        "visibility": visibility,
        "consent_ref": normalize_text(str(record.get("consent_ref", ""))),
        "redaction_tags": _strings(record.get("redaction_tags")),
    }
    normalized["quality_score"] = round(sum(normalized_quality.values()) / len(normalized_quality), 4)
    normalized["record_digest"] = sha256_obj({k: v for k, v in normalized.items() if k != "record_digest"})
    return normalized


def load_evidence(path: str | Path | None) -> list[dict[str, Any]]:
    if not path:
        return []
    data = load_json(path)
    if isinstance(data, dict):
        data = data.get("evidence", [])
    if not isinstance(data, list):
        raise ValueError("Evidence JSON must be a list or an object with an evidence list")
    out = [normalize_evidence(record, idx) for idx, record in enumerate(data)]
    ids = [r["evidence_id"] for r in out]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate evidence_id")
    return out


def evidence_index(records: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {r["evidence_id"]: r for r in records}


def evidence_coverage(events: list[dict[str, Any]], records: list[dict[str, Any]]) -> dict[str, Any]:
    index = evidence_index(records)
    missing = []
    used: set[str] = set()
    counter_used: set[str] = set()
    event_rows = []
    for event in events:
        refs = event.get("evidence_refs", [])
        counter = event.get("counterevidence_refs", [])
        unresolved = [r for r in refs + counter if r not in index]
        if unresolved:
            missing.append({"event_id": event["event_id"], "missing_evidence_refs": unresolved})
        used.update(r for r in refs if r in index)
        counter_used.update(r for r in counter if r in index)
        qualities = [index[r]["quality_score"] for r in refs if r in index]
        event_rows.append({
            "event_id": event["event_id"],
            "evidence_count": len([r for r in refs if r in index]),
            "counterevidence_count": len([r for r in counter if r in index]),
            "mean_evidence_quality": round(sum(qualities) / len(qualities), 4) if qualities else None,
            "unresolved_refs": unresolved,
        })
    return {
        "record_count": len(records),
        "used_record_count": len(used | counter_used),
        "unused_record_ids": sorted(set(index) - used - counter_used),
        "missing_references": missing,
        "event_rows": event_rows,
    }
