"""Bundled versioned working-law and source registries."""
