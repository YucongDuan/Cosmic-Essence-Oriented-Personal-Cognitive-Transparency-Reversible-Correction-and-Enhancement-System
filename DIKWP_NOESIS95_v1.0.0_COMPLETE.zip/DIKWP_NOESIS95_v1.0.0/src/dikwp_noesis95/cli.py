from __future__ import annotations

import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import sys
from typing import Any

from .compiler import compile_noesis
from .corrections import approve_proposal
from .diffing import compare_and_save
from .exporter import export_transparency_packet
from .laws import law_summary, load_law_registry
from .ledger import append_event, initialize_ledger, ledger_from_json, load_ledger, verify_ledger_records
from .utils import load_json, save_json
from .verify import verify_output_dir


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _json_print(obj: Any, *, stream=None) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2), file=stream or sys.stdout)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="noesis95", description="DIKWP-NOESIS 9.5 cognitive transparency, reversible correction and enhancement")
    sub = p.add_subparsers(dest="command", required=True)

    init_p = sub.add_parser("init", help="Create a local owner-governed workspace")
    init_p.add_argument("workspace")
    init_p.add_argument("--owner-id", required=True)
    init_p.add_argument("--display-name", default="")

    append_p = sub.add_parser("append", help="Normalize and append one cognitive event to the hash-chained ledger")
    append_p.add_argument("--ledger", required=True)
    append_p.add_argument("--event", required=True, help="Path to event JSON")
    append_p.add_argument("--owner-id")

    import_p = sub.add_parser("import-json", help="Build a new hash-chained ledger from an events JSON file")
    import_p.add_argument("--input", required=True)
    import_p.add_argument("--ledger", required=True)
    import_p.add_argument("--owner-id")
    import_p.add_argument("--overwrite", action="store_true")

    compile_p = sub.add_parser("compile", help="Compile audit, feedback, correction candidates and enhancement plan")
    compile_p.add_argument("--owner", required=True)
    compile_p.add_argument("--ledger", required=True)
    compile_p.add_argument("--evidence")
    compile_p.add_argument("--config")
    compile_p.add_argument("--eidos")
    compile_p.add_argument("--law-registry")
    compile_p.add_argument("--out", required=True)

    demo_p = sub.add_parser("demo", help="Run the bundled cosmic-method demo")
    demo_p.add_argument("--out", default="outputs/yucongduan_cosmic_method")
    demo_p.add_argument("--example-root")
    demo_p.add_argument("--eidos")

    vl_p = sub.add_parser("verify-ledger", help="Verify sequence and hash chain")
    vl_p.add_argument("ledger")

    verify_p = sub.add_parser("verify", help="Verify a compiled output directory")
    verify_p.add_argument("output_dir")

    approve_p = sub.add_parser("approve", help="Append an owner-approved correction successor")
    approve_p.add_argument("--ledger", required=True)
    approve_p.add_argument("--proposals", required=True)
    approve_p.add_argument("--proposal-id", required=True)
    approve_p.add_argument("--approver", required=True)
    approve_p.add_argument("--authorization-ref", required=True)

    laws_p = sub.add_parser("laws", help="Print the versioned working-law registry summary")
    laws_p.add_argument("--registry")
    laws_p.add_argument("--full", action="store_true")

    export_p = sub.add_parser("export", help="Create an owner-governed selective transparency packet")
    export_p.add_argument("--bundle", required=True)
    export_p.add_argument("--audience", choices=["owner", "trusted_reviewer", "public"], default="public")
    export_p.add_argument("--out", required=True)
    export_p.add_argument("--include-display-name", action="store_true")

    diff_p = sub.add_parser("diff", help="Compare two compiled cognitive worldlines")
    diff_p.add_argument("--old", required=True)
    diff_p.add_argument("--new", required=True)
    diff_p.add_argument("--out", required=True)

    serve_p = sub.add_parser("serve", help="Serve a compiled dashboard on loopback only")
    serve_p.add_argument("directory")
    serve_p.add_argument("--port", type=int, default=8765)
    serve_p.add_argument("--host", default="127.0.0.1", choices=["127.0.0.1", "localhost", "::1"])

    sub.add_parser("summary", help="Print architecture summary")
    sub.add_parser("doctor", help="Check local runtime and bundled registry")
    return p


def _init_workspace(args: argparse.Namespace) -> int:
    root = Path(args.workspace)
    root.mkdir(parents=True, exist_ok=True)
    paths = [root / "owner.json", root / "config.json", root / "evidence.json", root / "cognitive_ledger.jsonl"]
    existing = [str(x) for x in paths if x.exists() and x.stat().st_size]
    if existing:
        raise FileExistsError(f"Refusing to overwrite non-empty workspace files: {existing}")
    save_json(root / "owner.json", {
        "owner_id": args.owner_id,
        "display_name": args.display_name,
        "rights": {
            "cognitive_record_use": True,
            "owner_review_required": True,
            "identity_simulation": False,
            "clinical_use": False,
            "employment_screening": False,
            "commercial_use": False,
        },
        "revocation": "Owner may stop future compilation and issue append-only correction/tombstone records.",
        "automatic_external_action_authority": 0,
    })
    save_json(root / "config.json", {
        "mesh_mode": "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE",
        "minimum_non_isomorphic_models_for_high_impact": 2,
        "correction_application": "named_owner_approval_only",
        "automatic_external_action_authority": 0,
    })
    save_json(root / "evidence.json", {"evidence": []})
    initialize_ledger(root / "cognitive_ledger.jsonl", overwrite=True)
    _json_print({"status": "ok", "workspace": str(root.resolve()), "files": [str(p.resolve()) for p in paths], "automatic_external_action_authority": 0})
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            return _init_workspace(args)
        if args.command == "append":
            record = append_event(args.ledger, load_json(args.event), owner_id=args.owner_id)
            _json_print({"status": "ok", "event_id": record["event_id"], "ledger_seq": record["ledger_seq"], "event_digest": record["event_digest"], "automatic_external_action_authority": 0})
            return 0
        if args.command == "import-json":
            records = ledger_from_json(args.input, args.ledger, owner_id=args.owner_id, overwrite=args.overwrite)
            _json_print({"status": "ok", "event_count": len(records), "head_digest": records[-1]["event_digest"] if records else "GENESIS", "ledger": str(Path(args.ledger).resolve())})
            return 0
        if args.command == "compile":
            bundle = compile_noesis(args.owner, args.ledger, args.evidence, args.out, config=args.config, eidos_bundle=args.eidos, law_registry_path=args.law_registry)
            _json_print({"status": "ok", "compilation_id": bundle["compilation_id"], "bundle_digest": bundle["bundle_digest"], "events": len(bundle["event_index"]), "issues": bundle["audit"]["issue_count"], "dashboard": str((Path(args.out) / "dashboard.html").resolve()), "automatic_external_action_authority": 0})
            return 0
        if args.command == "demo":
            root = Path(args.example_root) if args.example_root else _project_root() / "examples" / "yucongduan_cosmic_method"
            eidos = args.eidos
            if not eidos:
                candidate = _project_root().parent / "DIKWP_EIDOS95_v1.0.0" / "outputs" / "yucongduan_public_core" / "essence_bundle.json"
                eidos = str(candidate) if candidate.exists() else None
            bundle = compile_noesis(root / "owner.json", root / "cognitive_ledger.jsonl", root / "evidence.json", args.out, config=root / "config.json", eidos_bundle=eidos)
            _json_print({"status": "ok", "compilation_id": bundle["compilation_id"], "dashboard": str((Path(args.out) / "dashboard.html").resolve()), "report": str((Path(args.out) / "transparency_report.md").resolve()), "events": len(bundle["event_index"]), "issues": bundle["audit"]["issue_count"]})
            return 0
        if args.command == "verify-ledger":
            records = load_ledger(args.ledger, verify=False)
            report = verify_ledger_records(records)
            _json_print(report)
            return 0 if report["valid"] else 2
        if args.command == "verify":
            report = verify_output_dir(args.output_dir)
            _json_print(report)
            return 0 if report["valid"] else 2
        if args.command == "approve":
            records = load_ledger(args.ledger, verify=True)
            proposals_obj = load_json(args.proposals)
            proposals = proposals_obj.get("proposals", proposals_obj) if isinstance(proposals_obj, dict) else proposals_obj
            proposal = next((p for p in proposals if p.get("proposal_id") == args.proposal_id), None)
            if not proposal:
                raise ValueError(f"Proposal not found: {args.proposal_id}")
            original = next((r for r in records if r.get("event_id") == proposal.get("event_id")), None)
            if not original:
                raise ValueError(f"Original event not found: {proposal.get('event_id')}")
            record = approve_proposal(args.ledger, original, proposal, approver=args.approver, authorization_ref=args.authorization_ref)
            _json_print({"status": "ok", "new_event_id": record["event_id"], "supersedes": record["supersedes"], "ledger_seq": record["ledger_seq"], "automatic_external_action_authority": 0})
            return 0
        if args.command == "laws":
            registry = load_law_registry(args.registry)
            _json_print(registry if args.full else law_summary(registry))
            return 0
        if args.command == "export":
            packet = export_transparency_packet(args.bundle, args.out, audience=args.audience, include_display_name=args.include_display_name)
            _json_print({"status": "ok", "audience": args.audience, "event_count": len(packet["events"]), "evidence_count": len(packet["evidence"]), "export_digest": packet["export_digest"], "out": str(Path(args.out).resolve()), "automatic_external_action_authority": 0})
            return 0
        if args.command == "diff":
            report = compare_and_save(args.old, args.new, args.out)
            _json_print({"status": "ok", "added": len(report["added_event_ids"]), "changed": len(report["changed_events"]), "out": str(Path(args.out).resolve()), "automatic_external_action_authority": 0})
            return 0
        if args.command == "serve":
            directory = Path(args.directory).resolve()
            if not directory.is_dir():
                raise ValueError(f"Not a directory: {directory}")
            handler = partial(SimpleHTTPRequestHandler, directory=str(directory))
            server = ThreadingHTTPServer((args.host, args.port), handler)
            _json_print({"status": "serving", "url": f"http://{args.host}:{args.port}/dashboard.html", "directory": str(directory), "loopback_only": True, "automatic_external_action_authority": 0})
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                server.server_close()
            return 0
        if args.command == "summary":
            print("DIKWP-NOESIS 9.5\nPipeline: owner/rights boundary -> append-only cognitive ledger -> evidence resolution -> E/H/F/P/N + D/I/K/W/P audit -> non-isomorphic model competition -> prediction/outcome calibration -> 24 versioned working-law alignment -> owner-approved append-only correction candidates -> burden-bounded enhancement experiments -> integrity manifest and offline dashboard.\nAutomatic external action authority: 0.")
            return 0
        if args.command == "doctor":
            registry = load_law_registry()
            _json_print({
                "system": "DIKWP-NOESIS 9.5",
                "version": "1.0.0",
                "python": sys.version,
                "mesh_mode": "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE",
                "stdlib_only_core": True,
                "network_required_for_core": False,
                "bundled_working_law_count": len(registry.get("laws", [])),
                "law_boundary": registry.get("boundary"),
                "automatic_external_action_authority": 0,
            })
            return 0
    except (ValueError, FileNotFoundError, FileExistsError, OSError, json.JSONDecodeError) as exc:
        _json_print({"status": "error", "command": args.command, "message": str(exc), "automatic_external_action_authority": 0}, stream=sys.stderr)
        return 3
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
