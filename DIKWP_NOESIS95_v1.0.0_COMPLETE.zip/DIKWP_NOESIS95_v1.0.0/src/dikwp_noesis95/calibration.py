from __future__ import annotations

from datetime import datetime, timezone
import math
from typing import Any

from .utils import clamp, utc_now


def _parse_time(value: str) -> datetime | None:
    if not value:
        return None
    try:
        v = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(v)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def _prediction_register(events: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    predictions: dict[str, dict[str, Any]] = {}
    duplicates = []
    for event in events:
        for pred in event.get("predictions", []):
            pid = pred["prediction_id"]
            row = {**pred, "event_id": event["event_id"], "event_created_at": event.get("created_at"), "event_status": event.get("status")}
            if pid in predictions:
                duplicates.append({"prediction_id": pid, "first_event": predictions[pid]["event_id"], "duplicate_event": event["event_id"]})
            else:
                predictions[pid] = row
    return predictions, duplicates


def _outcome_register(events: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    outcomes: dict[str, dict[str, Any]] = {}
    duplicates = []
    for event in events:
        for outcome in event.get("outcomes", []):
            pid = outcome["prediction_id"]
            row = {**outcome, "outcome_event_id": event["event_id"]}
            if pid in outcomes:
                duplicates.append({"prediction_id": pid, "first_event": outcomes[pid]["outcome_event_id"], "duplicate_event": event["event_id"]})
            else:
                outcomes[pid] = row
    return outcomes, duplicates


def _calibration_bins(resolved: list[dict[str, Any]], width: float = 0.1) -> list[dict[str, Any]]:
    bins = []
    n_bins = int(round(1 / width))
    for idx in range(n_bins):
        low = idx * width
        high = 1.0 if idx == n_bins - 1 else (idx + 1) * width
        members = [r for r in resolved if (low <= r["probability"] <= high if idx == n_bins - 1 else low <= r["probability"] < high)]
        if not members:
            continue
        mean_p = sum(r["probability"] for r in members) / len(members)
        observed_rate = sum(r["observed"] for r in members) / len(members)
        bins.append({
            "lower": round(low, 2), "upper": round(high, 2), "count": len(members),
            "mean_probability": round(mean_p, 4), "observed_rate": round(observed_rate, 4),
            "calibration_gap": round(mean_p - observed_rate, 4),
        })
    return bins


def calibration_report(events: list[dict[str, Any]], *, now: str | None = None) -> dict[str, Any]:
    predictions, duplicate_predictions = _prediction_register(events)
    outcomes, duplicate_outcomes = _outcome_register(events)
    resolved = []
    pending = []
    orphan_outcomes = []
    now_dt = _parse_time(now or utc_now()) or datetime.now(timezone.utc)
    for pid, pred in predictions.items():
        if pid in outcomes:
            outcome = outcomes[pid]
            p = clamp(float(pred["probability"]), 1e-9, 1 - 1e-9)
            y = int(outcome["observed"])
            resolved.append({
                "prediction_id": pid,
                "event_id": pred["event_id"],
                "statement": pred["statement"],
                "probability": float(pred["probability"]),
                "observed": y,
                "brier": round((p - y) ** 2, 6),
                "log_loss": round(-(y * math.log(p) + (1 - y) * math.log(1 - p)), 6),
                "due_at": pred.get("due_at"),
                "observed_at": outcome.get("observed_at"),
                "evidence_refs": outcome.get("evidence_refs", []),
                "outcome_event_id": outcome.get("outcome_event_id"),
            })
        else:
            due = _parse_time(pred.get("due_at", ""))
            pending.append({
                **pred,
                "overdue": bool(due and due < now_dt),
                "days_from_due": round((now_dt - due).total_seconds() / 86400, 1) if due else None,
            })
    for pid, outcome in outcomes.items():
        if pid not in predictions:
            orphan_outcomes.append({"prediction_id": pid, **outcome})
    n = len(resolved)
    mean_brier = sum(r["brier"] for r in resolved) / n if n else None
    mean_log = sum(r["log_loss"] for r in resolved) / n if n else None
    accuracy = sum((r["probability"] >= 0.5) == bool(r["observed"]) for r in resolved) / n if n else None
    bins = _calibration_bins(resolved)
    expected_calibration_error = None
    if n:
        expected_calibration_error = sum(b["count"] / n * abs(b["calibration_gap"]) for b in bins)
    caution = (
        "No resolved predictions yet; the system can inspect recording discipline but cannot estimate calibration."
        if n == 0 else
        "Very small sample: treat scores as descriptive, not a stable trait estimate."
        if n < 20 else
        "Moderate sample: inspect domain and time-window stratification before generalizing."
        if n < 100 else
        "Larger sample, but calibration remains conditional on prediction selection, domain and resolution quality."
    )
    return {
        "prediction_count": len(predictions),
        "resolved_count": n,
        "pending_count": len(pending),
        "overdue_count": sum(1 for p in pending if p["overdue"]),
        "mean_brier": round(mean_brier, 6) if mean_brier is not None else None,
        "mean_log_loss": round(mean_log, 6) if mean_log is not None else None,
        "threshold_accuracy": round(accuracy, 6) if accuracy is not None else None,
        "expected_calibration_error": round(expected_calibration_error, 6) if expected_calibration_error is not None else None,
        "calibration_bins": bins,
        "resolved": resolved,
        "pending": pending,
        "duplicate_predictions": duplicate_predictions,
        "duplicate_outcomes": duplicate_outcomes,
        "orphan_outcomes": orphan_outcomes,
        "interpretation_boundary": caution,
        "not_a_trait_score": True,
    }
