from __future__ import annotations

from copy import deepcopy
from typing import Any

from .ledger import append_event
from .utils import sha256_obj, stable_id, utc_now

_REMEDIATIONS: dict[str, dict[str, Any]] = {
    "UNSCOPED_UNIVERSAL_CLAIM": {
        "operation": "narrow_scope",
        "patch": {"scope": {"subjects": ["Specify target population/object"], "contexts": ["Specify context"], "time_horizon": "Specify time window", "scale": "Specify scale", "observer_position": "Specify observer/measurement position", "exclusions": ["List known exclusions"]}},
        "test": "Search for a case outside the proposed scope and a case inside it; compare whether the same relation holds.",
    },
    "FALSE_CERTAINTY": {
        "operation": "recalibrate_confidence",
        "patch": {"confidence": 0.65, "open_questions": ["What evidence would justify raising confidence again?"]},
        "test": "Obtain at least one independent supporting source and one actively sought disconfirming test before raising confidence.",
    },
    "EVIDENCE_GAP": {
        "operation": "add_evidence_or_reclassify",
        "patch": {"status": "tentative", "confidence": 0.5, "owner_annotations": ["Evidence required; alternatively reclassify as proposal/normative statement where appropriate."]},
        "test": "Attach a resolvable primary record or run a prospective observation with a predefined result rule.",
    },
    "EVIDENCE_REFERENCE_MISSING": {
        "operation": "repair_provenance",
        "patch": {"owner_annotations": ["Resolve missing evidence IDs or remove invalid references while preserving the correction history."]},
        "test": "Every evidence ID must resolve to an immutable evidence-ledger record and digest.",
    },
    "EVIDENCE_INDEPENDENCE_COLLAPSE": {
        "operation": "triangulate_sources",
        "patch": {"owner_annotations": ["Seek evidence from a different independence group, method, institution or measurement path."]},
        "test": "Compare conclusions after excluding the shared dependency chain.",
    },
    "SOURCE_AUTHORITY_OVERREACH": {
        "operation": "separate_source_from_truth",
        "patch": {"confidence": 0.6, "owner_annotations": ["Treat model output, memory or secondary synthesis as a lead rather than direct external proof."]},
        "test": "Replace or corroborate with direct observation, primary documentation, code execution or domain experiment.",
    },
    "SINGLE_MODEL_CLOSURE": {
        "operation": "create_model_duel",
        "patch": {"world_models": [
            {"name": "Mechanism model", "model_type": "causal", "claim": "State a causal explanation", "assumptions": ["List causal assumptions"], "predictions": ["Prediction unique to this model"], "discriminators": ["Test that separates causal and alternative models"], "failure_modes": ["Conditions under which this model fails"], "confidence": 0.5},
            {"name": "Context/selection model", "model_type": "contextual", "claim": "State a non-causal, contextual or selection explanation", "assumptions": ["List context/selection assumptions"], "predictions": ["Different prediction"], "discriminators": ["Same test with divergent expected result"], "failure_modes": ["Conditions under which this model fails"], "confidence": 0.5}
        ]},
        "test": "Run a pre-registered discriminator whose expected outcomes differ between the models.",
    },
    "MODEL_PSEUDO_DIVERSITY": {
        "operation": "increase_structural_diversity",
        "patch": {"owner_annotations": ["Replace wording variants with models that differ in mechanism, scale, observer, value function or institutional incentives."]},
        "test": "A model pair counts only when at least one observable result would update them in opposite directions.",
    },
    "VALUE_SMUGGLING": {
        "operation": "make_values_and_burdens_explicit",
        "patch": {"values": [{"name": "Specify value", "weight": 0.5, "beneficiaries": ["Who benefits"], "burden_bearers": ["Who bears error/cost"], "measurement": "How the value is observed", "conflicts": ["Competing value"]}]},
        "test": "Ask whether a person carrying the burden would endorse the metric and consent/appeal path.",
    },
    "PURPOSE_OPACITY": {
        "operation": "compile_purpose_contract",
        "patch": {"purpose": {"input_state": "Current observable state", "desired_state": "Desired observable state", "output": "Concrete deliverable/action", "success_metrics": ["Metric and threshold"], "time_horizon": "Time window", "stop_conditions": ["Stop if harm, cost or invalid assumption threshold is crossed"], "rollback": "Return to prior safe state"}},
        "test": "A reviewer should be able to decide success, failure and stop without guessing hidden intent.",
    },
    "NO_FALSIFIER": {
        "operation": "add_falsifier",
        "patch": {"falsifiers": ["Observable result that would lower confidence or retire the claim"], "open_questions": ["Which alternative explanation predicts that result?"]},
        "test": "Precommit the confidence update before observing the result.",
    },
    "CATEGORY_COLLAPSE": {
        "operation": "retype_semantic_position",
        "patch": {"owner_annotations": ["Split one record into observation(D/E), interpretation(I/H), reusable claim(K), judgment(W/N or H), and purpose/action(P) records as needed."]},
        "test": "Remove each layer in turn; verify that no layer silently carries another layer's authority.",
    },
    "OUTCOMELESS_ACTION": {
        "operation": "add_reality_return",
        "patch": {"action": {"result_metric": "Observable result and collection time"}, "predictions": [{"statement": "Expected outcome of the action", "probability": 0.6, "due_at": "Set due date", "outcome_definition": "Binary or otherwise predeclared resolution rule"}]},
        "test": "Record the result at the due time even when it is unfavorable or ambiguous.",
    },
    "HIGH_STAKES_IRREVERSIBLE": {
        "operation": "reduce_and_reverse",
        "patch": {"action": {"reversible": True, "rollback": "Pilot on the smallest reversible scope; define rollback owner, trigger and recovery state"}, "purpose": {"stop_conditions": ["Stop on specified harm/uncertainty threshold"]}},
        "test": "Perform a dry-run rollback before the live action; if rollback fails, do not escalate.",
    },
    "COUNTEREVIDENCE_ERASURE": {
        "operation": "restore_residuals",
        "patch": {"counterevidence_refs": ["Add strongest counterevidence record"], "open_questions": ["What remains unexplained?"], "falsifiers": ["What would reverse the conclusion?"]},
        "test": "Steelman the strongest alternative and have a second reviewer identify omitted residuals.",
    },
    "REVISION_WITHOUT_LINEAGE": {
        "operation": "link_worldline",
        "patch": {"supersedes": ["Insert prior event_id"], "owner_annotations": ["State what changed, why, which evidence triggered it, and what remains preserved."]},
        "test": "Traverse from the new record to the old record and reconstruct the reason for revision.",
    },
    "AFFECTED_WORLD_OMISSION": {
        "operation": "map_affected_worlds",
        "patch": {"affected_worlds": [{"stakeholder": "Affected person/group/system", "expected_benefit": "Expected benefit", "possible_burden": "Possible burden/error cost", "consent_status": "unknown", "appeal_or_exit": "Appeal/exit/remedy path", "power_position": "relative leverage"}]},
        "test": "Include at least one party that does not share the decision-maker's incentives.",
    },
    "STATUS_ASYMMETRY_BLINDNESS": {
        "operation": "record_power_and_burden",
        "patch": {"owner_annotations": ["For every affected world, record relative leverage, who must prove consent, who pays for error and who can reverse the decision."]},
        "test": "Reverse the roles and ask whether the same evidence and consent standard would still be accepted.",
    },
    "FORMAT_AUTHORITY": {
        "operation": "separate_formal_validity_from_external_validity",
        "patch": {"owner_annotations": ["Label which steps are definitions/formal derivations and which require empirical validation."], "confidence": 0.65},
        "test": "Attempt an external prediction that is not guaranteed by the definitions themselves.",
    },
    "IDENTITY_CLAIM_FUSION": {
        "operation": "decompose_identity_claim",
        "patch": {"scope": {"time_horizon": "Specify when this pattern was observed", "contexts": ["Contexts in which it occurs"], "exclusions": ["Contexts or counterexamples where it does not occur"]}, "confidence": 0.6, "owner_annotations": ["Describe behavior/state/role rather than an immutable essence."]},
        "test": "Search for counterexamples across roles, relationships, time periods and capacity states.",
    },
    "EXTERNAL_ACTION_NOT_AUTHORIZED": {
        "operation": "block_until_named_authorization",
        "patch": {"action": {"external": False, "authorization_ref": "Required before any external action"}, "status": "tentative"},
        "test": "Verify named owner, scope, expiry, revocation and rollback; automatic external-action authority remains zero.",
    },
    "CAPACITY_CONTEXT_OMITTED": {
        "operation": "record_state_context",
        "patch": {"state_context": {"capacity": "normal/reduced/unknown", "stress": "0-10 or unknown", "sleep_hours": "hours or unknown", "time_pressure": "deadline/urgency", "environment": "social/physical context", "notes": "Medication, illness or other material conditions only when voluntarily supplied and appropriate"}},
        "test": "Reassess the same judgment in a different capacity state before treating it as stable.",
    },
    "PREDICTION_RESOLUTION_GAP": {
        "operation": "resolve_prediction",
        "patch": {"owner_annotations": ["Create an outcome event with observed=0/1, observation time, evidence refs and ambiguity notes."]},
        "test": "Resolve according to the predeclared outcome definition; do not rewrite the original probability.",
    },
    "MEMORY_RECONSTRUCTION_UNMARKED": {
        "operation": "separate_memory_from_record",
        "patch": {"claim_class": "H", "dikwp": "I", "confidence": 0.6, "owner_annotations": ["This is a present reconstruction; link primary records separately when available."], "open_questions": ["Which details may be reconstruction or later interpretation?"]},
        "test": "Compare the recollection with contemporaneous records and preserve discrepancies rather than silently harmonizing them.",
    },
    "BURDEN_EXIT_GAP": {
        "operation": "add_exit_and_remedy",
        "patch": {"owner_annotations": ["Add a specific appeal, refusal, exit, compensation or repair path for every burdened stakeholder."]},
        "test": "Have the burdened party test the exit/remedy path before escalation.",
    },
    "SEMANTIC_RETURN_MISSING": {
        "operation": "design_semantic_round_trip",
        "patch": {"purpose": {"success_metrics": ["Define observable D/I returned from the intended K/W/P transformation"]}, "action": {"result_metric": "Define the record that will be compared with the original input state"}},
        "test": "Run input D→I→K/W→P/action→outcome D and quantify the non-equivalent residual.",
    },
    "DISCLOSURE_WITHOUT_CONSENT_REF": {
        "operation": "restore_owner_governed_visibility",
        "patch": {"visibility": "private", "consent_ref": "Owner must supply a specific consent/authorization reference before wider disclosure", "owner_annotations": ["Disclosure was returned to private pending owner-governed authorization."]},
        "test": "Verify the named authorizing person, intended audience, scope, expiry, revocation path and redactions before changing visibility.",
    },
}


def correction_proposals(audit: dict[str, Any]) -> list[dict[str, Any]]:
    proposals = []
    for issue in audit.get("issues", []):
        remediation = _REMEDIATIONS.get(issue["code"], {"operation": "owner_review", "patch": {"owner_annotations": ["Owner review required"]}, "test": "Define a discriminating reality-contact step."})
        seed = {"issue_id": issue["issue_id"], "operation": remediation["operation"]}
        proposals.append({
            "proposal_id": stable_id("corr", seed, 20),
            "created_at": utc_now(),
            "event_id": issue["event_id"],
            "issue_id": issue["issue_id"],
            "issue_code": issue["code"],
            "severity": issue["severity"],
            "operation": remediation["operation"],
            "reason_zh": issue["reason_zh"],
            "reason_en": issue["reason_en"],
            "proposed_patch": deepcopy(remediation["patch"]),
            "discriminating_action": remediation["test"],
            "approval_required": True,
            "approved": False,
            "automatic_application": False,
            "rollback": "The proposal does not mutate the original record. Approval appends a successor event; the successor can later be retired by another append-only record.",
            "rights_boundary": "No proposal authorizes identity simulation, diagnosis, treatment, external communication or action on the owner's behalf.",
        })
    return sorted(proposals, key=lambda p: (-p["severity"], p["event_id"], p["issue_code"]))


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        elif isinstance(value, list) and isinstance(out.get(key), list):
            # Templates are appended unless the target list is empty.
            out[key] = out[key] + [x for x in value if x not in out[key]]
        else:
            out[key] = deepcopy(value)
    return out


def approve_proposal(
    ledger_path: str,
    original_event: dict[str, Any],
    proposal: dict[str, Any],
    *,
    approver: str,
    authorization_ref: str,
) -> dict[str, Any]:
    if not approver.strip() or not authorization_ref.strip():
        raise ValueError("Named approver and authorization_ref are required")
    if original_event.get("event_id") != proposal.get("event_id"):
        raise ValueError("Proposal does not target the supplied original event")
    corrected = _deep_merge(original_event, proposal.get("proposed_patch", {}))
    corrected.pop("ledger_seq", None)
    corrected.pop("previous_digest", None)
    corrected.pop("event_digest", None)
    corrected.pop("recorded_at", None)
    corrected["event_id"] = stable_id("evt", {"original": original_event["event_id"], "proposal": proposal["proposal_id"], "authorization": authorization_ref}, 20)
    corrected["created_at"] = utc_now()
    corrected["kind"] = "correction"
    corrected["status"] = "active"
    corrected["supersedes"] = sorted(set(corrected.get("supersedes", []) + [original_event["event_id"]]))
    corrected["owner_annotations"] = corrected.get("owner_annotations", []) + [
        f"Approved correction proposal {proposal['proposal_id']} by {approver}; authorization {authorization_ref}."
    ]
    corrected["correction_metadata"] = {
        "proposal_id": proposal["proposal_id"],
        "approver": approver,
        "authorization_ref": authorization_ref,
        "proposal_digest": sha256_obj(proposal),
        "original_event_digest": original_event.get("event_digest"),
    }
    # Metadata is retained as a normalized, hash-covered correction record.
    corrected["tags"] = sorted(set(corrected.get("tags", []) + ["approved-correction", proposal["issue_code"]]))
    return append_event(ledger_path, corrected, owner_id=original_event["owner_id"])
