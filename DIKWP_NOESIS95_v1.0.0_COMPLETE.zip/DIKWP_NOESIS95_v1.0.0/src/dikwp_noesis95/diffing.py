from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import load_json, save_json, utc_now


def _load(value: dict[str, Any] | str | Path) -> dict[str, Any]:
    return load_json(value) if isinstance(value, (str, Path)) else value


def compare_bundles(old: dict[str, Any] | str | Path, new: dict[str, Any] | str | Path) -> dict[str, Any]:
    a, b = _load(old), _load(new)
    ea = {e["event_id"]: e for e in a.get("event_index", [])}
    eb = {e["event_id"]: e for e in b.get("event_index", [])}
    added = sorted(set(eb) - set(ea))
    removed_from_view = sorted(set(ea) - set(eb))
    changed = []
    for eid in sorted(set(ea) & set(eb)):
        fields = {}
        for key in ("status", "confidence", "claim_class", "dikwp", "scope", "evidence_refs", "counterevidence_refs", "world_models", "values", "purpose", "affected_worlds", "falsifiers", "open_questions", "action"):
            if ea[eid].get(key) != eb[eid].get(key):
                fields[key] = {"old": ea[eid].get(key), "new": eb[eid].get(key)}
        if fields:
            changed.append({"event_id": eid, "fields": fields})
    va = (a.get("audit") or {}).get("transparency_vector", {})
    vb = (b.get("audit") or {}).get("transparency_vector", {})
    vector_delta = {k: round(float(vb.get(k, 0)) - float(va.get(k, 0)), 4) for k in sorted(set(va) | set(vb))}
    ia = (a.get("audit") or {}).get("issue_code_counts", {})
    ib = (b.get("audit") or {}).get("issue_code_counts", {})
    issue_delta = {k: int(ib.get(k, 0)) - int(ia.get(k, 0)) for k in sorted(set(ia) | set(ib))}
    revisions = [
        {"event_id": e["event_id"], "supersedes": e.get("supersedes", []), "status": e.get("status")}
        for e in b.get("event_index", []) if e.get("supersedes")
    ]
    return {
        "generated_at": utc_now(),
        "old_compilation_id": a.get("compilation_id"),
        "new_compilation_id": b.get("compilation_id"),
        "added_event_ids": added,
        "removed_from_view_event_ids": removed_from_view,
        "changed_events": changed,
        "revision_lineage_in_new": revisions,
        "transparency_vector_delta": vector_delta,
        "issue_count_delta_by_code": issue_delta,
        "calibration": {
            "old": a.get("calibration"),
            "new": b.get("calibration"),
        },
        "interpretation_boundary": (
            "A delta describes recorded worldline changes, not a change in personal worth, intelligence, sanity, identity or consciousness. "
            "Removed-from-view records may reflect filtering or retention policy rather than erasure."
        ),
        "automatic_external_action_authority": 0,
    }


def compare_and_save(old: str | Path, new: str | Path, out: str | Path) -> dict[str, Any]:
    report = compare_bundles(old, new)
    save_json(out, report)
    return report
