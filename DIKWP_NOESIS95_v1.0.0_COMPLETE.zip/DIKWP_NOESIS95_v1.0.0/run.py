#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from dikwp_noesis95.cli import main
raise SystemExit(main())
