# NOESIS95 认知提升计划 / Cognitive Enhancement Plan

生成时间：2026-08-31T01:47:01+00:00

> This plan is educational and epistemic decision support. It is not psychotherapy, diagnosis, treatment, crisis care or a substitute for a qualified professional.

## 1. 预测—行动—结果闭环 / Prediction-action-outcome loop
维度：`reality_contact`；当前记录表现：35.8%

- 为关键判断给出概率和到期日。
- 执行经授权的最小行动或观察。
- 无论结果是否有利都回填。
- 计算Brier分数并更新模型而非改写历史。

指标：预测解决率、Brier分数、逾期率、结果回填完整率
节奏：One focused cycle per week for four weeks, then review burden and evidence before continuing.
减负边界：Stop or reduce scope if the exercise creates material distress, coercion, privacy loss, conflict escalation or opportunity cost greater than its measured learning value.
主体控制：The owner may reject, edit, pause or retire this exercise; non-completion is not treated as failure or pathology.

## 2. Ω残差日志 / Omega residual journal
维度：`residual_preservation`；当前记录表现：47.2%

- 记录异常、矛盾、低频案例和无法翻译部分。
- 禁止把残差自动归为噪声。
- 每周期选择一个残差建立新模型。
- 标记哪些残差因负担过高暂不处理。

指标：残差保留率、由残差触发的模型修订数
节奏：One focused cycle per week for four weeks, then review burden and evidence before continuing.
减负边界：Stop or reduce scope if the exercise creates material distress, coercion, privacy loss, conflict escalation or opportunity cost greater than its measured learning value.
主体控制：The owner may reject, edit, pause or retire this exercise; non-completion is not treated as failure or pathology.

## 3. 状态依赖复判 / State-dependent re-evaluation
维度：`capacity_context`；当前记录表现：66.7%

- 高影响判断时记录睡眠、压力、时间与环境。
- 在不同状态下重复最关键判断。
- 比较置信度与选择变化。
- 将稳定结论与状态依赖结论分开。

指标：状态记录率、跨状态判断漂移、延迟决定收益
节奏：One focused cycle per week for four weeks, then review burden and evidence before continuing.
减负边界：Stop or reduce scope if the exercise creates material distress, coercion, privacy loss, conflict escalation or opportunity cost greater than its measured learning value.
主体控制：The owner may reject, edit, pause or retire this exercise; non-completion is not treated as failure or pathology.

## 4. 先写失败条件 / Failure-first protocol
维度：`falsifiability`；当前记录表现：66.7%

- 在继续论证前写出主张失败的可观察条件。
- 写出竞争模型对此结果的解释。
- 设定何时降低置信度或退役模型。
- 结果出现时按规则执行。

指标：带反证入口主张比例、按规则退役率
节奏：One focused cycle per week for four weeks, then review burden and evidence before continuing.
减负边界：Stop or reduce scope if the exercise creates material distress, coercion, privacy loss, conflict escalation or opportunity cost greater than its measured learning value.
主体控制：The owner may reject, edit, pause or retire this exercise; non-completion is not treated as failure or pathology.

## 5. 信息增益优先试验 / Information-gain-first test
维度：`distinguishing_evidence`；当前记录表现：68.8%

- 列出竞争模型共同预测与分歧预测。
- 选择分歧最大且可逆的观察。
- 预先定义每个结果如何更新模型。
- 记录未能区分的原因。

指标：区分结果比例、每单位负担的信息增益
节奏：One focused cycle per week for four weeks, then review burden and evidence before continuing.
减负边界：Stop or reduce scope if the exercise creates material distress, coercion, privacy loss, conflict escalation or opportunity cost greater than its measured learning value.
主体控制：The owner may reject, edit, pause or retire this exercise; non-completion is not treated as failure or pathology.

## 防止指标绑架

Do not fill fields merely to raise scores. Empty-but-honest fields are preferable to fabricated evidence, artificial countermodels or coerced disclosure.

自动外部行动权限：0
