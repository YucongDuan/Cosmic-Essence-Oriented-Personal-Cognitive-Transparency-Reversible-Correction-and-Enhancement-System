# Security policy

## Supported release

Version 1.0.x is the supported reference line.

## Reporting

Report vulnerabilities privately to the repository maintainer before public disclosure. Include affected version, reproduction steps, expected impact and whether private cognitive records may be exposed.

## Security assumptions

The standard-library core is local-first but does not encrypt files. Operators remain responsible for disk encryption, operating-system access control, backups and secure deletion of uncompiled drafts. Do not serve a private dashboard beyond loopback. The CLI restricts the built-in server to loopback addresses.

## Prohibited security changes

A patch must not secretly transmit cognitive records, enable telemetry by default, weaken ledger/manifests without disclosure, or convert correction candidates into automatic external actions.
