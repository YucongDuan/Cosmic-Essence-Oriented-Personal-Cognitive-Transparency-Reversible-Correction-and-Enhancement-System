# 主张边界 / Claim Boundaries

## 系统可以主张什么

NOESIS95可以如实报告：

- 所提供记录是否包含来源ID、范围、置信度、竞争模型、预测、结果和修订血缘；
- 内置透明规则是否被触发；
- 概率预测在当前样本中的Brier分数和校准描述；
- 某个矫正候选将修改哪些字段；
- 输出文件与账本摘要是否完整；
- 记录与24条操作卡之间的协议对齐程度。

## 系统不能从这些结果推出什么

不能推出：

- 一个人的全部真实认知；
- 智力、人格、道德、诚实、可靠、理性或社会价值；
- 精神疾病、心理诊断、治疗需要或危机风险；
- 法律责任、证言可信度、就业适格性、保险风险或政治/宗教倾向；
- 人工系统或人的意识、人格、灵魂或主体地位；
- 六部研究书中的宇宙论命题已经成为实验确立的物理定律；
- 内部一致、数学形式、程序可运行或仪表盘漂亮等于外部真实。

## Cognitive correction boundary

“认知矫正”仅指 owner-governed epistemic record correction: source repair, confidence recalibration, scope narrowing, claim-class separation, competing-model construction, falsifier registration, reversible testing, outcome return and append-only revision.

It does not mean involuntary belief modification, behavioral control, deprogramming, clinical treatment, ideological conformity or hidden persuasion.

## Clinical and crisis boundary

NOESIS95 is not a medical device and is not psychotherapy, psychiatry, neuropsychological assessment, crisis response or a substitute for qualified care. A person experiencing urgent danger or severe distress should use appropriate local emergency or professional services rather than relying on this system.

## External action boundary

The system has no authority to publish, send messages, transact, sign, represent, diagnose, contact third parties, alter external profiles or operate infrastructure. Automatic external-action authority is fixed at 0.
