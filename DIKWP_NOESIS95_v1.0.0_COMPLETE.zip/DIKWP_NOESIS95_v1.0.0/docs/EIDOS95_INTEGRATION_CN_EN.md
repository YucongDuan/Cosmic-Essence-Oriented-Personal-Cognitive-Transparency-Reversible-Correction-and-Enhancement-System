# EIDOS95 Integration

## Purpose

EIDOS95 and NOESIS95 solve different problems:

- EIDOS95 compresses accumulated content and experience into source-grounded essence signatures while exposing attribution and compression loss.
- NOESIS95 evaluates live, consequential cognitive records and closes the prediction–outcome–revision loop.

## Import behavior

Use:

```bash
python run.py compile \
  --owner owner.json \
  --ledger cognitive_ledger.jsonl \
  --evidence evidence.json \
  --eidos /path/to/essence_bundle.json \
  --out output
```

NOESIS95:

1. checks the EIDOS bundle digest when available;
2. checks owner ID compatibility;
3. imports only source-grounded signatures, declared models, rights audit and claim boundaries as context;
4. marks the EIDOS context as a revisable prior map;
5. does not treat recurring concepts as immutable identity or proof of truth.

## Anti-lock-in rule

A later cognitive event may contradict an EIDOS signature. The contradiction must remain visible. EIDOS recurrence does not overrule prospective evidence, owner correction or reality outcomes.

## Privacy

Import is local. The reference implementation sends no content to a network service. Users should still store both bundles with appropriate filesystem encryption and access control when they contain private material.
