# DIKWP-NOESIS 9.5 形式规范

## 1. 认知世界线，而非静态人格

在时刻 `t`，系统只描述所有者主动登记或明确导入的认知记录状态：

```text
C_t = <R_t, E_t, M_t, Q_t, O_t, V_t, G_t, H_t, Ω_t>
```

其中：

- `R_t`：D/I/K/W/P 与 E/H/F/P/N 双重分型的认知事件集合；
- `E_t`：来源、反证、独立依赖组、质量、权利和可见性账本；
- `M_t`：竞争世界模型及其假设、预测、区分试验和退役条件；
- `Q_t`：带概率、到期时间和预先结算规则的预测集合；
- `O_t`：通过 `prediction_id` 回填的现实结果；
- `V_t`：价值、受益者、负担承担者、冲突与测量方式；
- `G_t`：目的的输入、期望状态、输出、指标、停止和回滚条件；
- `H_t`：版本、前序、修订、批准与授权血缘；
- `Ω_t`：未知、矛盾、异常、不可安全披露和当前语义空间无法承载的残差。

`C_t` 不是人的全部认知，也不是人格、智力、道德、意识或心理健康表征。未登记内容保持未知；未知不得被自动解释为缺陷、隐瞒、同意或不存在。

## 2. 双重语义分型

每条事件至少经过两个相互独立的映射：

```text
σ_DIKWP : R → {D, I, K, W, P}
σ_claim : R → {E, H, F, P, N}
```

第一映射描述语义功能位置：数据/同义登记、差异信息、可复用知识、价值配置、输入—输出目的。第二映射描述证据纪律：来源约束成果、历史解释、形式构造、经验假说、规范或形而上提案。

这两个字母空间不可混用。尤其：

- `P`（DIKWP）是目的位置；
- `P`（claim class）是需要经验结算的假说；
- `F` 的内部一致不自动推出经验真实；
- `N` 的价值正当性不能由概率或形式完整性替代；
- `E` 只能在其来源、对象、尺度和时间边界内继承。

## 3. 追加式连续

所有认知修订采用后继关系：

```text
C_{t+1} = append(C_t, revision(old_id, new_record, reason, evidence, approver, authorization))
```

禁止：

```text
overwrite(old_record)
```

每条账本记录包含序号、前序摘要和自身摘要：

```text
d_i = SHA256(canonical(record_i_without_digest))
record_i.previous_digest = d_{i-1}
```

哈希链提供篡改可见性，不提供输入真实性保证，也不替代签名、加密、访问控制或可信时间戳。

## 4. 非同构世界模型竞技场

对高影响主张 `r`，候选模型集合为：

```text
M(r) = {m_1, m_2, ..., m_k},  k ≥ 2
```

模型多元不能只靠同义改写。参考实现要求候选之间至少在以下一项上形成实质差异：

- 模型家族或因果结构；
- 核心假设；
- 预期观察；
- 区分试验；
- 会导致相反更新的结果；
- 失败或退役条件。

真正的区分情境 `x` 应满足：

```text
Update(m_i | x) ≠ Update(m_j | x)
```

启发式检测只能发现明显伪多元，不能替代领域专家判断。

## 5. 预测—结果—校准

预测 `q_i` 必须在结果已知前登记概率 `p_i ∈ [0,1]`、到期时间和结算规则。二元结果 `y_i ∈ {0,1}` 通过独立结果事件追加。

Brier 分数：

```text
Brier = (1/n) Σ_i (p_i - y_i)^2
```

对数损失使用数值截断以避免 `log(0)`。校准区间按概率桶分别展示平均预测和实际频率，并报告样本量、待解决、逾期和选择边界。

任何校准统计都仅描述被登记、可结算的预测样本，不是稳定人格分数。跨领域、跨时间和不同结算质量的结果不得无条件聚合。

## 6. 透明度向量

系统输出十六维记录透明度向量：

```text
T(C_t) = <
 provenance, scope, uncertainty, claim_discipline,
 dikwp_separation, model_plurality, distinguishing_evidence,
 value_visibility, purpose_executability, affected_worlds,
 falsifiability, reversibility, reality_contact,
 revision_continuity, residual_preservation, capacity_context
>
```

每一维回答不同问题，维度之间不可互相抵消。实现可给出 `navigation_mean` 以便界面排序，但必须同时声明：

```text
navigation_mean ≠ person_score
```

不得把透明度向量或其均值转换为就业、保险、信贷、教育、医疗、法律、政治、意识形态、人格、智力、心理健康或社会价值判断。

## 7. 结构性问题检测

审计器只检测记录结构中的认识论风险，例如：

- 高置信、低证据或低范围声明；
- 全称化和不可证伪表达；
- 把形式闭合冒充经验成立；
- 高影响判断只有一个模型；
- 模型只有措辞差异；
- 价值、受益者和负担被隐藏；
- 行动不可逆、外部化且无授权；
- 预测没有结算规则或长期不回填；
- 记忆重构冒充同期原始记录；
- 修订覆盖而不保留血缘。

问题代码针对事件，不裁决人格。规则未触发不等于主张为真，规则触发也不等于主张为假。

## 8. 可逆矫正事务

审计结果 `z_t = A(C_t)` 可生成候选提案：

```text
q_t = Propose(z_t, C_t)
```

提案状态：

```text
approval ∈ {pending, rejected, accepted}
```

只有 `accepted` 且具备具名批准者和授权引用时，系统才能追加新的 `correction` 事件。提案可以要求：

- 补充来源或反证；
- 缩小范围；
- 降低或重新校准置信度；
- 拆分主张类别；
- 增加非同构模型；
- 预写失败条件；
- 执行最小、可逆、可停止的现实试验；
- 补录结果；
- 修订或退役模型。

系统不得自动改写原事件，不得把拒绝提案解释为病理或不合作，也不得自动实施外部行动。

## 9. 选择性透明与可见性

每个事件和证据记录可标注：

```text
visibility ∈ {private, trusted_reviewer, public}
```

选择性导出遵循所有者配置。过滤后的公开包不是完整账本；缺失记录可能是私有、未登记、被撤回或超出范围。缺失不构成同意、虚假或能力不足的证据。

可访问数据不自动授予解释权、身份模拟权、商业使用权、临床使用权、官方代表权或外部行动权。

## 10. 24条工作规律的形式地位

每张规律卡 `U_j` 包含：

```text
U_j = <status, proposition, operational_rule,
       falsifier_entry_points, applicability,
       retirement_condition, provenance, version>
```

其中 `status` 只能是本体工作命题、形式协议、研究假说、经验方法或规范约束之一。软件只能报告记录与操作规则的对齐，不得从对齐推出宇宙论、物理学或意识论命题已被实验确立。

## 11. “终极”的开放定义

NOESIS95 将“终极”实现为最大限度的责任闭环，而不是不可修改的最终结论：

```text
Ultimate_open = provenance
              + explicit_scope
              + claim_separation
              + plural_models
              + falsifiability
              + reality_return
              + burden_visibility
              + consent
              + reversibility
              + append_only_revision
              + successor_freedom
              + explicit_Ω
```

任何当前闭合都必须留下反例入口、现实回返、退役条件和后继世界重新开始的自由。

## 12. 权限不变量

参考实现的硬不变量：

```text
automatic_external_action_authority = 0
```

系统可以在本地生成分析、提案、仪表盘、差分和选择性透明包，但不能自动发布、通信、交易、签署、代表、诊断、治疗、操作外部基础设施或对他人实施认知干预。
