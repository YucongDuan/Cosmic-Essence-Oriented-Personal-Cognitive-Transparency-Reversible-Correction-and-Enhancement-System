# 24条宇宙本质导向认知工作规律
# 24 Cosmic-Essence-Oriented Cognitive Working Laws

## 认识论边界 / Epistemic boundary

这些卡片不是一组已经由实验共同确立的“终极物理定律”或“意识定律”。它们被分别标注为：

- 本体工作命题；
- 形式协议；
- 研究假说；
- 经验方法；
- 规范约束。

每张卡都有操作规则、反例入口和退役条件。软件对齐只表示认知记录体现了相应协议，不证明宇宙论命题为真。

These cards are not collectively asserted as experimentally established final laws of physics or consciousness. Each card is a versioned ontological working proposition, formal protocol, research hypothesis, empirical method or normative constraint. Software alignment indicates record-level protocol support, not cosmic proof.

## 注册表 / Registry

| ID | 中文 | English | Status |
|---|---|---|---|
| U01 | 无外部整体与局部视点 | Outside-less whole and local viewpoint | ontological working proposition |
| U02 | 发生先于对象 | Occurrence before object | ontological working proposition |
| U03 | 有后果差异 | Consequential difference | research hypothesis |
| U04 | 关系生成实体 | Relational generation of entities | ontological working proposition |
| U05 | 局部完备不等于全局终局 | Local closure without global finality | formal protocol |
| U06 | DIKWP语义位置分离 | DIKWP positional separation | formal protocol |
| U07 | 追加式连续性 | Append-only continuity | formal protocol |
| U08 | 差异保真 | Difference preservation | formal protocol |
| U09 | 记录级路径 | Record-level path | formal protocol |
| U10 | 价值操作化 | Operationalized value | normative constraint |
| U11 | 目的作为输入输出契约 | Purpose as input-output contract | formal protocol |
| U12 | 双向再生与同语义返回 | Bidirectional regeneration and semantic return | research hypothesis |
| U13 | 生成性残差 | Generative residual | ontological working proposition |
| U14 | 非同构多世界模型 | Non-isomorphic multiple world models | formal protocol |
| U15 | 现实接触与校准 | Reality contact and calibration | empirical method |
| U16 | 记忆是主动重构 | Memory as active reconstruction | research hypothesis |
| U17 | 身份是可修订连续性 | Identity as revisable continuity | ontological working proposition |
| U18 | 能动性、拒绝与可逆性 | Agency, refusal and reversibility | normative constraint |
| U19 | 不对称与负担可见 | Asymmetry and burden visibility | normative constraint |
| U20 | 不输出毁灭的开放负熵 | Open negentropy without exported destruction | normative constraint |
| U21 | 后继世界自由 | Successor-world freedom | normative constraint |
| U22 | 具身时间承载 | Embodied temporal bearing | research hypothesis |
| U23 | 信号不等于语义主权 | Signal is not semantic sovereignty | normative constraint |
| U24 | 终极理论必须包含非终局性 | An ultimate theory must include its non-finality | ontological working proposition |

完整、机器可读的命题、操作规则、反例入口、适用域和退役条件位于：

- `config/COSMIC_LAW_REGISTRY.json`
- `src/dikwp_noesis95/data/cosmic_laws.json`

## 从宇宙命题到个人认知协议 / Translation to personal cognition

宇宙层的概念不能直接越权成为心理或物理事实。NOESIS95只做有边界的协议翻译：

- “无外部整体”翻译为：个人判断必须声明观察位置与不可见残差；
- “发生先于对象”翻译为：身份标签要回到历史、关系和修订条件；
- “有后果差异”翻译为：关键差异应产生可预期、可观测的后果；
- “追加连续性”翻译为：认知修订不静默覆盖；
- “非同构模型”翻译为：高影响决定必须有能被现实区分的竞争解释；
- “现实再进入”翻译为：预测和行动必须回填结果；
- “生成性残差”翻译为：异常、未决和不可安全披露部分不能被自动抹平；
- “主体性与信号主权”翻译为：可访问数据不等于可代表、可解释、可商业化或可强制矫正。

这种翻译本身记录为可修订设计选择，而不是宇宙命题的自动证明。
