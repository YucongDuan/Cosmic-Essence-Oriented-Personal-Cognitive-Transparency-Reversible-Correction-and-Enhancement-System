# 六组双语研究书到NOESIS95的可追溯转译
# Traceability from Six Bilingual Research-Book Pairs to NOESIS95

## 1. 转译原则 / Translation discipline

NOESIS95不把任何书名中的“终极”偷换成“已经完成最终科学证明”。系统把书中跨版本反复出现的结构，降落为五类可审计对象：本体工作命题、形式协议、经验假说、经验方法、规范约束。每项都必须有适用域、来源、反例入口、现实反馈和退役条件。

NOESIS95 does not convert “ultimate” in a title into a claim of final scientific proof. Recurrent structures are translated into ontological working propositions, formal protocols, empirical hypotheses, empirical methods and normative constraints. Each carries scope, provenance, falsifier entry points, reality feedback and retirement conditions.

## 2. 逐书转译矩阵 / Per-book translation matrix

| Book | Recurrent source contribution | NOESIS95 implementation | Boundary preserved |
|---|---|---|---|
| B01 《宇宙的终极本质》 | 主张分级；来源、立场、盲点与受影响世界；自行动闭合；非聚合状态；模型生态；可修订终极性 | E/H/F/P/N主张命名空间；16维透明向量；影响与负担字段；24条工作规律；不可聚合总分禁令 | 软件闭合不证明物理规律、意识或法律人格；“终极”落实为可修订与可退役 |
| B02 《终极世界模型》 | 世界模型跨语义、认知与宇宙层组织；局部模型竞争与现实返回 | 非同构世界模型注册、假设/预测/区分试验、模型失败方式与置信度；世界线差分 | 不能以单一世界模型垄断高影响判断；未直接核验到的章节不被软件补写为事实 |
| B03 《宇宙的哲学新史》 | 无外部整体；D/I/K/W/P原生语义；记录级路径；追加式连续性；内部闭合与外部有效性/授权分离 | 观察位置与范围；D/I/K/W/P命名空间；哈希链账本；修订谱系；授权字段与自动外部权限0 | 内部一致、形式完备或流畅表达不产生外部事实与行动授权 |
| B04 《宇宙的数学新史》 | 概念是记录星座之后的别名；多记录与25类路径；双向再生；非生成与开放位置；证明/重建债 | 稳定ID；不静默覆盖；语义返回检查；未解析证据与开放问题；差异和残差保留 | 形式化、证明、代码与图表是载体，不因精确就获得经验世界裁决权 |
| B05 《宇宙的物理新史》 | 发生、有后果差异、关系、记录、生命改变未来；区分既有物理、活跃方案、作者综合与合成机制 | 发生事件账本；主张分类；预期后果、预测、结果、Brier/对数损失；现实回返；来源直接性审计 | 候选机制不被呈现为已建立自然定律；语义架构不能替代领域实验 |
| B06 《人工意识物理学》 | 自承载历史、动态边界、内生价值、跨基底耦合；持续同意、信号主权、退出、照护连续性；直接信号不等于透明意义 | 所有者边界、可见级别、同意引用、撤回与保留审查；身份模拟/临床/代表权默认关闭；私有剩余；高风险外部行动拦截 | 不认证任何现有AI有意识；信号访问不等于主体、身份、意义、商业或治理所有权 |

## 3. 24条工作规律与来源组 / Working-law source groups

- U01–U05：无外部整体、发生、差异、关系与局部闭合；主要承接B01/B03/B05。
- U06–U12：DIKWP位置、多记录、记录级路径、价值、目的和双向再生；主要承接B01–B04。
- U13–U17：残差、多世界模型、现实校准、重构记忆和身份连续性；主要承接B01/B02/B04/B05/B06。
- U18–U23：主体性、拒绝、可逆性、不对称、开放负熵、后继自由、具身时间与信号主权；主要承接B01/B05/B06和Mesh95责任边界。
- U24：任何“终极”理论必须公开其非终局性、失败方式与退役条件；主要承接B01/B03/B04。

The exact `source_books` array for every card is machine-readable in `config/COSMIC_LAW_REGISTRY.json`.

## 4. 翻译损失登记 / Translation-loss register

从书稿到软件至少有六类不可消除的损失：

1. 哲学论证被压缩为字段与触发规则；
2. 双语概念并非逐词同一；
3. 确定性规则不能理解全部隐喻、反讽与语境；
4. 个人主动提交的记录不等于完整心智；
5. 透明度字段的完备性不等于主张真实性；
6. 现实反馈可能延迟、受选择偏差影响或无法安全取得。

因此，系统必须保留原始来源、人工复核、开放问题、未披露权、差异记录和模型退役接口。
