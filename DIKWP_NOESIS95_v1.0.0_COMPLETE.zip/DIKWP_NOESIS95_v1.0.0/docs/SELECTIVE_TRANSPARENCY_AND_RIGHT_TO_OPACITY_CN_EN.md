# 选择性透明与不透明权
# Selective Transparency and the Right to Opacity

认知透明不是无边界曝光。NOESIS95采用三层可见性：

- `private`：仅所有者本地审阅；
- `trusted_reviewer`：仅具名、经授权的审阅者；
- `public`：所有者明确同意公开的方法或记录。

每条事件与证据可携带`consent_ref`、`retention_review_at`和`redaction_tags`。公开导出会过滤私密记录和`owner_only_notes`，并声明它只是选择性视图，不是完整哈希链。

The system treats absence as ambiguous. A missing item may be private, withheld, unrecorded, forgotten, unsafe to disclose or outside scope. It must not be interpreted as consent, falsehood, deficiency, guilt or a stable trait.

公开材料、开源代码、可访问脑机信号或平台数据都不自动授予身份模拟、声音克隆、临床使用、就业筛选、商业利用、官方代表或外部行动权。自动外部行动权限固定为0。
