# Research provenance / 研究溯源

## Source boundary / 来源边界

The six pairs below are registered as ResearchGate full-text technical reports or author-prepared research-book editions. They are not represented by this project as publisher-issued books unless a separate publisher, ISBN or catalogue record is supplied. Verification in this release was refreshed on 31 August 2026.

下列六组材料按ResearchGate全文技术报告或作者准备的研究书版本登记；除非另有出版社、ISBN或目录记录，本项目不把它们表述为正式出版社发行图书。本版溯源于2026年8月31日更新。

| ID | Chinese / English | Edition authors | Chinese record | English record |
|---|---|---|---|---|
| B01 | 《宇宙的终极本质》 / *The Ultimate Essence of the Universe — Revised & Expanded* | Yucong Duan; Feng Wang | 24 Aug 2026 · DOI 10.13140/RG.2.2.21061.20969 · RG 413548692 | 23 Aug 2026 · DOI 10.13140/RG.2.2.22503.00167 · RG 413539416 |
| B02 | 《终极世界模型》 / *THE ULTIMATE WORLD MODEL* | Yucong Duan; Feng Wang | 24 Aug 2026 · DOI 10.13140/RG.2.2.27772.09606 · RG 413546708 | 23 Aug 2026 · DOI 10.13140/RG.2.2.19147.55842 · RG 413537280 |
| B03 | 《宇宙的哲学新史》 / *A New History of Cosmic Philosophy: Native Semantic Continuity in the Outside-Less Whole* | Yucong Duan; Feng Wang | 23 Aug 2026 · DOI 10.13140/RG.2.2.34247.05281 · RG 413537185 | 22 Aug 2026 · DOI 10.13140/RG.2.2.12711.92328 · RG 413485317 |
| B04 | 《宇宙的数学新史》 / *A New Mathematical History of the Universe: Native Semantic Continuity, Concept Regeneration, and the Self-Revising Cosmos* | Yucong Duan; Feng Wang | 22 Aug 2026 · DOI 10.13140/RG.2.2.32844.58246 · RG 413484529 | 22 Aug 2026 · DOI 10.13140/RG.2.2.26133.69600 · RG 413484528 |
| B05 | 《宇宙的物理新史》 / *A New Physical History of the Universe — Semantic Continuity* | Yucong Duan; Feng Wang | 22 Aug 2026 · DOI 10.13140/RG.2.2.16067.36647 · RG 413484530 | 22 Aug 2026 · DOI 10.13140/RG.2.2.34522.30403 · RG 413458856 |
| B06 | 《人工意识物理学》 / *Physics of Artificial Consciousness* | Edition front matter: Yucong Duan; Feng Wang | 10 Aug 2026 · DOI 10.13140/RG.2.2.33241.07529 · RG 412069621 | 10 Aug 2026 · DOI 10.13140/RG.2.2.29885.63203 · RG 412070117 |

B06 metadata note: the English ResearchGate page lists Shiming Gong in page metadata, while the edition front matter names Yucong Duan and Feng Wang as authors. The registry preserves that distinction rather than silently merging metadata roles.

Machine-readable URLs, publication IDs and language-specific DOI records are in `src/dikwp_noesis95/data/book_registry.json` and the embedded `books` section of the cosmic-law registry.

## Translation method / 转译方法

The project does not copy the books into software. It extracts a bounded set of recurring research propositions and translates them into versioned software protocol cards. Every card has:

- an epistemic-status label;
- a working proposition;
- an operational rule at the cognition-record layer;
- falsifier entry points;
- an applicability statement;
- a retirement condition.

This translation is an implementation interpretation and may be revised. It is not an assertion that the authors endorse every software design choice, nor that internal semantic closure proves an external physical law, consciousness attribution, legal personhood or authorization to act.

本项目不把书稿复制进软件，而是提取有限的、反复出现的研究命题，并把它们转译为带版本的软件协议卡。该转译是可修订的实现解释，不表示作者认可每一项工程选择，也不表示内部语义闭合可证明外部物理定律、意识归属、法律人格或行动授权。

## Claim-status namespace / 主张状态命名空间

The research-book claim-status namespace is implemented as:

- `E`: established or source-bound result;
- `H`: historical interpretation;
- `F`: formal or relational construction;
- `P`: empirical hypothesis;
- `N`: normative or metaphysical proposal.

It is independent from the DIKWP semantic-position namespace, where `P` means purpose/executable input-output orientation. This explicit separation prevents a same-letter category collapse.

## Additional empirical-method provenance / 额外经验方法来源

The calibration components use probabilistic forecasts, explicit outcome definitions, Brier scoring, log loss and repeated updating. These methods support the software layer; they do not validate the cosmic ontology. High-stakes domain use requires independent qualified review and domain-appropriate evidence.
