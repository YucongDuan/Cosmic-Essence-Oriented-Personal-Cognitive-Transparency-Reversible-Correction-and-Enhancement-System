# Contributing

1. Preserve the owner-governed, append-only and zero-external-authority boundaries.
2. Add tests for every new audit rule, schema field and migration.
3. Separate descriptive claims, formal protocol choices and normative commitments.
4. Do not add a total cognition/personality score.
5. Do not label record patterns as mental disorders or use clinical terminology without an appropriately regulated, separately governed product.
6. Keep the core usable without network access or proprietary models.
7. Document translation loss and false-positive/false-negative risks.

Run:

```bash
python -m unittest discover -s tests -v
python scripts/validate_release.py
```
