# Workspace templates

Copy `owner.json`, `config.json`, `event.json` and `evidence.json` into a private workspace, replace placeholders, then append the event through the CLI. Do not edit a signed ledger line manually; corrections are successor events.
