# Software provenance

- System design: DIKWP-NOESIS 9.5 reference implementation.
- Parent architecture: Mesh95 owner agency, evidence permissions, multiple world models, reversible intervention, reality contact, calibration, revision and responsibility handoff.
- Upstream context format: DIKWP-EIDOS 9.5 source-grounded cognitive essence bundle.
- Research programme attribution: Yucong Duan; six bilingual August 2026 research-book/technical-report pairs with Feng Wang are registered in `docs/RESEARCH_PROVENANCE.md`.
- Implementation boundary: this code is an engineering translation and does not imply author endorsement of every rule or establish the books' ontological claims as empirical laws.
