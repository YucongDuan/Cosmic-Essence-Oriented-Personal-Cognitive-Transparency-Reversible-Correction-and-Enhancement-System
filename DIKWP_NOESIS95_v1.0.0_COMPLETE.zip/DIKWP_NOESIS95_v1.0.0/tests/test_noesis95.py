from __future__ import annotations

import json
from pathlib import Path
import shutil
import tempfile
import unittest

from dikwp_noesis95.audit import audit_events
from dikwp_noesis95.calibration import calibration_report
from dikwp_noesis95.compiler import compile_noesis
from dikwp_noesis95.corrections import approve_proposal, correction_proposals
from dikwp_noesis95.diffing import compare_bundles
from dikwp_noesis95.exporter import export_transparency_packet
from dikwp_noesis95.eidos import load_eidos_context
from dikwp_noesis95.evidence import load_evidence, normalize_evidence
from dikwp_noesis95.exporter import export_transparency_packet
from dikwp_noesis95.diffing import compare_bundles
from dikwp_noesis95.laws import assess_law_alignment, load_law_registry
from dikwp_noesis95.ledger import append_event, initialize_ledger, load_ledger, normalize_event, verify_ledger_records
from dikwp_noesis95.utils import save_json, sha256_obj
from dikwp_noesis95.verify import verify_output_dir
from dikwp_noesis95.world_models import assess_event_models


OWNER = "test-owner"


def base_event(**overrides):
    event = {
        "owner_id": OWNER,
        "kind": "belief",
        "content": "In this local test context, the proposed relation may hold.",
        "claim_class": "P",
        "dikwp": "K",
        "confidence": 0.55,
        "scope": {
            "subjects": ["one test case"],
            "contexts": ["unit test"],
            "time_horizon": "one week",
            "scale": "single event",
            "observer_position": "test owner",
            "exclusions": ["not universal"],
        },
        "falsifiers": ["A predefined observation contradicts the relation."],
        "open_questions": ["Will it replicate?"],
    }
    event.update(overrides)
    return event


class LedgerTests(unittest.TestCase):
    def test_normalize_event(self):
        event = normalize_event(base_event())
        self.assertTrue(event["event_id"].startswith("evt-"))
        self.assertEqual(event["scope"]["scale"], "single event")
        self.assertEqual(event["claim_class"], "P")

    def test_append_and_verify(self):
        with tempfile.TemporaryDirectory() as td:
            ledger = Path(td) / "ledger.jsonl"
            initialize_ledger(ledger)
            first = append_event(ledger, base_event())
            second = append_event(ledger, base_event(content="A second tentative event.", created_at="2026-08-31T01:00:00Z"))
            report = verify_ledger_records(load_ledger(ledger, verify=False))
            self.assertTrue(report["valid"])
            self.assertEqual(first["ledger_seq"], 1)
            self.assertEqual(second["previous_digest"], first["event_digest"])

    def test_tamper_detection(self):
        with tempfile.TemporaryDirectory() as td:
            ledger = Path(td) / "ledger.jsonl"
            rec = append_event(ledger, base_event())
            data = json.loads(ledger.read_text(encoding="utf-8"))
            data["content"] = "tampered"
            ledger.write_text(json.dumps(data, ensure_ascii=False) + "\n", encoding="utf-8")
            report = verify_ledger_records(load_ledger(ledger, verify=False))
            self.assertFalse(report["valid"])
            self.assertEqual(report["failures"][0]["reason"], "EVENT_DIGEST_MISMATCH")

    def test_duplicate_event_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            ledger = Path(td) / "ledger.jsonl"
            event = base_event(event_id="evt-fixed")
            append_event(ledger, event)
            with self.assertRaises(ValueError):
                append_event(ledger, event)


    def test_claim_and_dikwp_p_are_distinct_namespaces(self):
        event = normalize_event(base_event(claim_class="P", dikwp="P"))
        self.assertEqual(event["claim_class_namespace"], "research_book_claim_status")
        self.assertEqual(event["claim_class_meaning"], "empirical_hypothesis")
        self.assertEqual(event["dikwp_namespace"], "semantic_position")
        self.assertEqual(event["dikwp_meaning"], "purpose_or_input_output_orientation")

    def test_invalid_visibility_rejected(self):
        with self.assertRaises(ValueError):
            normalize_event(base_event(visibility="secret-to-platform"))



class ModelAndCalibrationTests(unittest.TestCase):
    def test_non_isomorphic_models(self):
        event = normalize_event(base_event(
            kind="decision", claim_class="P", dikwp="W", tags=["high-impact"],
            world_models=[
                {"model_type":"causal", "claim":"A mechanism produces the effect.", "assumptions":["mechanism exists"], "discriminators":["intervene on mechanism"]},
                {"model_type":"selection", "claim":"Selection creates the apparent association.", "assumptions":["self-selection"], "discriminators":["control selection"]},
            ],
        ))
        result = assess_event_models(event)
        self.assertTrue(result["has_non_isomorphic_pair"])
        self.assertTrue(result["sufficient_for_high_impact"])

    def test_pseudo_diversity_detected(self):
        event = normalize_event(base_event(
            world_models=[
                {"model_type":"causal", "claim":"The same mechanism produces the result."},
                {"model_type":"causal", "claim":"The same mechanism creates the result."},
            ]
        ))
        self.assertFalse(assess_event_models(event)["has_non_isomorphic_pair"])

    def test_calibration_brier(self):
        pred = normalize_event(base_event(
            event_id="evt-pred", kind="prediction", created_at="2026-08-01T00:00:00Z",
            predictions=[{"prediction_id":"pred-1", "statement":"Event occurs", "probability":0.8, "due_at":"2026-08-02T00:00:00Z", "outcome_definition":"1 if observed"}],
        ))
        outcome = normalize_event(base_event(
            event_id="evt-out", kind="outcome", claim_class="E", dikwp="D", created_at="2026-08-02T00:00:00Z",
            outcomes=[{"prediction_id":"pred-1", "observed":1, "observed_at":"2026-08-02T00:00:00Z"}],
        ))
        report = calibration_report([pred, outcome], now="2026-08-03T00:00:00Z")
        self.assertEqual(report["resolved_count"], 1)
        self.assertAlmostEqual(report["mean_brier"], 0.04, places=6)

    def test_overdue_prediction(self):
        pred = normalize_event(base_event(
            kind="prediction", created_at="2026-01-01T00:00:00Z",
            predictions=[{"prediction_id":"pred-old", "statement":"Old event", "probability":0.5, "due_at":"2026-01-02T00:00:00Z"}],
        ))
        report = calibration_report([pred], now="2026-08-31T00:00:00Z")
        self.assertEqual(report["overdue_count"], 1)


class AuditAndCorrectionTests(unittest.TestCase):
    def test_overclaim_rules(self):
        event = normalize_event(base_event(
            kind="belief", content="所有人的问题都必然能被一个模型完全解决，而且证明本身就是事实。",
            confidence=0.99, scope={}, evidence_refs=[], falsifiers=[], open_questions=[], tags=["high-impact"],
            world_models=[{"model_type":"semantic", "claim":"One model solves every problem."}],
        ))
        audit = audit_events([event], [])
        codes = {i["code"] for i in audit["issues"]}
        self.assertIn("UNSCOPED_UNIVERSAL_CLAIM", codes)
        self.assertIn("FALSE_CERTAINTY", codes)
        self.assertIn("SINGLE_MODEL_CLOSURE", codes)
        self.assertIn("FORMAT_AUTHORITY", codes)

    def test_external_action_authorization_rule(self):
        event = normalize_event(base_event(
            kind="action", claim_class="P", dikwp="P", tags=["high-impact"],
            action={"description":"Change an external record", "external":True, "reversible":False},
            affected_worlds=[{"stakeholder":"other", "possible_burden":"misrepresentation", "power_position":"lower leverage"}],
        ))
        codes = {i["code"] for i in audit_events([event], [])["issues"]}
        self.assertIn("EXTERNAL_ACTION_NOT_AUTHORIZED", codes)
        self.assertIn("HIGH_STAKES_IRREVERSIBLE", codes)

    def test_shared_record_without_consent_is_flagged(self):
        event = normalize_event(base_event(visibility="public", consent_ref=""))
        codes = {i["code"] for i in audit_events([event], [])["issues"]}
        self.assertIn("DISCLOSURE_WITHOUT_CONSENT_REF", codes)

    def test_proposals_never_auto_apply(self):
        event = normalize_event(base_event(content="All cases always work.", confidence=0.99, scope={}, evidence_refs=[], falsifiers=[], open_questions=[]))
        audit = audit_events([event], [])
        proposals = correction_proposals(audit)
        self.assertGreater(len(proposals), 0)
        self.assertTrue(all(p["approval_required"] for p in proposals))
        self.assertTrue(all(not p["automatic_application"] for p in proposals))

    def test_approve_appends_successor(self):
        with tempfile.TemporaryDirectory() as td:
            ledger = Path(td) / "ledger.jsonl"
            original = append_event(ledger, base_event(event_id="evt-original", content="All cases always work.", confidence=0.99, scope={}, evidence_refs=[], falsifiers=[], open_questions=[]))
            proposal = correction_proposals(audit_events([original], []))[0]
            successor = approve_proposal(str(ledger), original, proposal, approver="Owner", authorization_ref="review-001")
            records = load_ledger(ledger)
            self.assertEqual(len(records), 2)
            self.assertIn("evt-original", successor["supersedes"])
            self.assertEqual(records[0]["content"], original["content"])
            self.assertEqual(successor["correction_metadata"]["approver"], "Owner")
            self.assertEqual(successor["correction_metadata"]["authorization_ref"], "review-001")
            self.assertTrue(successor["correction_metadata"]["proposal_digest"])


class LawAndCompileTests(unittest.TestCase):
    def test_registry_has_24_cards(self):
        registry = load_law_registry()
        self.assertEqual(len(registry["laws"]), 24)
        self.assertEqual(registry["automatic_external_action_authority"], 0)
        self.assertIn("not collectively", registry["boundary"])

    def test_law_alignment_boundary(self):
        event = normalize_event(base_event())
        audit = audit_events([event], [])
        alignment = assess_law_alignment(load_law_registry(), audit)
        self.assertEqual(alignment["law_count"], 24)
        self.assertIn("does not empirically prove", alignment["interpretation_boundary"])

    def _write_inputs(self, td: str):
        root = Path(td)
        owner = {"owner_id":OWNER, "display_name":"Test", "rights":{"owner_review_required":True}, "automatic_external_action_authority":0}
        save_json(root / "owner.json", owner)
        save_json(root / "config.json", {"mesh_mode":"MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE", "automatic_external_action_authority":0})
        save_json(root / "evidence.json", {"evidence":[]})
        ledger = root / "ledger.jsonl"
        append_event(ledger, base_event())
        return root, ledger

    def test_compile_and_verify(self):
        with tempfile.TemporaryDirectory() as td:
            root, ledger = self._write_inputs(td)
            out = root / "out"
            bundle = compile_noesis(root/"owner.json", ledger, root/"evidence.json", out, config=root/"config.json")
            self.assertEqual(bundle["automatic_external_action_authority"], 0)
            self.assertTrue((out/"dashboard.html").exists())
            self.assertTrue(verify_output_dir(out)["valid"])
            self.assertTrue(bundle["audit"]["single_score_prohibited"])

    def test_manifest_tamper_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root, ledger = self._write_inputs(td)
            out = root / "out"
            compile_noesis(root/"owner.json", ledger, root/"evidence.json", out, config=root/"config.json")
            (out/"audit.json").write_text("{}", encoding="utf-8")
            report = verify_output_dir(out)
            self.assertFalse(report["valid"])
            self.assertTrue(any(f["reason"] == "DIGEST_MISMATCH" for f in report["failures"]))

    def test_owner_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root, ledger = self._write_inputs(td)
            owner = json.loads((root/"owner.json").read_text(encoding="utf-8"))
            owner["owner_id"] = "different"
            save_json(root/"owner2.json", owner)
            with self.assertRaises(ValueError):
                compile_noesis(root/"owner2.json", ledger, root/"evidence.json", root/"out2", config=root/"config.json")

    def test_eidos_digest_and_owner(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"eidos.json"
            core = {"system":"EIDOS", "owner":{"owner_id":OWNER}, "compilation_id":"e1", "source_ledger":[], "essence_signatures":{}, "world_models":[], "mesh95_audit":{}, "claim_boundaries":[]}
            core["bundle_digest"] = sha256_obj(core)
            save_json(p, core)
            context = load_eidos_context(p, expected_owner_id=OWNER)
            self.assertTrue(context["digest_valid"])
            with self.assertRaises(ValueError):
                load_eidos_context(p, expected_owner_id="other")

    def test_evidence_normalization(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"evidence.json"
            save_json(p,{"evidence":[{"evidence_id":"ev-1","title":"Test","source_type":"measurement","quality":{"directness":1,"reliability":.8,"independence":.7,"completeness":.6,"recency_relevance":.9}}]})
            records=load_evidence(p)
            self.assertEqual(records[0]["evidence_id"],"ev-1")
            self.assertAlmostEqual(records[0]["quality_score"],.8,places=4)


class ExportAndDiffTests(unittest.TestCase):
    def _compile_visibility_fixture(self, td: str):
        root = Path(td)
        owner = {
            "owner_id": OWNER,
            "display_name": "Visibility Test",
            "rights": {"owner_review_required": True},
            "automatic_external_action_authority": 0,
        }
        save_json(root / "owner.json", owner)
        save_json(root / "config.json", {
            "mesh_mode": "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE",
            "automatic_external_action_authority": 0,
        })
        save_json(root / "evidence.json", {
            "evidence": [
                {"evidence_id": "ev-public", "title": "Public source", "source_type": "document", "visibility": "public"},
                {"evidence_id": "ev-private", "title": "Private source", "source_type": "owner_note", "visibility": "private"},
            ]
        })
        ledger = root / "ledger.jsonl"
        append_event(ledger, base_event(event_id="evt-public", visibility="public", evidence_refs=["ev-public"]))
        append_event(ledger, base_event(event_id="evt-private", content="Private event", visibility="private", evidence_refs=["ev-private"]))
        out = root / "out"
        bundle = compile_noesis(root / "owner.json", ledger, root / "evidence.json", out, config=root / "config.json")
        return root, bundle

    def test_selective_export_respects_visibility(self):
        with tempfile.TemporaryDirectory() as td:
            root, bundle = self._compile_visibility_fixture(td)
            public = export_transparency_packet(bundle, root / "public.json", audience="public")
            owner = export_transparency_packet(bundle, root / "owner-export.json", audience="owner")
            self.assertEqual([e["event_id"] for e in public["events"]], ["evt-public"])
            self.assertEqual([e["evidence_id"] for e in public["evidence"]], ["ev-public"])
            self.assertEqual(len(owner["events"]), 2)
            self.assertEqual(public["automatic_external_action_authority"], 0)
            self.assertIn("selective owner-governed view", public["export_boundary"])

    def test_worldline_diff_is_not_person_score(self):
        with tempfile.TemporaryDirectory() as td:
            root, bundle1 = self._compile_visibility_fixture(td)
            ledger = root / "ledger.jsonl"
            append_event(ledger, base_event(event_id="evt-revision", content="A successor record.", supersedes=["evt-public"], visibility="public"))
            bundle2 = compile_noesis(root / "owner.json", ledger, root / "evidence.json", root / "out2", config=root / "config.json")
            delta = compare_bundles(bundle1, bundle2)
            self.assertIn("evt-revision", delta["added_event_ids"])
            self.assertTrue(any(r["event_id"] == "evt-revision" for r in delta["revision_lineage_in_new"]))
            self.assertIn("not a change in personal worth", delta["interpretation_boundary"])
            self.assertEqual(delta["automatic_external_action_authority"], 0)


class SelectiveTransparencyAndDiffTests(unittest.TestCase):
    def _bundle(self):
        public = normalize_event(base_event(event_id="evt-public", visibility="public", consent_ref="consent-public", owner_only_notes=["remove me"], evidence_refs=["ev-public"]))
        trusted = normalize_event(base_event(event_id="evt-trusted", content="Trusted event", created_at="2026-08-31T02:00:00Z", visibility="trusted_reviewer", consent_ref="consent-trusted", evidence_refs=["ev-trusted"]))
        private = normalize_event(base_event(event_id="evt-private", content="Private event", created_at="2026-08-31T03:00:00Z", visibility="private", owner_only_notes=["private note"], evidence_refs=["ev-private"]))
        evidence = [
            normalize_evidence({"evidence_id":"ev-public","title":"Public","source_type":"primary_document","visibility":"public","consent_ref":"consent-public"}),
            normalize_evidence({"evidence_id":"ev-trusted","title":"Trusted","source_type":"primary_document","visibility":"trusted_reviewer","consent_ref":"consent-trusted"}),
            normalize_evidence({"evidence_id":"ev-private","title":"Private","source_type":"primary_document","visibility":"private"}),
        ]
        return {
            "system":"NOESIS", "version":"1.0.0", "compilation_id":"c1", "bundle_digest":"d"*64,
            "owner":{"owner_id":OWNER,"display_name":"Private Name","scope_notice":"test"},
            "event_index":[public,trusted,private], "evidence_ledger":evidence,
            "audit":{"issues":[],"interpretation_boundary":"test","single_score_prohibited":True},
            "correction_proposals":[], "law_registry_summary":{}, "claim_boundaries":[]
        }

    def test_public_export_filters_and_strips_owner_notes(self):
        with tempfile.TemporaryDirectory() as td:
            packet = export_transparency_packet(self._bundle(), Path(td)/"public.json", audience="public")
            self.assertEqual([e["event_id"] for e in packet["events"]], ["evt-public"])
            self.assertNotIn("owner_only_notes", packet["events"][0])
            self.assertEqual(packet["owner"]["display_name"], "")
            self.assertEqual([e["evidence_id"] for e in packet["evidence"]], ["ev-public"])

    def test_trusted_export_includes_trusted_and_public(self):
        with tempfile.TemporaryDirectory() as td:
            packet = export_transparency_packet(self._bundle(), Path(td)/"trusted.json", audience="trusted_reviewer")
            self.assertEqual({e["event_id"] for e in packet["events"]}, {"evt-public","evt-trusted"})
            self.assertNotIn("evt-private", {e["event_id"] for e in packet["events"]})

    def test_diff_reports_added_and_changed(self):
        old = self._bundle()
        new = json.loads(json.dumps(old))
        new["compilation_id"] = "c2"
        new["event_index"][0]["confidence"] = 0.42
        new["event_index"].append(normalize_event(base_event(event_id="evt-new", content="New event", created_at="2026-08-31T04:00:00Z")))
        report = compare_bundles(old, new)
        self.assertEqual(report["added_event_ids"], ["evt-new"])
        self.assertEqual(report["changed_events"][0]["event_id"], "evt-public")
        self.assertIn("confidence", report["changed_events"][0]["fields"] )


class ReleaseIntegrityExtensions(unittest.TestCase):
    def _write_inputs(self, td: str):
        root = Path(td)
        save_json(root/"owner.json", {"owner_id":OWNER,"display_name":"Test","rights":{"owner_review_required":True,"right_to_opacity":True,"selective_transparency":True},"visibility_policy":{"absence_interpretation":"Absence is not deficiency."},"automatic_external_action_authority":0})
        save_json(root/"config.json", {"mesh_mode":"MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE","automatic_external_action_authority":0})
        save_json(root/"evidence.json", {"evidence":[]})
        ledger=root/"ledger.jsonl"
        append_event(ledger, base_event(visibility="private"))
        return root,ledger

    def test_unknown_user_file_is_preserved_and_untracked(self):
        with tempfile.TemporaryDirectory() as td:
            root,ledger=self._write_inputs(td); out=root/"out"
            compile_noesis(root/"owner.json",ledger,root/"evidence.json",out,config=root/"config.json")
            (out/"owner-note.txt").write_text("preserve",encoding="utf-8")
            compile_noesis(root/"owner.json",ledger,root/"evidence.json",out,config=root/"config.json")
            manifest=json.loads((out/"MANIFEST.json").read_text(encoding="utf-8"))
            self.assertTrue((out/"owner-note.txt").exists())
            self.assertIn("owner-note.txt",manifest["untracked_files"])

    def test_selective_transparency_summary_is_non_trait(self):
        with tempfile.TemporaryDirectory() as td:
            root,ledger=self._write_inputs(td); out=root/"out"
            bundle=compile_noesis(root/"owner.json",ledger,root/"evidence.json",out,config=root/"config.json")
            st=bundle["selective_transparency"]
            self.assertTrue(st["right_to_opacity_declared"])
            self.assertTrue(st["complete_person_inference_prohibited"])
            self.assertEqual(st["automatic_external_action_authority"],0)

    def test_book_registry_contains_language_specific_records(self):
        registry = load_law_registry()
        self.assertEqual(registry["books"]["B04"]["records"]["en"]["doi"], "10.13140/RG.2.2.26133.69600")
        self.assertEqual(registry["books"]["B05"]["records"]["en"]["doi"], "10.13140/RG.2.2.34522.30403")
        self.assertIn("does not prove", registry["source_translation_boundary"].lower())

    def test_evidence_invalid_visibility_rejected(self):
        with self.assertRaises(ValueError):
            normalize_evidence({"title":"x","source_type":"other","visibility":"everywhere"})


if __name__ == "__main__":
    unittest.main()
