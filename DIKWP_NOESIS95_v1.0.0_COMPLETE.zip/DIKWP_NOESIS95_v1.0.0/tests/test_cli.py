from __future__ import annotations

from contextlib import redirect_stdout, redirect_stderr
import io
import json
from pathlib import Path
import tempfile
import unittest

from dikwp_noesis95.cli import main


class CLITests(unittest.TestCase):
    def test_doctor(self):
        out=io.StringIO()
        with redirect_stdout(out):
            code=main(["doctor"])
        self.assertEqual(code,0)
        data=json.loads(out.getvalue())
        self.assertEqual(data["bundled_working_law_count"],24)
        self.assertEqual(data["automatic_external_action_authority"],0)

    def test_init_workspace(self):
        with tempfile.TemporaryDirectory() as td:
            ws=Path(td)/"ws"
            out=io.StringIO()
            with redirect_stdout(out):
                code=main(["init",str(ws),"--owner-id","owner-x"])
            self.assertEqual(code,0)
            self.assertTrue((ws/"owner.json").exists())
            self.assertTrue((ws/"cognitive_ledger.jsonl").exists())

    def test_invalid_external_authority_config(self):
        with tempfile.TemporaryDirectory() as td:
            ws=Path(td)/"ws"
            with redirect_stdout(io.StringIO()):
                main(["init",str(ws),"--owner-id","owner-x"])
            config=json.loads((ws/"config.json").read_text(encoding="utf-8")); config["automatic_external_action_authority"]=1
            (ws/"config.json").write_text(json.dumps(config),encoding="utf-8")
            err=io.StringIO()
            with redirect_stderr(err):
                code=main(["compile","--owner",str(ws/"owner.json"),"--ledger",str(ws/"cognitive_ledger.jsonl"),"--evidence",str(ws/"evidence.json"),"--config",str(ws/"config.json"),"--out",str(ws/"out")])
            self.assertEqual(code,3)
            self.assertIn("automatic external action",err.getvalue())


if __name__ == "__main__":
    unittest.main()
