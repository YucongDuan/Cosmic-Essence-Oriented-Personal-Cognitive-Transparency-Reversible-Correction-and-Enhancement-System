# Changelog

## 1.0.0 — 2026-08-31

- Initial open-source reference release.
- Append-only cognitive event ledger with hash-chain verification.
- E/H/F/P/N and D/I/K/W/P record typing.
- Evidence quality, independence and rights-aware provenance ledger.
- Sixteen-dimensional cognitive record transparency vector.
- Twenty-six transparent epistemic/decision risk patterns.
- Non-isomorphic world-model competition and discriminator audit.
- Forecast outcome register with Brier, log-loss and calibration bins.
- Twenty-four versioned cosmic-essence-oriented working-law cards.
- Owner-approval-only append-only correction proposals.
- Burden-bounded cognitive enhancement exercises.
- EIDOS95 context integration, static offline dashboard, manifests and verification.
