# DIKWP-NOESIS 9.5

## 面向宇宙本质工作规律的个人认知透明化、可逆矫正与共同提升系统

NOESIS95不是“读心器”、人格测试、思想改造工具，也不把人压缩成一个认知分数。它把个人主动提交的关键认知记录，组织为可追溯、可否证、可校准、可修订、可拒绝和可退出的认知世界线。

### 与EIDOS95的关系

- EIDOS95处理已经积累的论文、著作、代码、经验、反例、目的与权利，形成认知本质中间表示。
- NOESIS95处理正在发生的判断：主张从何而来、属于D/I/K/W/P哪一位置、是E/H/F/P/N哪类主张、有哪些竞争模型、预计发生什么、结果怎样、置信度如何修订、谁获益、谁承担代价、是否可逆。


### 两套P不得坍塌

- `claim_class`属于`research_book_claim_status`命名空间：E=已建立或受来源约束的结果，H=历史解释，F=形式/关系构造，P=经验假说，N=规范或形而上提案。
- `dikwp`属于`semantic_position`命名空间：D=同语义/数据登记，I=差异语义/信息登记，K=认知抽象形成的完整语义，W=价值配置，P=目的及可执行输入—输出取向。
- 因而“主张类P”和“DIKWP位置P”不能因为字母相同而被混为一类；系统在每个事件中同时保存命名空间和中文/英文含义。

### 关键能力

1. 认知事件采用追加式哈希链，不静默覆盖历史。
2. 经验与假说主张回到证据ID、来源类型、独立依赖组、质量与权利记录。
3. 高影响判断需要非同构世界模型，而非同一句话的不同措辞。
4. 概率预测保留原始概率，结果另行追加，并计算Brier分数、对数损失与校准区间。
5. 系统只生成矫正候选；具名所有者批准后才能追加后继记录。
6. 所有者可拒绝、暂停、撤回未来使用、修订或退役建议。
7. 24条“宇宙本质导向工作规律”分别标注为本体工作命题、形式协议、研究假说、经验方法或规范约束，并带反例入口与退役条件。
8. 自动外部行动权限固定为0。

### 最短运行

```bash
python run.py doctor
python run.py demo --out outputs/yucongduan_cosmic_method
python run.py verify outputs/yucongduan_cosmic_method
```


### 选择性透明导出与世界线差分

```bash
python run.py export \
  --bundle outputs/yucongduan_cosmic_method/noesis_bundle.json \
  --audience owner \
  --out outputs/owner_transparency_packet.json

python run.py diff \
  --old outputs/noesis_v1/noesis_bundle.json \
  --new outputs/noesis_v2/noesis_bundle.json \
  --out outputs/cognitive_worldline_delta.json
```

公开或评审导出只包含相应可见级别的事件和证据；过滤包不是完整账本。差分描述记录世界线变化，不表示人的价值、智力、心理或身份发生了评分变化。

### 透明度向量

系统分别展示来源、范围、不确定性、主张分类、DIKWP位置、模型多元、区分证据、价值、目的、受影响世界、可否证性、可逆性、现实接触、修订连续性、残差和能力情境。导航均值只用于寻找记录缺口，不能用于评价人的智力、人格、道德、真诚、意识、心理健康或社会价值。

### 矫正的含义

这里的“认知矫正”不是强制替换信念，而是：

> 在保留原记录的前提下，通过补充来源、降低不当置信、拆分主张类别、建立竞争模型、预写反证条件、执行最小可逆试验、回填现实结果，并由所有者具名批准，形成新的后继认知状态。

### 边界

本系统不能诊断或治疗心理/精神疾病，不能代替医疗、心理、法律、金融或安全专业人员，不能认证意识或人格，不能自动代表任何人对外发布、通信、交易或采取行动。不得用于强制筛选、秘密画像、就业或保险评分、意识形态一致性审查和非自愿认知改造。

完整说明见：

- `docs/ARCHITECTURE_CN.md`
- `docs/FORMAL_SPEC_CN.md`
- `docs/COSMIC_WORKING_LAWS_CN_EN.md`
- `docs/CLAIM_BOUNDARIES_CN_EN.md`
- `docs/THREAT_MODEL_CN_EN.md`
- `docs/EIDOS95_INTEGRATION_CN_EN.md`
